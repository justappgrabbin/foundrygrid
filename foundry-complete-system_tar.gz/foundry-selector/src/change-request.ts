/**
 * Foundry Selector - Change Request (Phase 2)
 * 
 * GATE between observation (Phase 1) and mutation (Phase 3).
 * 
 * Any attempt to:
 * - Add fillers
 * - Modify structure
 * - Fork app
 * - Generate code
 * - Create new glyph
 * 
 * MUST pass through a Change Request.
 */

export type ChangeRequestType = 
  | 'ADD_FILLERS'
  | 'FORK_APP'
  | 'PERSONALIZE'
  | 'MODIFY_STRUCTURE';

export type ChangeRequestSource =
  | 'system'
  | 'user'
  | 'policy'
  | 'admin';

export interface ChangeRequest {
  type: ChangeRequestType;
  targetApp: string;              // App glyph ID
  missing: string[];              // What's missing
  requestedBy: ChangeRequestSource;
  reason: string;                 // Why this change
  approved: boolean;              // Gate
  approvedBy?: string;            // Who approved
  approvedAt?: string;            // When approved
  metadata?: Record<string, unknown>;
}

/**
 * Create change request for adding fillers
 */
export function createFillerRequest(
  targetApp: string,
  missing: string[],
  reason: string
): ChangeRequest {
  return {
    type: 'ADD_FILLERS',
    targetApp,
    missing,
    requestedBy: 'system',
    reason,
    approved: false,
  };
}

/**
 * Approve change request
 */
export function approveRequest(
  request: ChangeRequest,
  approvedBy: string
): ChangeRequest {
  return {
    ...request,
    approved: true,
    approvedBy,
    approvedAt: new Date().toISOString(),
  };
}

/**
 * Validate that request is approved before proceeding
 */
export function requireApproval(request: ChangeRequest): void {
  if (!request.approved) {
    throw new Error(
      `Change request not approved. ` +
      `Type: ${request.type}, Target: ${request.targetApp}`
    );
  }
}
