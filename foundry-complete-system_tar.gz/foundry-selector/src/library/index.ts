/**
 * Foundry Selector - App Library
 * 
 * Catalog of finished apps with extracted capabilities.
 */

import type { AppRecord } from '../profile/types.js';

// In-memory app library
// In production: this would be in database
const apps: Map<string, AppRecord> = new Map();

/**
 * Add app to library
 */
export function addApp(app: AppRecord): void {
  apps.set(app.appGlyph, app);
}

/**
 * Get app by glyph ID
 */
export function getApp(glyphId: string): AppRecord | null {
  return apps.get(glyphId) || null;
}

/**
 * List all apps
 */
export function listApps(filters?: {
  quality?: string;
  tags?: string[];
  hasCapabilities?: string[];
}): AppRecord[] {
  let results = Array.from(apps.values());
  
  // Filter by quality
  if (filters?.quality) {
    results = results.filter(app => app.quality === filters.quality);
  }
  
  // Filter by tags
  if (filters?.tags && filters.tags.length > 0) {
    results = results.filter(app =>
      filters.tags!.some(tag => app.tags.includes(tag))
    );
  }
  
  // Filter by capabilities
  if (filters?.hasCapabilities && filters.hasCapabilities.length > 0) {
    results = results.filter(app =>
      filters.hasCapabilities!.every(cap => app.capabilities.includes(cap))
    );
  }
  
  return results;
}

/**
 * Find apps with specific capabilities
 */
export function findByCapabilities(capabilities: string[]): AppRecord[] {
  return Array.from(apps.values()).filter(app =>
    capabilities.every(cap => app.capabilities.includes(cap))
  );
}

/**
 * Get production-locked apps only
 */
export function getProductionApps(): AppRecord[] {
  return Array.from(apps.values()).filter(app =>
    app.quality === 'production' && app.locked
  );
}

/**
 * Seed library with example apps
 */
export function seedLibrary(): void {
  // SaaS Dashboard App
  addApp({
    appGlyph: 'sha256:saas-dashboard-v1',
    quality: 'production',
    capabilities: ['auth', 'dashboard', 'user-management', 'analytics'],
    strengths: ['onboarding', 'ui', 'performance'],
    weaknesses: ['payments', 'advanced-analytics'],
    derivedFrom: [
      'sha256:auth-component',
      'sha256:dashboard-layout',
      'sha256:user-table',
      'sha256:analytics-charts'
    ],
    fillsGaps: ['routing', 'error-handling', 'state-management'],
    tags: ['saas', 'b2b', 'dashboard'],
    locked: true,
    name: 'SaaS Dashboard',
    description: 'Complete dashboard with auth and user management',
    created: '2025-12-01T00:00:00Z',
    size: 245000
  });
  
  // E-commerce App
  addApp({
    appGlyph: 'sha256:ecommerce-v1',
    quality: 'production',
    capabilities: ['auth', 'products', 'cart', 'payments', 'orders'],
    strengths: ['checkout', 'ui', 'mobile-responsive'],
    weaknesses: ['admin-panel', 'analytics'],
    derivedFrom: [
      'sha256:auth-component',
      'sha256:product-listing',
      'sha256:shopping-cart',
      'sha256:stripe-integration',
      'sha256:order-tracking'
    ],
    fillsGaps: ['routing', 'error-handling', 'form-validation'],
    tags: ['ecommerce', 'consumer', 'payments'],
    locked: true,
    name: 'E-commerce Store',
    description: 'Full e-commerce with Stripe payments',
    created: '2025-11-15T00:00:00Z',
    size: 312000
  });
  
  // Internal Tool
  addApp({
    appGlyph: 'sha256:internal-tool-v1',
    quality: 'tested',
    capabilities: ['auth', 'data-table', 'forms', 'export'],
    strengths: ['data-handling', 'filtering', 'bulk-operations'],
    weaknesses: ['ui-polish', 'mobile'],
    derivedFrom: [
      'sha256:auth-component',
      'sha256:data-grid',
      'sha256:form-builder',
      'sha256:csv-export'
    ],
    fillsGaps: ['routing', 'permissions'],
    tags: ['internal', 'admin', 'data'],
    locked: false,
    name: 'Internal Admin Tool',
    description: 'Data management tool for internal teams',
    created: '2025-12-10T00:00:00Z',
    size: 156000
  });
  
  // Marketing Site
  addApp({
    appGlyph: 'sha256:marketing-site-v1',
    quality: 'production',
    capabilities: ['landing', 'blog', 'contact-form', 'seo'],
    strengths: ['performance', 'seo', 'design'],
    weaknesses: ['interactivity'],
    derivedFrom: [
      'sha256:hero-section',
      'sha256:blog-engine',
      'sha256:contact-form',
      'sha256:seo-meta'
    ],
    fillsGaps: ['routing', 'static-generation'],
    tags: ['marketing', 'public', 'static'],
    locked: true,
    name: 'Marketing Site',
    description: 'High-performance marketing website',
    created: '2025-11-20T00:00:00Z',
    size: 89000
  });
  
  // Minimal Auth App
  addApp({
    appGlyph: 'sha256:auth-starter-v1',
    quality: 'tested',
    capabilities: ['auth', 'profile'],
    strengths: ['simplicity', 'security'],
    weaknesses: ['features', 'ui'],
    derivedFrom: [
      'sha256:auth-component',
      'sha256:profile-page'
    ],
    fillsGaps: ['routing', 'session-management'],
    tags: ['starter', 'minimal', 'auth'],
    locked: false,
    name: 'Auth Starter',
    description: 'Minimal authentication starter',
    created: '2025-12-12T00:00:00Z',
    size: 45000
  });
}
