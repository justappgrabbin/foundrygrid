#!/usr/bin/env node
/**
 * Foundry Selector - Demo
 * 
 * Shows the alignment engine in action.
 */

import { seedLibrary, listApps, getApp } from './library/index.js';
import { selectApp, rankApps } from './alignment/engine.js';
import type { UserProfile } from './profile/types.js';

// Colors for terminal output
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  blue: '\x1b[34m',
  yellow: '\x1b[33m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m',
};

function header(text: string) {
  console.log(`\n${colors.cyan}${text}${colors.reset}`);
  console.log('─'.repeat(70));
}

function success(text: string) {
  console.log(`${colors.green}✓${colors.reset} ${text}`);
}

function info(text: string) {
  console.log(`${colors.blue}ℹ${colors.reset} ${text}`);
}

// ============================================================================
// Demo Setup
// ============================================================================

header('Foundry Selector - Live Demonstration');

// Seed library with example apps
info('Seeding app library...');
seedLibrary();
const apps = listApps();
success(`Loaded ${apps.length} apps`);

// ============================================================================
// User Profile 1: SaaS Founder
// ============================================================================

header('User Profile 1: SaaS Founder');

const saasFounder: UserProfile = {
  needs: ['auth', 'dashboard', 'user-management'],
  constraints: ['high-reliability'],
  preferences: ['fast-setup', 'clean-ui'],
  avoid: ['experimental'],
};

console.log('Needs:', saasFounder.needs.join(', '));
console.log('Constraints:', saasFounder.constraints.join(', '));
console.log('Preferences:', saasFounder.preferences.join(', '));
console.log('Avoid:', saasFounder.avoid.join(', '));

const result1 = selectApp(saasFounder);

if (result1) {
  console.log(`\n${colors.green}Selected App:${colors.reset}`);
  const app1 = getApp(result1.selectedApp);
  console.log(`  Name: ${app1?.name}`);
  console.log(`  Glyph: ${result1.selectedApp}`);
  console.log(`  Confidence: ${(result1.confidence * 100).toFixed(1)}%`);
  console.log(`  Score: ${result1.score}`);
  
  console.log(`\n${colors.blue}Why this app:${colors.reset}`);
  console.log(`  ${result1.why}`);
  
  console.log(`\n${colors.green}Matched:${colors.reset}`);
  console.log(`  Needs: ${result1.matched.needs.join(', ') || 'none'}`);
  console.log(`  Preferences: ${result1.matched.preferences.join(', ') || 'none'}`);
  
  if (result1.missing.length > 0) {
    console.log(`\n${colors.yellow}Missing:${colors.reset}`);
    result1.missing.forEach(m => console.log(`  - ${m}`));
  }
  
  if (result1.recommendations.length > 0) {
    console.log(`\n${colors.blue}Recommendations:${colors.reset}`);
    result1.recommendations.forEach(r => console.log(`  - ${r}`));
  }
}

// ============================================================================
// User Profile 2: E-commerce Startup
// ============================================================================

header('User Profile 2: E-commerce Startup');

const ecommerceStartup: UserProfile = {
  needs: ['auth', 'products', 'cart', 'payments'],
  constraints: ['high-reliability'],
  preferences: ['mobile-responsive', 'fast-checkout'],
  avoid: [],
};

console.log('Needs:', ecommerceStartup.needs.join(', '));
console.log('Constraints:', ecommerceStartup.constraints.join(', '));
console.log('Preferences:', ecommerceStartup.preferences.join(', '));

const result2 = selectApp(ecommerceStartup);

if (result2) {
  console.log(`\n${colors.green}Selected App:${colors.reset}`);
  const app2 = getApp(result2.selectedApp);
  console.log(`  Name: ${app2?.name}`);
  console.log(`  Confidence: ${(result2.confidence * 100).toFixed(1)}%`);
  
  console.log(`\n${colors.blue}Why this app:${colors.reset}`);
  console.log(`  ${result2.why}`);
  
  console.log(`\n${colors.green}Matched:${colors.reset}`);
  console.log(`  Needs: ${result2.matched.needs.join(', ')}`);
}

// ============================================================================
// User Profile 3: Internal Tool Builder
// ============================================================================

header('User Profile 3: Internal Tool Builder');

const internalTool: UserProfile = {
  needs: ['auth', 'data-table', 'export'],
  constraints: [],
  preferences: ['data-handling', 'bulk-operations'],
  avoid: ['experimental'],
};

console.log('Needs:', internalTool.needs.join(', '));
console.log('Preferences:', internalTool.preferences.join(', '));

const result3 = selectApp(internalTool);

if (result3) {
  console.log(`\n${colors.green}Selected App:${colors.reset}`);
  const app3 = getApp(result3.selectedApp);
  console.log(`  Name: ${app3?.name}`);
  console.log(`  Confidence: ${(result3.confidence * 100).toFixed(1)}%`);
  
  console.log(`\n${colors.blue}Why this app:${colors.reset}`);
  console.log(`  ${result3.why}`);
}

// ============================================================================
// Ranking Demo
// ============================================================================

header('Ranking All Apps for SaaS Founder');

const ranked = rankApps(saasFounder, 3);

console.log('Top 3 matches:\n');
ranked.forEach((result, i) => {
  const app = getApp(result.selectedApp);
  console.log(`${i + 1}. ${app?.name}`);
  console.log(`   Confidence: ${(result.confidence * 100).toFixed(1)}%`);
  console.log(`   Score: ${result.score}`);
  console.log(`   Matched needs: ${result.matched.needs.join(', ')}`);
  if (result.missing.length > 0) {
    console.log(`   Missing: ${result.missing.join(', ')}`);
  }
  console.log();
});

// ============================================================================
// Summary
// ============================================================================

header('Summary');

console.log('What we demonstrated:\n');
success('App library with 5 production apps');
success('Deterministic scoring algorithm');
success('Explainable selection (why this app?)');
success('Gap detection (what\'s missing)');
success('Recommendations (how to improve)');
success('Ranking (compare multiple apps)');

console.log(`\n${colors.gray}The alignment engine is working.${colors.reset}`);
console.log(`${colors.gray}No AI. No guessing. Just logic.${colors.reset}\n`);
