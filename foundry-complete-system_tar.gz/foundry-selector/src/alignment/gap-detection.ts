/**
 * Foundry Selector - Gap Detection (Phase 1)
 * 
 * OBSERVES gaps. Does NOT generate or fix them.
 * Generation happens in Phase 3 (foundry-builder).
 */

/**
 * Detect missing capabilities
 */
export function detectGaps(
  appCapabilities: string[],
  userNeeds: string[]
): string[] {
  return userNeeds.filter(need => !appCapabilities.includes(need));
}

/**
 * Detect missing system components (routing, error handling, etc)
 */
export function detectSystemGaps(
  existingModules: string[]
): { type: string; reason: string }[] {
  const gaps: { type: string; reason: string }[] = [];
  
  // Check for routing
  if (!existingModules.some(m => m.includes('router') || m.includes('Router'))) {
    gaps.push({
      type: 'routing',
      reason: 'App has multiple pages but no router'
    });
  }
  
  // Check for error boundary
  if (!existingModules.some(m => m.includes('ErrorBoundary'))) {
    gaps.push({
      type: 'error-boundary',
      reason: 'App lacks error handling'
    });
  }
  
  // Check for boot logic
  if (!existingModules.some(m => m.includes('index') || m.includes('main'))) {
    gaps.push({
      type: 'boot',
      reason: 'App needs initialization code'
    });
  }
  
  return gaps;
}

// EVERYTHING BELOW THIS LINE WAS REMOVED
// Gap generation belongs in Phase 3 (foundry-builder)

/**
 * OLD CODE - MOVED TO foundry-builder
 * 
 * function generateRouting(routes: string[]): GapFiller {
  const content = `// Auto-generated routing
import { BrowserRouter, Routes, Route } from 'react-router-dom';

export function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
${routes.map(route => `        <Route path="${route}" element={<${capitalize(route)}Page />} />`).join('\n')}
      </Routes>
    </BrowserRouter>
  );
}

function capitalize(str: string): string {
  return str.charAt(0).toUpperCase() + str.slice(1);
}
`;
  
  return {
    type: 'routing',
    generated: true,
    content,
    reason: 'App needs routing between pages',
  };
}

/**
 * Generate boot logic gap filler
 */
function generateBoot(appName: string): GapFiller {
  const content = `// Auto-generated boot logic
import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

console.log('${appName} initialized');
`;
  
  return {
    type: 'boot',
    generated: true,
    content,
    reason: 'App needs initialization code',
  };
}

/**
 * Generate error boundary gap filler
 */
function generateErrorBoundary(): GapFiller {
  const content = `// Auto-generated error boundary
import React from 'react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('App error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '2rem', textAlign: 'center' }}>
          <h1>Something went wrong</h1>
          <p>{this.state.error?.message}</p>
          <button onClick={() => window.location.reload()}>
            Reload
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
`;
  
  return {
    type: 'error-boundary',
    generated: true,
    content,
    reason: 'App needs error handling',
  };
}

/**
 * Generate defaults gap filler
 */
function generateDefaults(config: Record<string, unknown>): GapFiller {
  const content = `// Auto-generated defaults
export const appDefaults = ${JSON.stringify(config, null, 2)};
`;
  
  return {
    type: 'defaults',
    generated: true,
    content,
    reason: 'App needs default configuration',
  };
}

/**
 * Generate glue code gap filler
 */
function generateGlue(components: string[]): GapFiller {
  const content = `// Auto-generated glue code
// Connects components that weren't designed to work together

${components.map(comp => `import ${comp} from './${comp}';`).join('\n')}

export function ConnectedApp() {
  return (
    <div className="app">
      ${components.map(comp => `<${comp} />`).join('\n      ')}
    </div>
  );
}
`;
  
  return {
    type: 'glue',
    generated: true,
    content,
    reason: 'App needs to connect disparate components',
  };
}

/**
 * Determine what fillers are needed for an app
 */
export function determineNeededFillers(
  capabilities: string[],
  existingFiles: string[]
): GapFiller[] {
  const fillers: GapFiller[] = [];
  
  // Check if routing is needed
  if (!existingFiles.includes('router.tsx') && !existingFiles.includes('Router.tsx')) {
    const routes = capabilities.filter(cap =>
      ['auth', 'dashboard', 'profile', 'settings'].includes(cap)
    );
    if (routes.length > 1) {
      fillers.push(generateRouting(routes));
    }
  }
  
  // Check if boot logic is needed
  if (!existingFiles.includes('index.tsx') && !existingFiles.includes('main.tsx')) {
    fillers.push(generateBoot('App'));
  }
  
  // Check if error boundary is needed
  if (!existingFiles.includes('ErrorBoundary.tsx')) {
    fillers.push(generateErrorBoundary());
  }
  
  // Always add defaults if not present
  if (!existingFiles.includes('config.ts') && !existingFiles.includes('defaults.ts')) {
    fillers.push(generateDefaults({
      apiUrl: process.env.API_URL || '/api',
      environment: process.env.NODE_ENV || 'development',
    }));
  }
  
  return fillers;
}

/**
 * Apply fillers to app content
 */
export function applyFillers(
  appContent: Map<string, string>,
  fillers: GapFiller[]
): Map<string, string> {
  const result = new Map(appContent);
  
  for (const filler of fillers) {
    let filename: string;
    
    switch (filler.type) {
      case 'routing':
        filename = 'src/Router.tsx';
        break;
      case 'boot':
        filename = 'src/index.tsx';
        break;
      case 'error-boundary':
        filename = 'src/ErrorBoundary.tsx';
        break;
      case 'defaults':
        filename = 'src/config.ts';
        break;
      case 'glue':
        filename = 'src/Glue.tsx';
        break;
    }
    
    result.set(filename, filler.content);
  }
  
  return result;
}
