/**
 * Foundry Selector - Alignment Engine
 * 
 * Deterministic, explainable app selection.
 * No AI. Just logic.
 */

import type { UserProfile, AppRecord, AlignmentResult } from '../profile/types.js';
import { listApps } from '../library/index.js';
import { detectGaps, detectSystemGaps } from './gap-detection.js';

/**
 * Select best app for user profile
 */
export function selectApp(profile: UserProfile): AlignmentResult | null {
  // Get candidate apps (production only by default)
  const candidates = listApps({ quality: 'production' });
  
  if (candidates.length === 0) {
    return null;
  }
  
  // Score each app
  const scored = candidates.map(app => ({
    app,
    score: scoreApp(app, profile),
  }));
  
  // Sort by score (descending)
  scored.sort((a, b) => b.score.total - a.score.total);
  
  const best = scored[0];
  
  // Calculate confidence (0.0 - 1.0)
  const maxPossible = calculateMaxScore(profile);
  const confidence = best.score.total / maxPossible;
  
  // Build result
  return {
    selectedApp: best.app.appGlyph,
    confidence,
    score: best.score.total,
    matched: {
      needs: best.score.matchedNeeds,
      preferences: best.score.matchedPreferences,
    },
    missing: best.score.missingNeeds,
    systemGaps: detectSystemGaps(best.app.fillsGaps), // Phase 1 - detection only
    recommendations: generateRecommendations(best.app, profile, best.score),
    why: explainSelection(best.app, profile, best.score),
  };
}

/**
 * Score an app against user profile
 */
function scoreApp(app: AppRecord, profile: UserProfile): {
  total: number;
  matchedNeeds: string[];
  missingNeeds: string[];
  matchedPreferences: string[];
  conflicts: string[];
} {
  let total = 0;
  const matchedNeeds: string[] = [];
  const matchedPreferences: string[] = [];
  const conflicts: string[] = [];
  
  // Detect gaps (Phase 1 - observation only)
  const missingNeeds = detectGaps(app.capabilities, profile.needs);
  
  // Score needs (critical - high weight)
  for (const need of profile.needs) {
    if (app.capabilities.includes(need)) {
      total += 10; // High weight for needs
      matchedNeeds.push(need);
    } else {
      // Already in missingNeeds from detectGaps()
      total -= 5; // Penalty for missing needs
    }
  }
  
  // Score preferences (nice-to-have - medium weight)
  for (const pref of profile.preferences) {
    if (app.strengths.includes(pref)) {
      total += 3;
      matchedPreferences.push(pref);
    }
  }
  
  // Check constraints (hard requirements)
  for (const constraint of profile.constraints) {
    if (constraint === 'high-reliability' && app.quality === 'production') {
      total += 5;
    }
    if (constraint === 'fast-setup' && app.size < 100000) {
      total += 2;
    }
  }
  
  // Penalize avoided attributes
  for (const avoid of profile.avoid) {
    if (avoid === 'experimental' && app.quality !== 'production') {
      total -= 10;
      conflicts.push(`Quality is ${app.quality}, not production`);
    }
    if (app.weaknesses.includes(avoid)) {
      total -= 3;
      conflicts.push(`Weak in ${avoid}`);
    }
  }
  
  // Bonus for gap coverage
  total += app.fillsGaps.length * 2;
  
  // Quality bonus
  if (app.quality === 'production' && app.locked) {
    total += 5;
  }
  
  return {
    total,
    matchedNeeds,
    missingNeeds,
    matchedPreferences,
    conflicts,
  };
}

/**
 * Calculate theoretical maximum score
 */
function calculateMaxScore(profile: UserProfile): number {
  let max = 0;
  
  // All needs met
  max += profile.needs.length * 10;
  
  // All preferences met
  max += profile.preferences.length * 3;
  
  // Constraints met
  max += profile.constraints.length * 5;
  
  // No conflicts
  // (no penalty)
  
  // Average gap coverage
  max += 6; // Assume 3 gaps filled
  
  // Quality bonus
  max += 5;
  
  return max;
}

/**
 * Generate recommendations
 */
function generateRecommendations(
  app: AppRecord,
  profile: UserProfile,
  score: ReturnType<typeof scoreApp>
): string[] {
  const recs: string[] = [];
  
  // Missing needs
  if (score.missingNeeds.length > 0) {
    for (const need of score.missingNeeds) {
      recs.push(`Add ${need} module to fulfill requirement`);
    }
  }
  
  // Weaknesses that matter
  for (const weak of app.weaknesses) {
    if (profile.needs.includes(weak) || profile.preferences.includes(weak)) {
      recs.push(`Consider strengthening ${weak} (currently weak)`);
    }
  }
  
  // Quality upgrade
  if (!app.locked && profile.constraints.includes('high-reliability')) {
    recs.push('Promote to production and lock for reliability');
  }
  
  return recs;
}

/**
 * Explain why this app was selected
 */
function explainSelection(
  app: AppRecord,
  profile: UserProfile,
  score: ReturnType<typeof scoreApp>
): string {
  const reasons: string[] = [];
  
  // Matched needs
  if (score.matchedNeeds.length > 0) {
    reasons.push(
      `Provides ${score.matchedNeeds.length}/${profile.needs.length} required capabilities: ${score.matchedNeeds.join(', ')}`
    );
  }
  
  // Matched preferences
  if (score.matchedPreferences.length > 0) {
    reasons.push(
      `Strong in preferred areas: ${score.matchedPreferences.join(', ')}`
    );
  }
  
  // Quality
  if (app.quality === 'production' && app.locked) {
    reasons.push('Production-grade and locked (high reliability)');
  }
  
  // Gap coverage
  if (app.fillsGaps.length > 0) {
    reasons.push(
      `Includes essential glue: ${app.fillsGaps.join(', ')}`
    );
  }
  
  return reasons.join('. ');
}

/**
 * Compare multiple apps for user
 */
export function rankApps(profile: UserProfile, limit: number = 5): AlignmentResult[] {
  const candidates = listApps({ quality: 'production' });
  
  const results = candidates
    .map(app => {
      const score = scoreApp(app, profile);
      const maxPossible = calculateMaxScore(profile);
      const confidence = score.total / maxPossible;
      
      return {
        selectedApp: app.appGlyph,
        confidence,
        score: score.total,
        matched: {
          needs: score.matchedNeeds,
          preferences: score.matchedPreferences,
        },
        missing: score.missingNeeds,
        recommendations: generateRecommendations(app, profile, score),
        why: explainSelection(app, profile, score),
      };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
  
  return results;
}
