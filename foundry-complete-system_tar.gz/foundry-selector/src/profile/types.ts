/**
 * Foundry Selector - Core Types
 * 
 * Simple, concrete types. No abstractions.
 */

// ============================================================================
// App Library
// ============================================================================

export interface AppRecord {
  appGlyph: string;                    // sha256:...
  quality: 'draft' | 'tested' | 'production' | 'archived';
  
  // Extracted from glyph metadata
  capabilities: string[];              // ["auth", "dashboard", "payments"]
  strengths: string[];                 // ["onboarding", "ui"]
  weaknesses: string[];                // ["analytics"]
  
  // Lineage
  derivedFrom: string[];               // Parent fragment glyphs
  
  // What this app provides as glue
  fillsGaps: string[];                 // ["routing", "error-handling"]
  
  // Categorization
  tags: string[];                      // ["saas", "consumer", "internal"]
  
  // Immutability
  locked: boolean;                     // true if quality === 'production'
  
  // Metadata
  name?: string;
  description?: string;
  created: string;
  size: number;
}

// ============================================================================
// User Profile
// ============================================================================

export interface UserProfile {
  // What the user needs
  needs: string[];                     // ["auth", "dashboard"]
  
  // Hard constraints
  constraints: string[];               // ["high-reliability"]
  
  // Soft preferences
  preferences: string[];               // ["fast-setup", "clean-ui"]
  
  // What to avoid
  avoid: string[];                     // ["experimental"]
}

// ============================================================================
// Alignment Result
// ============================================================================

export interface AlignmentResult {
  selectedApp: string;                 // App glyph ID
  confidence: number;                  // 0.0 - 1.0
  score: number;                       // Raw score
  
  // Match details
  matched: {
    needs: string[];                   // Needs that are met
    preferences: string[];             // Preferences that are met
  };
  
  // What's missing (Phase 1 - detection only)
  missing: string[];                   // Needs not met
  systemGaps?: Array<{                 // System components missing
    type: string;
    reason: string;
  }>;
  
  // Recommendations
  recommendations: string[];           // Human-readable suggestions
  
  // Explanation
  why: string;                         // "This app fits because..."
}

// ============================================================================
// Removed: GapFiller, PersonalizedApp
// These belong in Phase 3 (foundry-builder)
// ============================================================================
