/**
 * Foundry Core Library - Type Definitions
 * Pure types, no runtime dependencies
 */

export type QualityLevel = 'draft' | 'tested' | 'production' | 'archived';
export type OriginType = 'imported' | 'assembled' | 'derived';
export type ContentType = 'fragment' | 'app' | 'artifact';

/**
 * Core glyph structure (immutable identity)
 */
export interface Glyph {
  // Identity (derived from content + lineage)
  id: string;                    // sha256:... (hash of canonical glyph payload)
  schemaVersion: number;         // 1
  
  // Content identity (separate from glyph ID)
  contentHash: string;           // sha256 of normalized content
  contentSize: number;           // bytes
  contentType: ContentType;
  
  // Metadata (mutable via new glyph)
  quality: QualityLevel;
  
  // Provenance (immutable)
  origin: GlyphOrigin;
  
  // Timestamps (excluded from hash inputs)
  createdAt: string;             // ISO 8601, excluded from glyph.id
  promotedAt?: string;           // excluded from glyph.id
  
  // Producer
  producer: Producer;
  
  // Trust attestations (for tested/production)
  attestations?: Attestation[];
}

export interface GlyphOrigin {
  type: OriginType;
  parents?: string[];            // glyph IDs (for assembled/derived)
  sourceUri?: string;            // for imported
  changes?: string[];            // What changed from parent (for derived)
  reason?: string;               // Why this derivation happened
}

export interface Producer {
  userId: string;                // "user-alice" | "foundry-selector" | "foundry-builder"
  tool: string;                  // "foundry-cli/1.0.0"
  environment: string;           // "node/20.11.0"
  humanReadable?: string;        // "Alice Smith" (optional display name)
}

export interface Attestation {
  quality: 'tested' | 'production';
  signer: string;                // public key or user ID
  signature: string;             // Ed25519 signature (base64)
  signedAt: string;              // ISO 8601, excluded from signature payload
  evidence?: string;             // URI to CI run, test report, etc.
  metadata?: Record<string, unknown>;
}

/**
 * Canonical glyph payload (what gets hashed to create glyph.id)
 * CRITICAL: Order matters. Must be sorted.
 */
export interface CanonicalGlyphPayload {
  contentHash: string;
  contentSize: number;
  contentType: ContentType;
  origin: {
    type: OriginType;
    parents?: string[];          // sorted
    sourceUri?: string;
  };
  producer: {
    environment: string;
    tool: string;
    userId: string;
  };
  quality: QualityLevel;
  schemaVersion: number;
}

/**
 * Fragment input (before glyph creation)
 */
export interface FragmentInput {
  content: string | Buffer;
  manifest?: Record<string, unknown>;
  contentType?: ContentType;
  quality?: QualityLevel;
  origin?: Partial<GlyphOrigin>;
  producer: Producer;
}

/**
 * Signature payload (what gets signed for attestations)
 */
export interface SignaturePayload {
  glyphId: string;
  quality: 'tested' | 'production';
  timestamp: string;             // ISO 8601
  evidence?: string;
}

/**
 * Assembly recipe (deterministic build input)
 */
export interface Recipe {
  schemaVersion: number;
  app: {
    name: string;
    version: string;
    framework?: string;
  };
  fragments: FragmentReference[];
  generated?: GeneratedFile[];
  meta: {
    createdAt: string;
    createdBy: string;
    tool: string;
  };
}

export interface FragmentReference {
  id: string;                    // glyph ID
  path: string;                  // where to place in workspace
  contentHash: string;           // verification
  contentSize: number;           // verification
}

export interface GeneratedFile {
  path: string;
  template: string;
  inputs: string[];              // fragment names or IDs
}
