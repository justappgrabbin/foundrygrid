/**
 * Foundry Core - Glyph Serialization
 * 
 * Convert glyphs to/from various formats:
 * - JSON (full metadata)
 * - Inline comments (embedded in source files)
 * - Sidecar files (.glyph.json)
 */

import type { Glyph } from './types.js';

/**
 * Serialize glyph to JSON
 */
export function serializeGlyph(glyph: Glyph): string {
  return JSON.stringify(glyph, null, 2);
}

/**
 * Parse glyph from JSON
 */
export function parseGlyph(json: string): Glyph {
  return JSON.parse(json);
}

/**
 * Generate inline comment header for source files
 * 
 * Format depends on file type.
 */
export function generateInlineHeader(
  glyph: Glyph,
  style: 'javascript' | 'css' | 'html' | 'python' | 'shell'
): string {
  const compact = createCompactMetadata(glyph);
  
  switch (style) {
    case 'javascript':
      return `// ╔═══════════════════════════════════════════════════════════╗
// ║ FOUNDRY GLYPH                                             ║
// ╠═══════════════════════════════════════════════════════════╣
// ║ id: ${compact.id}
// ║ quality: ${compact.quality}${compact.locked ? ' 🔒' : ''}
// ║ origin: ${compact.origin}
// ║ created: ${compact.created}
// ╚═══════════════════════════════════════════════════════════╝

`;

    case 'css':
      return `/*
 * ╔═══════════════════════════════════════════════════════════╗
 * ║ FOUNDRY GLYPH                                             ║
 * ╠═══════════════════════════════════════════════════════════╣
 * ║ id: ${compact.id}
 * ║ quality: ${compact.quality}${compact.locked ? ' 🔒' : ''}
 * ║ origin: ${compact.origin}
 * ║ created: ${compact.created}
 * ╚═══════════════════════════════════════════════════════════╝
 */

`;

    case 'html':
      return `<!--
  ╔═══════════════════════════════════════════════════════════╗
  ║ FOUNDRY GLYPH                                             ║
  ╠═══════════════════════════════════════════════════════════╣
  ║ id: ${compact.id}
  ║ quality: ${compact.quality}${compact.locked ? ' 🔒' : ''}
  ║ origin: ${compact.origin}
  ║ created: ${compact.created}
  ╚═══════════════════════════════════════════════════════════╝
-->

`;

    case 'python':
      return `# ╔═══════════════════════════════════════════════════════════╗
# ║ FOUNDRY GLYPH                                             ║
# ╠═══════════════════════════════════════════════════════════╣
# ║ id: ${compact.id}
# ║ quality: ${compact.quality}${compact.locked ? ' 🔒' : ''}
# ║ origin: ${compact.origin}
# ║ created: ${compact.created}
# ╚═══════════════════════════════════════════════════════════╝

`;

    case 'shell':
      return `# ╔═══════════════════════════════════════════════════════════╗
# ║ FOUNDRY GLYPH                                             ║
# ╠═══════════════════════════════════════════════════════════╣
# ║ id: ${compact.id}
# ║ quality: ${compact.quality}${compact.locked ? ' 🔒' : ''}
# ║ origin: ${compact.origin}
# ║ created: ${compact.created}
# ╚═══════════════════════════════════════════════════════════╝

`;
  }
}

/**
 * Create compact metadata for inline headers
 */
function createCompactMetadata(glyph: Glyph) {
  // Shorten glyph ID for readability
  const shortId = glyph.id.replace('sha256:', '').slice(0, 16) + '...';
  
  // Origin summary
  let originSummary: string;
  switch (glyph.origin.type) {
    case 'imported':
      originSummary = 'imported';
      break;
    case 'assembled':
      originSummary = `assembled (${glyph.origin.parents?.length || 0} fragments)`;
      break;
    case 'derived':
      originSummary = 'derived';
      break;
  }
  
  // Check if locked (production with attestations)
  const locked = glyph.quality === 'production' && (glyph.attestations?.length || 0) > 0;
  
  return {
    id: shortId,
    quality: glyph.quality,
    origin: originSummary,
    created: glyph.createdAt.split('T')[0], // Just the date
    locked,
  };
}

/**
 * Embed glyph in source content
 */
export function embedGlyph(
  content: string,
  glyph: Glyph,
  fileType: string
): string {
  const ext = fileType.toLowerCase();
  
  let style: 'javascript' | 'css' | 'html' | 'python' | 'shell';
  
  if (ext.match(/\.(js|jsx|ts|tsx|mjs|cjs)$/)) {
    style = 'javascript';
  } else if (ext.match(/\.(css|scss|sass|less)$/)) {
    style = 'css';
  } else if (ext.match(/\.(html|xml|svg)$/)) {
    style = 'html';
  } else if (ext.match(/\.(py|pyw)$/)) {
    style = 'python';
  } else if (ext.match(/\.(sh|bash|zsh)$/)) {
    style = 'shell';
  } else {
    // Default to JavaScript-style for unknown types
    style = 'javascript';
  }
  
  const header = generateInlineHeader(glyph, style);
  return header + content;
}

/**
 * Extract glyph from embedded content
 * Returns glyph ID if found, null otherwise
 */
export function extractGlyphId(content: string): string | null {
  // Look for glyph ID in any comment style
  const patterns = [
    /\/\/.*id:\s*(sha256:[a-f0-9]+)/i,      // JavaScript
    /\/\*.*id:\s*(sha256:[a-f0-9]+)/is,     // CSS
    /<!--.*id:\s*(sha256:[a-f0-9]+)/is,     // HTML
    /#.*id:\s*(sha256:[a-f0-9]+)/i,         // Python/Shell
  ];
  
  for (const pattern of patterns) {
    const match = content.match(pattern);
    if (match) {
      return match[1];
    }
  }
  
  return null;
}

/**
 * Generate sidecar filename for glyph metadata
 */
export function sidecarFilename(originalFilename: string): string {
  return `${originalFilename}.glyph.json`;
}

/**
 * Create sidecar file content
 */
export function createSidecarContent(glyph: Glyph): string {
  return serializeGlyph(glyph);
}
