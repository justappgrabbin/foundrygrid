/**
 * Foundry Core - Content Normalization
 * 
 * CRITICAL: These functions MUST be deterministic.
 * Same input → same output, always.
 * 
 * Timestamps, randomness, and I/O are FORBIDDEN.
 */

/**
 * Normalize text content for deterministic hashing
 * 
 * Rules:
 * 1. Normalize line endings (CRLF → LF)
 * 2. Trim trailing whitespace on each line
 * 3. Ensure exactly one trailing newline
 */
export function normalizeText(content: string): string {
  return content
    .replace(/\r\n/g, '\n')           // CRLF → LF
    .replace(/[ \t]+$/gm, '')         // Remove trailing whitespace per line
    .replace(/\n+$/g, '')             // Remove all trailing newlines
    + '\n';                            // Add exactly one trailing newline
}

/**
 * Normalize binary content (no-op, use raw bytes)
 */
export function normalizeBinary(content: Buffer): Buffer {
  return content;
}

/**
 * Normalize manifest (package.json, etc.) for deterministic hashing
 * 
 * Rules:
 * 1. Sort all object keys recursively
 * 2. Preserve arrays as-is (order matters for dependencies)
 * 3. Remove undefined values
 */
export function normalizeManifest(manifest: Record<string, unknown>): Record<string, unknown> {
  return sortKeysDeep(manifest);
}

/**
 * Recursively sort object keys for deterministic JSON serialization
 */
function sortKeysDeep(obj: unknown): unknown {
  // Null or undefined
  if (obj === null || obj === undefined) {
    return obj;
  }
  
  // Primitives
  if (typeof obj !== 'object') {
    return obj;
  }
  
  // Arrays - preserve order, but sort contents
  if (Array.isArray(obj)) {
    return obj.map(sortKeysDeep);
  }
  
  // Objects - sort keys
  const sorted: Record<string, unknown> = {};
  const keys = Object.keys(obj).sort();
  
  for (const key of keys) {
    const value = (obj as Record<string, unknown>)[key];
    if (value !== undefined) {
      sorted[key] = sortKeysDeep(value);
    }
  }
  
  return sorted;
}

/**
 * Detect if content is text or binary
 */
export function isTextContent(content: Buffer | string): boolean {
  if (typeof content === 'string') return true;
  
  // Check first 8KB for null bytes (simple binary detection)
  const sample = content.slice(0, 8192);
  for (let i = 0; i < sample.length; i++) {
    if (sample[i] === 0) return false;
  }
  
  return true;
}

/**
 * Normalize content based on type
 */
export function normalizeContent(
  content: string | Buffer,
  options?: { isBinary?: boolean }
): string | Buffer {
  // Explicit binary
  if (options?.isBinary) {
    const buffer = typeof content === 'string' 
      ? Buffer.from(content, 'utf-8')
      : content;
    return normalizeBinary(buffer);
  }
  
  // Detect if binary
  if (Buffer.isBuffer(content) && !isTextContent(content)) {
    return normalizeBinary(content);
  }
  
  // Treat as text
  const text = typeof content === 'string' 
    ? content 
    : content.toString('utf-8');
  
  return normalizeText(text);
}

/**
 * Create canonical JSON string (sorted keys, no whitespace)
 */
export function canonicalJSON(obj: unknown): string {
  const sorted = sortKeysDeep(obj);
  return JSON.stringify(sorted);
}
