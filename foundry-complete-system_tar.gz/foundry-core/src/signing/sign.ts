/**
 * Foundry Core - Cryptographic Signing
 * 
 * Ed25519 signatures for attestations.
 * All functions are pure (except key generation).
 */

import crypto from 'crypto';
import type { SignaturePayload, Attestation } from '../glyph/types.js';
import { canonicalJSON } from '../glyph/normalize.js';

export interface KeyPair {
  publicKey: string;    // base64
  privateKey: string;   // base64
}

/**
 * Generate Ed25519 keypair
 * 
 * NOTE: This is the ONLY non-pure function in the core library.
 * It uses crypto.randomBytes for key generation.
 */
export function generateKeyPair(): KeyPair {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
  
  return {
    publicKey: publicKey.export({ type: 'spki', format: 'der' }).toString('base64'),
    privateKey: privateKey.export({ type: 'pkcs8', format: 'der' }).toString('base64'),
  };
}

/**
 * Sign a payload with Ed25519 private key
 * 
 * Returns base64-encoded signature.
 */
export function sign(
  payload: SignaturePayload,
  privateKeyBase64: string
): string {
  // Create canonical representation (sorted keys)
  const canonical = canonicalJSON(payload);
  
  // Import private key
  const privateKey = crypto.createPrivateKey({
    key: Buffer.from(privateKeyBase64, 'base64'),
    format: 'der',
    type: 'pkcs8',
  });
  
  // Sign
  const signature = crypto.sign(null, Buffer.from(canonical, 'utf-8'), privateKey);
  
  return signature.toString('base64');
}

/**
 * Verify signature with Ed25519 public key
 */
export function verify(
  payload: SignaturePayload,
  signatureBase64: string,
  publicKeyBase64: string
): boolean {
  try {
    // Create canonical representation
    const canonical = canonicalJSON(payload);
    
    // Import public key
    const publicKey = crypto.createPublicKey({
      key: Buffer.from(publicKeyBase64, 'base64'),
      format: 'der',
      type: 'spki',
    });
    
    // Verify
    const signature = Buffer.from(signatureBase64, 'base64');
    return crypto.verify(
      null,
      Buffer.from(canonical, 'utf-8'),
      publicKey,
      signature
    );
  } catch {
    return false;
  }
}

/**
 * Create attestation for glyph promotion
 */
export function createAttestation(
  glyphId: string,
  quality: 'tested' | 'production',
  privateKey: string,
  signer: string,
  evidence?: string
): Attestation {
  const timestamp = new Date().toISOString();
  
  const payload: SignaturePayload = {
    glyphId,
    quality,
    timestamp,
    ...(evidence && { evidence }),
  };
  
  const signature = sign(payload, privateKey);
  
  return {
    quality,
    signer,
    signature,
    signedAt: timestamp,
    ...(evidence && { evidence }),
  };
}

/**
 * Verify attestation signature
 */
export function verifyAttestation(
  attestation: Attestation,
  glyphId: string,
  publicKey: string
): boolean {
  const payload: SignaturePayload = {
    glyphId,
    quality: attestation.quality,
    timestamp: attestation.signedAt,
    ...(attestation.evidence && { evidence: attestation.evidence }),
  };
  
  return verify(payload, attestation.signature, publicKey);
}

/**
 * Format public key for display
 */
export function formatPublicKey(publicKeyBase64: string, userId: string): string {
  const hash = crypto
    .createHash('sha256')
    .update(Buffer.from(publicKeyBase64, 'base64'))
    .digest('hex')
    .slice(0, 8);
  
  return `ed25519:user:${userId}:${hash}`;
}
