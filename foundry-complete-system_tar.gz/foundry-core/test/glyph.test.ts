/**
 * Foundry Core - Glyph Tests
 * 
 * Critical properties to verify:
 * 1. Determinism: same input → same output, always
 * 2. Uniqueness: different inputs → different outputs
 * 3. Integrity: glyph ID matches computed ID
 * 4. Immutability: timestamps excluded from ID
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  createGlyph,
  computeContentHash,
  recomputeGlyphId,
  verifyGlyphIntegrity,
  deriveGlyph,
  normalizeText,
  normalizeBinary,
  normalizeManifest,
  type FragmentInput,
} from '../src/index.js';

// Test fixtures
const testContent = `export function Button() {
  return <button>Click me</button>;
}`;

const testProducer = {
  userId: 'test-user',
  tool: 'foundry-core/test',
  environment: 'node/20.11.0',
};

test('normalization: text content is deterministic', () => {
  const input1 = 'hello\r\nworld\n';
  const input2 = 'hello\nworld\r\n';
  const input3 = 'hello\nworld   \n\n\n';
  
  const norm1 = normalizeText(input1);
  const norm2 = normalizeText(input2);
  const norm3 = normalizeText(input3);
  
  assert.equal(norm1, norm2);
  assert.equal(norm2, norm3);
  assert.equal(norm1, 'hello\nworld\n');
});

test('normalization: binary content is unchanged', () => {
  const buffer = Buffer.from([0x00, 0x01, 0xFF, 0xAB]);
  const normalized = normalizeBinary(buffer);
  
  assert.deepEqual(normalized, buffer);
  assert.notEqual(normalized, buffer); // Different reference
});

test('normalization: manifest keys are sorted', () => {
  const manifest1 = { z: 1, a: 2, m: 3 };
  const manifest2 = { a: 2, m: 3, z: 1 };
  
  const norm1 = normalizeManifest(manifest1);
  const norm2 = normalizeManifest(manifest2);
  
  assert.deepEqual(norm1, norm2);
  assert.deepEqual(Object.keys(norm1), ['a', 'm', 'z']);
});

test('content hash: deterministic for same content', () => {
  const hash1 = computeContentHash({ content: testContent });
  const hash2 = computeContentHash({ content: testContent });
  
  assert.equal(hash1, hash2);
  assert.match(hash1, /^sha256:[a-f0-9]{64}$/);
});

test('content hash: different for different content', () => {
  const hash1 = computeContentHash({ content: 'hello' });
  const hash2 = computeContentHash({ content: 'world' });
  
  assert.notEqual(hash1, hash2);
});

test('content hash: includes manifest', () => {
  const hashWithout = computeContentHash({ content: testContent });
  const hashWith = computeContentHash({ 
    content: testContent,
    manifest: { name: 'test' }
  });
  
  assert.notEqual(hashWithout, hashWith);
});

test('glyph creation: deterministic ID', () => {
  const input: FragmentInput = {
    content: testContent,
    producer: testProducer,
  };
  
  const glyph1 = createGlyph(input);
  const glyph2 = createGlyph(input);
  
  // IDs should match
  assert.equal(glyph1.id, glyph2.id);
  assert.equal(glyph1.contentHash, glyph2.contentHash);
  
  // Timestamps will differ (excluded from ID)
  // But that's okay - ID is still the same
});

test('glyph creation: different content yields different ID', () => {
  const glyph1 = createGlyph({
    content: 'hello',
    producer: testProducer,
  });
  
  const glyph2 = createGlyph({
    content: 'world',
    producer: testProducer,
  });
  
  assert.notEqual(glyph1.id, glyph2.id);
  assert.notEqual(glyph1.contentHash, glyph2.contentHash);
});

test('glyph integrity: recomputed ID matches', () => {
  const glyph = createGlyph({
    content: testContent,
    producer: testProducer,
  });
  
  const recomputed = recomputeGlyphId(glyph);
  assert.equal(recomputed, glyph.id);
  assert.equal(verifyGlyphIntegrity(glyph), true);
});

test('glyph integrity: detects tampering', () => {
  const glyph = createGlyph({
    content: testContent,
    producer: testProducer,
  });
  
  // Tamper with quality
  glyph.quality = 'production';
  
  // ID should no longer match
  assert.equal(verifyGlyphIntegrity(glyph), false);
});

test('derived glyph: same content, different lineage', () => {
  const original = createGlyph({
    content: testContent,
    producer: testProducer,
    quality: 'production',
  });
  
  const derived = deriveGlyph(original, {
    producer: testProducer,
    quality: 'draft',
  });
  
  // Same content
  assert.equal(derived.contentHash, original.contentHash);
  
  // Different IDs (different lineage + quality)
  assert.notEqual(derived.id, original.id);
  
  // Correct origin
  assert.equal(derived.origin.type, 'derived');
  assert.deepEqual(derived.origin.parents, [original.id]);
});

test('glyph: timestamps excluded from ID', async () => {
  // Create two glyphs with delay between them
  const glyph1 = createGlyph({
    content: testContent,
    producer: testProducer,
  });
  
  // Wait a bit
  await new Promise(resolve => setTimeout(resolve, 10));
  
  const glyph2 = createGlyph({
    content: testContent,
    producer: testProducer,
  });
  
  // Different timestamps
  assert.notEqual(glyph1.createdAt, glyph2.createdAt);
  
  // Same IDs (timestamps excluded)
  assert.equal(glyph1.id, glyph2.id);
});

test('glyph: parent order doesnt matter', () => {
  const parent1 = 'sha256:aaa';
  const parent2 = 'sha256:bbb';
  
  const glyph1 = createGlyph({
    content: testContent,
    producer: testProducer,
    origin: {
      type: 'assembled',
      parents: [parent1, parent2],
    },
  });
  
  const glyph2 = createGlyph({
    content: testContent,
    producer: testProducer,
    origin: {
      type: 'assembled',
      parents: [parent2, parent1], // Reversed
    },
  });
  
  // Should produce same ID (parents are sorted)
  assert.equal(glyph1.id, glyph2.id);
});

test('glyph: quality affects ID', () => {
  const draft = createGlyph({
    content: testContent,
    producer: testProducer,
    quality: 'draft',
  });
  
  const production = createGlyph({
    content: testContent,
    producer: testProducer,
    quality: 'production',
  });
  
  assert.notEqual(draft.id, production.id);
});

test('schema version: always 1', () => {
  const glyph = createGlyph({
    content: testContent,
    producer: testProducer,
  });
  
  assert.equal(glyph.schemaVersion, 1);
});
