/**
 * Foundry Overseer - Trust + Oversight
 * 
 * Philosophy: Let the system work. Only flag anomalies.
 * 
 * NOT a gatekeeper. NOT a blocker.
 * Just watches and warns.
 */

export interface Glyph {
  id: string;
  contentHash: string;
  contentSize: number;
  quality: 'draft' | 'tested' | 'production' | 'archived';
  origin: {
    type: 'imported' | 'assembled' | 'derived';
    parents?: string[];
    changes?: string[];
    reason?: string;
  };
  producer: {
    userId: string;
    tool: string;
    environment: string;
    humanReadable?: string;
  };
  createdAt: string;
}

export interface BuildResult {
  newGlyph: string;
  baseGlyph?: string;
  producer: string;
  changes: string[];
  reason: string;
  createdAt: string;
}

export interface Review {
  safe: boolean;
  severity: 'ok' | 'info' | 'warning' | 'error';
  warnings: Warning[];
  lineage: Lineage;
  recommendation?: string;
}

export interface Warning {
  severity: 'info' | 'warning' | 'error';
  message: string;
  detail?: string;
}

export interface Lineage {
  original?: string;
  parent?: string;
  current: string;
  createdBy: string;
  changes: string[];
  depth: number; // How many derivations deep
}

/**
 * Review a build result
 * 
 * Returns warnings, but does NOT block.
 */
export function review(
  result: BuildResult,
  getGlyph: (id: string) => Glyph | null
): Review {
  const warnings: Warning[] = [];
  const newGlyph = getGlyph(result.newGlyph);
  
  if (!newGlyph) {
    return {
      safe: false,
      severity: 'error',
      warnings: [{
        severity: 'error',
        message: 'Cannot review - new glyph not found',
      }],
      lineage: {
        current: result.newGlyph,
        createdBy: result.producer,
        changes: result.changes,
        depth: 0,
      },
    };
  }
  
  // Build lineage
  const lineage = buildLineage(newGlyph, getGlyph);
  
  // Check: Too many changes?
  if (result.changes.length > 5) {
    warnings.push({
      severity: 'warning',
      message: `Many changes made (${result.changes.length})`,
      detail: 'Review recommended - unusual number of modifications',
    });
  }
  
  // Check: Different author?
  if (lineage.parent) {
    const parent = getGlyph(lineage.parent);
    if (parent && parent.producer.userId !== newGlyph.producer.userId) {
      warnings.push({
        severity: 'info',
        message: `Modified by different author`,
        detail: `Original: ${parent.producer.userId}, Modified: ${newGlyph.producer.userId}`,
      });
    }
  }
  
  // Check: Size exploded?
  if (lineage.parent) {
    const parent = getGlyph(lineage.parent);
    if (parent && newGlyph.contentSize > parent.contentSize * 3) {
      warnings.push({
        severity: 'warning',
        message: 'Size increased significantly',
        detail: `${parent.contentSize} → ${newGlyph.contentSize} bytes (${Math.round(newGlyph.contentSize / parent.contentSize)}x)`,
      });
    }
  }
  
  // Check: Deep derivation chain?
  if (lineage.depth > 5) {
    warnings.push({
      severity: 'warning',
      message: 'Deep derivation chain',
      detail: `${lineage.depth} levels deep - consider consolidating`,
    });
  }
  
  // Check: Production modified?
  if (lineage.parent) {
    const parent = getGlyph(lineage.parent);
    if (parent && parent.quality === 'production') {
      warnings.push({
        severity: 'info',
        message: 'Derived from production glyph',
        detail: `Parent ${lineage.parent} is locked production`,
      });
    }
  }
  
  // Check: System producer (selector/builder)?
  if (newGlyph.producer.userId.startsWith('foundry-')) {
    warnings.push({
      severity: 'info',
      message: 'Created by system component',
      detail: `Producer: ${newGlyph.producer.userId}`,
    });
  }
  
  // Determine overall safety
  const hasErrors = warnings.some(w => w.severity === 'error');
  const hasWarnings = warnings.some(w => w.severity === 'warning');
  
  const severity = hasErrors ? 'error' : hasWarnings ? 'warning' : warnings.length > 0 ? 'info' : 'ok';
  
  return {
    safe: !hasErrors,
    severity,
    warnings,
    lineage,
    recommendation: getRecommendation(warnings, lineage),
  };
}

/**
 * Build lineage chain
 */
function buildLineage(
  glyph: Glyph,
  getGlyph: (id: string) => Glyph | null
): Lineage {
  const parent = glyph.origin.parents?.[0];
  
  // Find original (traverse parent chain)
  let original = glyph.id;
  let current = glyph;
  let depth = 0;
  
  while (current.origin.parents && current.origin.parents.length > 0) {
    const parentId = current.origin.parents[0];
    const parentGlyph = getGlyph(parentId);
    
    if (!parentGlyph) break;
    
    original = parentId;
    current = parentGlyph;
    depth++;
    
    // Prevent infinite loops
    if (depth > 100) break;
  }
  
  return {
    original: original !== glyph.id ? original : undefined,
    parent,
    current: glyph.id,
    createdBy: glyph.producer.userId,
    changes: glyph.origin.changes || [],
    depth,
  };
}

/**
 * Get recommendation based on warnings
 */
function getRecommendation(warnings: Warning[], lineage: Lineage): string | undefined {
  const hasWarnings = warnings.some(w => w.severity === 'warning');
  const hasErrors = warnings.some(w => w.severity === 'error');
  
  if (hasErrors) {
    return 'Review required - errors detected';
  }
  
  if (hasWarnings) {
    return 'Review recommended - unusual patterns detected';
  }
  
  if (lineage.depth > 3) {
    return 'Consider consolidating derivation chain';
  }
  
  return undefined;
}

/**
 * Format review for display
 */
export function formatReview(review: Review): string {
  const lines: string[] = [];
  
  lines.push(`Review: ${review.severity.toUpperCase()}`);
  lines.push(`Safe: ${review.safe ? 'YES' : 'NO'}`);
  lines.push('');
  
  lines.push('Lineage:');
  if (review.lineage.original) {
    lines.push(`  Original: ${review.lineage.original}`);
  }
  if (review.lineage.parent) {
    lines.push(`  Parent: ${review.lineage.parent}`);
  }
  lines.push(`  Current: ${review.lineage.current}`);
  lines.push(`  Created by: ${review.lineage.createdBy}`);
  lines.push(`  Depth: ${review.lineage.depth} levels`);
  
  if (review.lineage.changes.length > 0) {
    lines.push('');
    lines.push('Changes:');
    review.lineage.changes.forEach(change => {
      lines.push(`  - ${change}`);
    });
  }
  
  if (review.warnings.length > 0) {
    lines.push('');
    lines.push('Warnings:');
    review.warnings.forEach(w => {
      const prefix = w.severity === 'error' ? '✗' : w.severity === 'warning' ? '⚠' : 'ℹ';
      lines.push(`  ${prefix} ${w.message}`);
      if (w.detail) {
        lines.push(`    ${w.detail}`);
      }
    });
  }
  
  if (review.recommendation) {
    lines.push('');
    lines.push(`Recommendation: ${review.recommendation}`);
  }
  
  return lines.join('\n');
}
