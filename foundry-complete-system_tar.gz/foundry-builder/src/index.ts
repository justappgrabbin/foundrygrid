/**
 * Foundry Builder - Public API
 * 
 * Phase 3: Mutation Layer
 * 
 * ONLY exports:
 * - buildApp() - The one function that matters
 * - Types for inputs/outputs
 * 
 * Does NOT export:
 * - Internal filler generators
 * - Fork logic
 * - Helpers
 */

export { buildApp } from './builder.js';
export type {
  ApprovedChangeRequest,
  BuildResult,
  BuildProvenance,
  GeneratedFiller,
} from './types.js';
export { requireApproval, isApproved } from './types.js';
