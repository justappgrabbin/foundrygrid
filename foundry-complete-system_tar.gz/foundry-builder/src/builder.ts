/**
 * Foundry Builder - Core Builder
 * 
 * The ONE function that can mutate:
 * - buildApp(cr: ApprovedChangeRequest): BuildResult
 * 
 * Everything else is read-only.
 */

import type {
  ApprovedChangeRequest,
  BuildResult,
  BuildProvenance,
  GeneratedFiller,
  AppContent,
} from './types.js';
import { requireApproval } from './types.js';
import { forkApp } from './fork.js';
import { generateFillers } from './fillers/index.js';
import { createGlyph } from '@foundry/core';

/**
 * Build app from approved change request.
 * 
 * CRITICAL INVARIANTS:
 * 1. Only accepts ApprovedChangeRequest
 * 2. Always creates new glyph (never mutates)
 * 3. Records complete provenance
 * 4. No inference - only executes what's in CR
 * 
 * @throws if CR is not approved
 */
export async function buildApp(
  cr: ApprovedChangeRequest,
  getAppContent: (glyphId: string) => Promise<AppContent>
): Promise<BuildResult> {
  // GATE: Verify approval (throws if not approved)
  requireApproval(cr);
  
  // Get base app content
  const baseApp = await getAppContent(cr.targetApp);
  
  if (baseApp.metadata.locked) {
    throw new Error(
      `Cannot modify locked app: ${cr.targetApp}. ` +
      `Locked apps must be forked first.`
    );
  }
  
  // Fork app (creates new lineage)
  const forked = forkApp(baseApp, cr);
  
  // Generate fillers based on what's missing
  const fillers = generateFillers(cr.missing);
  
  // Apply fillers to forked content
  const enhanced = applyFillers(forked, fillers);
  
  // Create new app glyph
  const newGlyph = await createAppGlyph(enhanced);
  
  // Build provenance
  const provenance: BuildProvenance = {
    changeRequest: `${cr.type}:${cr.targetApp}`,
    baseApp: cr.targetApp,
    approvedBy: cr.approvedBy!,
    approvedAt: cr.approvedAt!,
    buildType: determineBuildType(cr.type),
    reason: cr.reason,
  };
  
  return {
    newAppGlyph: newGlyph.id,
    parents: [cr.targetApp],
    provenance,
    fillers,
    created: new Date().toISOString(),
  };
}

/**
 * Apply fillers to app content
 */
function applyFillers(
  app: AppContent,
  fillers: GeneratedFiller[]
): AppContent {
  const enhanced = {
    ...app,
    files: new Map(app.files),
  };
  
  for (const filler of fillers) {
    enhanced.files.set(filler.filename, filler.content);
  }
  
  return enhanced;
}

/**
 * Create app glyph from content
 */
async function createAppGlyph(content: AppContent) {
  // Combine all files into single content blob
  const combined = Array.from(content.files.entries())
    .map(([path, code]) => `// ${path}\n${code}`)
    .join('\n\n');
  
  return createGlyph({
    content: combined,
    quality: 'draft', // New builds always start as draft
    producer: {
      userId: 'foundry-builder',
      tool: 'foundry-builder',
      environment: 'node/20',
    },
  });
}

/**
 * Determine build type from CR type
 */
function determineBuildType(
  crType: string
): 'personalization' | 'fork' | 'gap-fill' {
  switch (crType) {
    case 'ADD_FILLERS':
      return 'gap-fill';
    case 'FORK_APP':
      return 'fork';
    case 'PERSONALIZE':
      return 'personalization';
    default:
      return 'gap-fill';
  }
}

// ============================================================================
// Enforcement: No other functions can create glyphs
// ============================================================================

/**
 * Builder does NOT do these things:
 * 
 * ✗ Detect gaps (that's Phase 1)
 * ✗ Suggest changes (that's Phase 1)
 * ✗ Approve requests (that's Phase 2)
 * ✗ Infer missing pieces (only executes CR)
 * ✗ Optimize or improve (deterministic only)
 * 
 * Builder ONLY:
 * ✓ Accepts approved CR
 * ✓ Forks base app
 * ✓ Generates specified fillers
 * ✓ Creates new glyph
 * ✓ Records provenance
 */
