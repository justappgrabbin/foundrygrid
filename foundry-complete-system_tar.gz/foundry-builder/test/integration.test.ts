/**
 * Foundry Builder - Integration Tests
 * 
 * These tests prove the phase boundaries cannot be violated.
 */

import { describe, it } from 'node:test';
import assert from 'node:assert';
import { buildApp } from '../dist/builder.js';
import type { ChangeRequest, ApprovedChangeRequest, AppContent } from '../dist/types.js';
import { isApproved } from '../dist/types.js';

// ============================================================================
// Test: Unapproved CR is rejected
// ============================================================================

describe('Phase Boundary Enforcement', () => {
  it('rejects unapproved change request', async () => {
    const unapproved: ChangeRequest = {
      type: 'ADD_FILLERS',
      targetApp: 'sha256:test-app',
      missing: ['routing'],
      requestedBy: 'system',
      reason: 'Test',
      approved: false,
    };
    
    const getApp = async () => mockAppContent();
    
    await assert.rejects(
      async () => buildApp(unapproved as any, getApp),
      /not approved/,
      'Should reject unapproved CR'
    );
  });
  
  it('accepts approved change request', async () => {
    const approved: ApprovedChangeRequest = {
      type: 'ADD_FILLERS',
      targetApp: 'sha256:test-app',
      missing: ['routing'],
      requestedBy: 'system',
      reason: 'Test',
      approved: true,
      approvedBy: 'test-user',
      approvedAt: new Date().toISOString(),
    };
    
    const getApp = async () => mockAppContent();
    
    const result = await buildApp(approved, getApp);
    
    assert.ok(result.newAppGlyph, 'Should create new glyph');
    assert.strictEqual(result.parents[0], 'sha256:test-app', 'Should track parent');
  });
});

// ============================================================================
// Test: Type guard works correctly
// ============================================================================

describe('Approval Type Guard', () => {
  it('identifies unapproved CR', () => {
    const cr: ChangeRequest = {
      type: 'ADD_FILLERS',
      targetApp: 'sha256:test',
      missing: [],
      requestedBy: 'system',
      reason: 'Test',
      approved: false,
    };
    
    assert.strictEqual(isApproved(cr), false);
  });
  
  it('identifies approved CR', () => {
    const cr: ApprovedChangeRequest = {
      type: 'ADD_FILLERS',
      targetApp: 'sha256:test',
      missing: [],
      requestedBy: 'system',
      reason: 'Test',
      approved: true,
      approvedBy: 'user',
      approvedAt: new Date().toISOString(),
    };
    
    assert.strictEqual(isApproved(cr), true);
  });
  
  it('rejects fake approval (missing approvedBy)', () => {
    const fake: any = {
      type: 'ADD_FILLERS',
      targetApp: 'sha256:test',
      missing: [],
      requestedBy: 'system',
      reason: 'Test',
      approved: true,
      // Missing approvedBy and approvedAt
    };
    
    assert.strictEqual(isApproved(fake), false);
  });
});

// ============================================================================
// Test: Builder creates new glyph (never mutates)
// ============================================================================

describe('Immutability Enforcement', () => {
  it('creates new glyph instead of mutating', async () => {
    const approved: ApprovedChangeRequest = {
      type: 'ADD_FILLERS',
      targetApp: 'sha256:original',
      missing: ['routing'],
      requestedBy: 'system',
      reason: 'Test',
      approved: true,
      approvedBy: 'test-user',
      approvedAt: new Date().toISOString(),
    };
    
    const getApp = async () => mockAppContent();
    
    const result = await buildApp(approved, getApp);
    
    assert.notStrictEqual(
      result.newAppGlyph,
      'sha256:original',
      'Should create NEW glyph, not mutate original'
    );
  });
  
  it('rejects mutation of locked apps', async () => {
    const approved: ApprovedChangeRequest = {
      type: 'ADD_FILLERS',
      targetApp: 'sha256:locked-app',
      missing: ['routing'],
      requestedBy: 'system',
      reason: 'Test',
      approved: true,
      approvedBy: 'test-user',
      approvedAt: new Date().toISOString(),
    };
    
    const getApp = async () => ({
      ...mockAppContent(),
      metadata: {
        ...mockAppContent().metadata,
        locked: true,
      },
    });
    
    await assert.rejects(
      async () => buildApp(approved, getApp),
      /locked app/,
      'Should reject mutation of locked apps'
    );
  });
});

// ============================================================================
// Test: Provenance is recorded
// ============================================================================

describe('Provenance Tracking', () => {
  it('records complete provenance', async () => {
    const approved: ApprovedChangeRequest = {
      type: 'ADD_FILLERS',
      targetApp: 'sha256:base',
      missing: ['routing'],
      requestedBy: 'system',
      reason: 'Missing routing capability',
      approved: true,
      approvedBy: 'alice',
      approvedAt: '2025-01-01T00:00:00Z',
    };
    
    const getApp = async () => mockAppContent();
    
    const result = await buildApp(approved, getApp);
    
    assert.strictEqual(result.provenance.baseApp, 'sha256:base');
    assert.strictEqual(result.provenance.approvedBy, 'alice');
    assert.strictEqual(result.provenance.approvedAt, '2025-01-01T00:00:00Z');
    assert.strictEqual(result.provenance.buildType, 'gap-fill');
    assert.strictEqual(result.provenance.reason, 'Missing routing capability');
  });
});

// ============================================================================
// Test Helpers
// ============================================================================

function mockAppContent(): AppContent {
  return {
    files: new Map([
      ['src/App.tsx', 'export function App() { return <div>App</div>; }'],
      ['package.json', '{"name": "test-app"}'],
    ]),
    metadata: {
      appGlyph: 'sha256:test-app',
      quality: 'draft',
      capabilities: ['ui'],
      locked: false,
    },
  };
}
