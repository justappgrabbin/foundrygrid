# Foundry Builder (Phase 3)

**Mutation Layer - Approved Changes Only**

---

## What This Is

The **only** module in the Foundry system that can create new glyphs.

Everything else observes.  
Only the builder mutates.  
And it only mutates when explicitly approved.

---

## The One Function That Matters

```typescript
buildApp(
  cr: ApprovedChangeRequest,
  getAppContent: (glyphId: string) => Promise<AppContent>
): Promise<BuildResult>
```

That's it.

---

## How Approval Works

### Type-Level Enforcement

```typescript
type ApprovedChangeRequest = ChangeRequest & {
  approved: true;        // Literal type, not boolean
  approvedAt: string;    // Required
  approvedBy: string;    // Required
};
```

You cannot fake this type.  
You cannot cast to it.  
You cannot construct it without approval.

### Runtime Enforcement

```typescript
export function requireApproval(cr: ChangeRequest): asserts cr is ApprovedChangeRequest {
  if (!isApproved(cr)) {
    throw new Error('Change request not approved');
  }
}
```

First line of `buildApp()` calls this.  
If it throws, nothing else runs.  
No flags. No if statements. Just: approval or abort.

---

## What Builder Does (Exactly)

### Input
```typescript
{
  type: 'ADD_FILLERS',
  targetApp: 'sha256:app123',
  missing: ['routing', 'error-handling'],
  approved: true,
  approvedBy: 'alice',
  approvedAt: '2025-01-01T00:00:00Z'
}
```

### Process
1. Verify approval (throws if missing)
2. Fork base app (creates new lineage)
3. Generate fillers for `missing` array
4. Apply fillers to forked content
5. Create new app glyph
6. Record complete provenance

### Output
```typescript
{
  newAppGlyph: 'sha256:new-app',
  parents: ['sha256:app123'],
  provenance: {
    changeRequest: 'ADD_FILLERS:sha256:app123',
    baseApp: 'sha256:app123',
    approvedBy: 'alice',
    approvedAt: '2025-01-01T00:00:00Z',
    buildType: 'gap-fill',
    reason: 'Missing routing capability'
  },
  fillers: [
    {
      type: 'routing',
      filename: 'src/Router.tsx',
      content: '...',
      reason: 'App needs routing between pages',
      generated: true
    }
  ],
  created: '2025-01-01T00:01:00Z'
}
```

---

## What Builder Does NOT Do

❌ Detect gaps (that's Phase 1 - selector)  
❌ Suggest changes (that's Phase 1)  
❌ Approve requests (that's Phase 2)  
❌ Infer missing pieces (only executes CR)  
❌ Optimize or improve (deterministic only)  

Builder is **dumb**.  
Selector is **smart**.  
This is intentional.

---

## Generated Fillers

When missing capabilities are detected, builder generates:

### `routing` → `src/Router.tsx`
```tsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';

export function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
      </Routes>
    </BrowserRouter>
  );
}
```

### `error-handling` → `src/ErrorBoundary.tsx`
```tsx
export class ErrorBoundary extends React.Component {
  // Catches errors, shows fallback UI
}
```

### `boot` → `src/index.tsx`
```tsx
import { App } from './App';
import { ErrorBoundary } from './ErrorBoundary';

root.render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);
```

### `state-management` → `src/state.tsx`
```tsx
export function AppStateProvider({ children }) {
  // Context-based state management
}
```

---

## Immutability Guarantee

Builder **never** mutates existing glyphs.

### Always:
- Forks base app
- Creates new glyph
- Records lineage
- Returns new ID

### Never:
- Modifies in place
- Overwrites files
- Mutates metadata
- Loses history

---

## Locked Apps

Production apps are locked:

```typescript
if (baseApp.metadata.locked) {
  throw new Error('Cannot modify locked app');
}
```

To modify a locked app:
1. Fork it (allowed)
2. Modify the fork (allowed)
3. Promote fork to production (separate flow)

Original locked app remains untouched.

---

## Integration Test (Proof of Enforcement)

```typescript
// Test 1: Unapproved CR is rejected
const unapproved = {
  type: 'ADD_FILLERS',
  targetApp: 'sha256:app',
  missing: ['routing'],
  approved: false
};

await assert.rejects(
  () => buildApp(unapproved),
  /not approved/
);

// Test 2: Approved CR succeeds
const approved = {
  ...unapproved,
  approved: true,
  approvedBy: 'alice',
  approvedAt: '2025-01-01T00:00:00Z'
};

const result = await buildApp(approved);
assert.ok(result.newAppGlyph);

// Test 3: Fake approval fails
const faked = {
  ...unapproved,
  approved: true
  // Missing approvedBy, approvedAt
};

assert.strictEqual(isApproved(faked), false);
```

Run tests:
```bash
npm test
```

All tests must pass. No exceptions.

---

## Usage Example

```typescript
import { buildApp } from '@foundry/builder';
import { selectApp, createFillerRequest, approveRequest } from '@foundry/selector';

// Phase 1: Select app
const selection = selectApp(apps, userProfile);
console.log('Missing:', selection.missing);

// Phase 2: Create + approve CR
const cr = createFillerRequest(
  selection.selectedApp,
  selection.missing,
  'User needs these capabilities'
);

const approved = approveRequest(cr, 'user-alice');

// Phase 3: Build
const result = await buildApp(approved, getAppContent);

console.log('New app:', result.newAppGlyph);
console.log('Fillers added:', result.fillers.length);
```

---

## Phase Boundaries Summary

| Phase | Module | Responsibility |
|-------|--------|----------------|
| 1 | Selector | Observe, detect, explain |
| 2 | Change Request | Gate, approve |
| 3 | **Builder** | Fork, generate, create |

Builder cannot act without Phase 2 approval.  
Phase 2 cannot act without Phase 1 detection.  
Phase 1 cannot mutate.

**This is enforced at compile time and runtime.**

---

## Status

✅ Type-level enforcement  
✅ Runtime checks  
✅ Integration tests  
✅ Immutability guaranteed  
✅ Provenance tracked  
✅ Locked app protection  

**The builder cannot misbehave.**

---

## Files

```
foundry-builder/
├── src/
│   ├── types.ts          # ApprovedChangeRequest, BuildResult
│   ├── builder.ts        # buildApp() - the one function
│   ├── fork.ts           # App forking logic
│   ├── fillers/
│   │   └── index.ts      # Filler generators
│   └── index.ts          # Public API
├── test/
│   └── integration.test.ts  # Enforcement tests
└── README.md
```

---

**The mutation layer is locked down.**  
**The phase boundaries are enforced.**  
**The system is safe.**
