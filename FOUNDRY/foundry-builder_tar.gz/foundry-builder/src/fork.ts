/**
 * Foundry Builder - App Forking
 * 
 * Creates new app with lineage tracked to parent.
 */

import type { ApprovedChangeRequest, AppContent } from './types.js';

/**
 * Fork app - creates new lineage
 * 
 * Forking:
 * - Copies all files
 * - Resets quality to draft
 * - Unlocks (forked apps are never locked)
 * - Records parent in origin
 */
export function forkApp(
  baseApp: AppContent,
  cr: ApprovedChangeRequest
): AppContent {
  return {
    files: new Map(baseApp.files), // Deep copy
    metadata: {
      ...baseApp.metadata,
      appGlyph: '', // Will be set when glyph is created
      quality: 'draft', // Forks always start as draft
      locked: false, // Forks are never locked
    },
  };
}

/**
 * Check if app can be forked
 */
export function canFork(app: AppContent): { allowed: boolean; reason?: string } {
  // All apps can be forked (even locked ones)
  // Forking is how you modify locked apps
  return { allowed: true };
}
