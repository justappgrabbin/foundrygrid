/**
 * Foundry Builder - Phase 3 Types
 * 
 * CRITICAL: Builder only accepts ApprovedChangeRequest.
 * Approval is not a boolean you can fake.
 */

// ChangeRequest type - copied from selector to avoid circular dependency
// In production: import from '@foundry/selector'
export interface ChangeRequest {
  type: 'ADD_FILLERS' | 'FORK_APP' | 'PERSONALIZE' | 'MODIFY_STRUCTURE';
  targetApp: string;
  missing: string[];
  requestedBy: 'system' | 'user' | 'policy' | 'admin';
  reason: string;
  approved: boolean;
  approvedBy?: string;
  approvedAt?: string;
  metadata?: Record<string, unknown>;
}

// ============================================================================
// Approved Change Request (The Gate)
// ============================================================================

/**
 * An approved change request.
 * 
 * This type can ONLY be created by approveChangeRequest().
 * The builder cannot create this. The builder cannot fake this.
 */
export type ApprovedChangeRequest = ChangeRequest & {
  approved: true;           // Literal type, not boolean
  approvedAt: string;       // ISO timestamp (required)
  approvedBy: string;       // Actor who approved (required)
};

/**
 * Type guard: check if a CR is approved
 */
export function isApproved(cr: ChangeRequest): cr is ApprovedChangeRequest {
  return (
    cr.approved === true &&
    typeof cr.approvedAt === 'string' &&
    typeof cr.approvedBy === 'string'
  );
}

/**
 * Require approval - throws if not approved
 */
export function requireApproval(cr: ChangeRequest): asserts cr is ApprovedChangeRequest {
  if (!isApproved(cr)) {
    throw new Error(
      `Change request not approved. ` +
      `Type: ${cr.type}, Target: ${cr.targetApp}. ` +
      `All mutations require explicit approval.`
    );
  }
}

// ============================================================================
// Build Result (Always New Glyph)
// ============================================================================

/**
 * Result of building an app.
 * Always creates a NEW glyph. Never mutates existing.
 */
export interface BuildResult {
  newAppGlyph: string;                  // New glyph ID
  parents: string[];                    // Parent app glyphs
  provenance: BuildProvenance;          // How it was created
  fillers: GeneratedFiller[];           // What was added
  created: string;                      // ISO timestamp
}

/**
 * Provenance - lineage and creation context
 */
export interface BuildProvenance {
  changeRequest: string;                // CR that triggered build
  baseApp: string;                      // Original app glyph
  approvedBy: string;                   // Who approved
  approvedAt: string;                   // When approved
  buildType: 'personalization' | 'fork' | 'gap-fill';
  reason: string;                       // Why it was built
}

/**
 * Generated filler - code that was auto-generated
 */
export interface GeneratedFiller {
  type: 'routing' | 'boot' | 'error-boundary' | 'defaults' | 'glue';
  filename: string;                     // Where it lives
  content: string;                      // Generated code
  reason: string;                       // Why it was added
  generated: true;                      // Always true
}

// ============================================================================
// App Content (For Building)
// ============================================================================

/**
 * App content - collection of files
 */
export interface AppContent {
  files: Map<string, string>;           // filename → content
  metadata: AppMetadata;
}

/**
 * App metadata
 */
export interface AppMetadata {
  appGlyph: string;
  quality: 'draft' | 'tested' | 'production' | 'archived';
  capabilities: string[];
  locked: boolean;
}
