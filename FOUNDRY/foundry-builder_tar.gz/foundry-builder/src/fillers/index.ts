/**
 * Foundry Builder - Gap Fillers
 * 
 * Generates system code to fill gaps.
 * ONLY called by builder. NEVER called by selector.
 */

import type { GeneratedFiller } from '../types.js';

/**
 * Generate all fillers for missing capabilities
 */
export function generateFillers(missing: string[]): GeneratedFiller[] {
  const fillers: GeneratedFiller[] = [];
  
  for (const capability of missing) {
    const filler = generateFillerFor(capability);
    if (filler) {
      fillers.push(filler);
    }
  }
  
  return fillers;
}

/**
 * Generate filler for specific capability
 */
function generateFillerFor(capability: string): GeneratedFiller | null {
  switch (capability) {
    case 'routing':
      return generateRouting();
    case 'error-handling':
      return generateErrorBoundary();
    case 'boot':
      return generateBoot();
    case 'state-management':
      return generateStateManagement();
    default:
      // Unknown capability - cannot auto-generate
      return null;
  }
}

/**
 * Generate routing filler
 */
function generateRouting(): GeneratedFiller {
  const content = `// Auto-generated routing (foundry-builder)
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { HomePage } from './pages/Home';
import { DashboardPage } from './pages/Dashboard';

export function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
      </Routes>
    </BrowserRouter>
  );
}
`;
  
  return {
    type: 'routing',
    filename: 'src/Router.tsx',
    content,
    reason: 'App needs routing between pages',
    generated: true,
  };
}

/**
 * Generate error boundary filler
 */
function generateErrorBoundary(): GeneratedFiller {
  const content = `// Auto-generated error boundary (foundry-builder)
import React from 'react';

interface Props {
  children: React.ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('[ErrorBoundary]', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '2rem', textAlign: 'center' }}>
          <h1>Something went wrong</h1>
          <p>{this.state.error?.message}</p>
          <button onClick={() => window.location.reload()}>
            Reload App
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
`;
  
  return {
    type: 'error-boundary',
    filename: 'src/ErrorBoundary.tsx',
    content,
    reason: 'App needs error handling',
    generated: true,
  };
}

/**
 * Generate boot logic filler
 */
function generateBoot(): GeneratedFiller {
  const content = `// Auto-generated boot logic (foundry-builder)
import React from 'react';
import ReactDOM from 'react-dom/client';
import { App } from './App';
import { ErrorBoundary } from './ErrorBoundary';

const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);

console.log('[Foundry App] Initialized');
`;
  
  return {
    type: 'boot',
    filename: 'src/index.tsx',
    content,
    reason: 'App needs initialization code',
    generated: true,
  };
}

/**
 * Generate state management filler
 */
function generateStateManagement(): GeneratedFiller {
  const content = `// Auto-generated state management (foundry-builder)
import { createContext, useContext, useState, ReactNode } from 'react';

interface AppState {
  user: { id: string; name: string } | null;
  theme: 'light' | 'dark';
}

const AppStateContext = createContext<AppState | null>(null);
const AppDispatchContext = createContext<any>(null);

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>({
    user: null,
    theme: 'light',
  });

  return (
    <AppStateContext.Provider value={state}>
      <AppDispatchContext.Provider value={setState}>
        {children}
      </AppDispatchContext.Provider>
    </AppStateContext.Provider>
  );
}

export function useAppState() {
  const context = useContext(AppStateContext);
  if (!context) {
    throw new Error('useAppState must be used within AppStateProvider');
  }
  return context;
}

export function useAppDispatch() {
  const context = useContext(AppDispatchContext);
  if (!context) {
    throw new Error('useAppDispatch must be used within AppStateProvider');
  }
  return context;
}
`;
  
  return {
    type: 'glue',
    filename: 'src/state.tsx',
    content,
    reason: 'App needs state management',
    generated: true,
  };
}
