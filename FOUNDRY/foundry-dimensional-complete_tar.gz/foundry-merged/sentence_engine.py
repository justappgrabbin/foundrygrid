"""
FOUNDRY SENTENCE ENGINE
=======================
Dynamic sentence generation from Gate.Line.Color.Tone.Base + Zodiac + House
Uses the knowledge base as semantic source (NO pre-generated templates)

Sentence Structure:
"[Gate Name] through [Line quality], motivated by [Color], 
 sensing via [Tone], grounded in [Base] environments,
 expressed in [Zodiac Sign] through [House] domain"
 
Author: Celestial
"""

import json
from typing import Dict, Optional, List
from pathlib import Path

class SentenceEngine:
    """
    Generates consciousness sentences dynamically from:
    - Calculated activations (gate.line.color.tone.base)
    - Astrological context (zodiac sign, house, planet)
    - Knowledge base (semantic meanings)
    """
    
    def __init__(self, knowledge_base_path: str):
        """Load the knowledge base"""
        with open(knowledge_base_path, 'r') as f:
            self.kb = json.load(f)
        
        # Extract components
        self.gates = self.kb.get('gates', {})
        self.colors = self.kb.get('colors', {})
        self.tones = self.kb.get('tones', {})
        self.bases = self.kb.get('bases', {})
        self.zodiac_info = self.kb.get('zodiac', {})
        
        print(f"✓ Loaded knowledge base: {len(self.gates)} gates, "
              f"{len(self.colors)} colors, {len(self.tones)} tones, {len(self.bases)} bases")
    
    def generate(self, activation: Dict, style: str = 'complete') -> str:
        """
        Generate sentence from activation data.
        
        activation = {
            'gate': 41,
            'line': 3,
            'color': 2,
            'tone': 5,
            'base': 1,
            'planet': 'sun',
            'planet_position': {
                'zodiac_sign': 'Virgo',
                'house': 10,
                ...
            }
        }
        
        style options:
        - 'complete': Full sentence with all layers
        - 'essence': Core meaning only
        - 'technical': Precise technical description
        - 'poetic': Natural language flow
        """
        
        # Extract components
        gate_num = str(activation['gate'])
        line_num = str(activation['line'])
        color_num = str(activation['color'])
        tone_num = str(activation['tone'])
        base_num = str(activation['base'])
        
        # Get semantic data
        gate_data = self.gates.get(gate_num, {})
        color_data = self.colors.get(color_num, {})
        tone_data = self.tones.get(tone_num, {})
        base_data = self.bases.get(base_num, {})
        
        # Get astrological context
        zodiac = activation.get('planet_position', {}).get('zodiac_sign', 'unknown')
        house = activation.get('planet_position', {}).get('house', 0)
        planet = activation.get('planet', 'unknown')
        
        # Generate based on style
        if style == 'complete':
            return self._generate_complete(
                gate_data, line_num, color_data, tone_data, base_data,
                zodiac, house, planet, activation
            )
        elif style == 'essence':
            return self._generate_essence(gate_data, color_data)
        elif style == 'technical':
            return self._generate_technical(activation, gate_data)
        elif style == 'poetic':
            return self._generate_poetic(
                gate_data, color_data, tone_data, base_data, zodiac, house
            )
        else:
            return self._generate_complete(
                gate_data, line_num, color_data, tone_data, base_data,
                zodiac, house, planet, activation
            )
    
    def _generate_complete(self, gate_data, line_num, color_data, tone_data, 
                          base_data, zodiac, house, planet, activation) -> str:
        """
        Complete sentence with all layers.
        
        Format:
        "You express [GATE NAME] through [LINE QUALITY], 
         motivated by [COLOR], sensing via [TONE], 
         grounded in [BASE] environments, 
         manifesting in [ZODIAC] through the [HOUSE] house via [PLANET]"
        """
        
        # Gate essence
        gate_name = gate_data.get('name', f"Gate {activation['gate']}")
        gate_keywords = gate_data.get('keywords', [])
        gate_essence = gate_keywords[0] if gate_keywords else gate_name.lower()
        
        # Line quality (get from lines if available, or derive from gate)
        line_data = gate_data.get('lines', {}).get(line_num, {})
        line_quality = self._derive_line_quality(line_num, gate_essence)
        
        # Color motivation
        color_name = color_data.get('name', 'unknown')
        color_motivation = color_data.get('motivation', color_name.lower())
        
        # Tone sense
        tone_name = tone_data.get('name', 'unknown')
        tone_sense = tone_data.get('sense', tone_name.lower())
        
        # Base environment
        base_name = base_data.get('name', 'unknown')
        base_env = base_data.get('environment', base_name.lower())
        
        # House domain
        house_domain = self._get_house_domain(house)
        
        # Construct sentence
        sentence = (
            f"You express {gate_essence} {line_quality}, "
            f"motivated by {color_motivation}, "
            f"sensing through {tone_sense}, "
            f"grounded in {base_env} environments, "
            f"manifesting in {zodiac} through {house_domain} via {planet}"
        )
        
        return sentence
    
    def _generate_essence(self, gate_data, color_data) -> str:
        """Core essence only"""
        gate_name = gate_data.get('name', 'Expression')
        gate_keywords = gate_data.get('keywords', [])
        color_motivation = color_data.get('motivation', 'desire')
        
        essence = gate_keywords[0] if gate_keywords else gate_name.lower()
        
        return f"I AM {essence}, motivated by {color_motivation}"
    
    def _generate_technical(self, activation, gate_data) -> str:
        """Precise technical description"""
        sig = activation.get('signature', 
                            f"{activation['gate']}.{activation['line']}."
                            f"{activation['color']}.{activation['tone']}.{activation['base']}")
        
        gate_name = gate_data.get('name', f"Gate {activation['gate']}")
        planet = activation.get('planet', 'unknown')
        zodiac = activation.get('planet_position', {}).get('zodiac_sign', 'unknown')
        zodiac_pos = activation.get('planet_position', {}).get('zodiac_position', '')
        house = activation.get('planet_position', {}).get('house', 0)
        freq = activation.get('frequency', 0)
        
        return (
            f"Activation {sig}: {gate_name} "
            f"via {planet} at {zodiac_pos} "
            f"(House {house}) "
            f"resonating at {freq:.2f}Hz"
        )
    
    def _generate_poetic(self, gate_data, color_data, tone_data, 
                        base_data, zodiac, house) -> str:
        """Natural language flow"""
        gate_keywords = gate_data.get('keywords', [])
        gate_essence = gate_keywords[0] if gate_keywords else "expression"
        
        color_keywords = color_data.get('keywords', [])
        color_feeling = color_keywords[0] if color_keywords else "desire"
        
        tone_keywords = tone_data.get('keywords', [])
        tone_quality = tone_keywords[0] if tone_keywords else "awareness"
        
        base_keywords = base_data.get('keywords', [])
        base_space = base_keywords[0] if base_keywords else "environment"
        
        house_meaning = self._get_house_meaning(house)
        
        return (
            f"Your {gate_essence} flows through {color_feeling}, "
            f"perceived via {tone_quality}, "
            f"anchored in {base_space}, "
            f"expressing through {house_meaning} in {zodiac}"
        )
    
    def _derive_line_quality(self, line_num: str, gate_essence: str) -> str:
        """Derive line quality from line number"""
        line_qualities = {
            '1': 'with foundational structure',
            '2': 'through natural talent',
            '3': 'via experimental discovery',
            '4': 'through relationship bonds',
            '5': 'with universal application',
            '6': 'as transcendent wisdom'
        }
        return line_qualities.get(line_num, 'through expression')
    
    def _get_house_domain(self, house: int) -> str:
        """Get house domain description"""
        house_domains = {
            1: 'self-identity',
            2: 'resources and values',
            3: 'communication and learning',
            4: 'home and foundation',
            5: 'creativity and pleasure',
            6: 'service and refinement',
            7: 'partnership and relating',
            8: 'transformation and depth',
            9: 'expansion and meaning',
            10: 'career and legacy',
            11: 'community and innovation',
            12: 'transcendence and release'
        }
        return house_domains.get(house, 'expression')
    
    def _get_house_meaning(self, house: int) -> str:
        """Get house meaning for poetic style"""
        house_meanings = {
            1: 'the realm of self',
            2: 'the domain of value',
            3: 'the space of connection',
            4: 'the foundation of being',
            5: 'the joy of creation',
            6: 'the art of service',
            7: 'the dance of relationship',
            8: 'the depth of transformation',
            9: 'the quest for meaning',
            10: 'the path of mastery',
            11: 'the field of vision',
            12: 'the ocean of dissolution'
        }
        return house_meanings.get(house, 'the field of life')
    
    def generate_field_narrative(self, field_activations: List[Dict]) -> str:
        """
        Generate a complete narrative from all activations in a field.
        
        field_activations = list of activation dicts for one field
        """
        if not field_activations:
            return "No activations in this field"
        
        sentences = []
        for act in field_activations:
            sentence = self.generate(act, style='poetic')
            sentences.append(sentence)
        
        # Join with proper punctuation
        narrative = ". ".join(sentences)
        return narrative + "."
    
    def generate_state_expression(self, activation: Dict) -> Dict:
        """
        Generate expression for all three states:
        - Distortion (not-self)
        - Resonance (aligned)
        - Convergence (mastery)
        """
        gate_num = str(activation['gate'])
        gate_data = self.gates.get(gate_num, {})
        power_exp = gate_data.get('power_expressions', {})
        
        # Get base components
        color_data = self.colors.get(str(activation['color']), {})
        tone_data = self.tones.get(str(activation['tone']), {})
        
        distortion = power_exp.get('distortion', {})
        resonance = power_exp.get('resonance', {})
        convergence = power_exp.get('convergence', {})
        
        return {
            'distortion': {
                'feels': distortion.get('feels', 'Blocked expression'),
                'looks': distortion.get('looks', 'Struggling with flow'),
                'scenarios': distortion.get('scenarios', 'When alignment is lost'),
                'guidance': self._generate_guidance(activation, 'distortion')
            },
            'resonance': {
                'feels': resonance.get('feels', 'Natural flow'),
                'looks': resonance.get('looks', 'Aligned expression'),
                'scenarios': resonance.get('scenarios', 'Living your design'),
                'guidance': self._generate_guidance(activation, 'resonance')
            },
            'convergence': {
                'feels': convergence.get('feels', 'Effortless mastery'),
                'looks': convergence.get('looks', 'Magnetic presence'),
                'scenarios': convergence.get('scenarios', 'Teaching through being'),
                'guidance': self._generate_guidance(activation, 'convergence')
            }
        }
    
    def _generate_guidance(self, activation: Dict, state: str) -> str:
        """Generate guidance based on current state"""
        gate_num = str(activation['gate'])
        gate_data = self.gates.get(gate_num, {})
        gate_name = gate_data.get('name', 'Expression')
        
        color_data = self.colors.get(str(activation['color']), {})
        color_motivation = color_data.get('motivation', 'desire')
        
        if state == 'distortion':
            return (
                f"To move toward alignment with {gate_name}, "
                f"honor your {color_motivation} without forcing it. "
                f"Trust your natural timing."
            )
        elif state == 'resonance':
            return (
                f"You're aligned with {gate_name}. "
                f"Continue following your {color_motivation}. "
                f"Share what flows naturally."
            )
        else:  # convergence
            return (
                f"Your mastery of {gate_name} serves as a beacon. "
                f"Your {color_motivation} guides others naturally. "
                f"Simply be."
            )


# ============================================================================
# INTEGRATION WITH FOUNDRY GRAPH
# ============================================================================

def integrate_sentence_engine_with_foundry():
    """
    Example of how to integrate the sentence engine with the Foundry graph.
    This would be added to foundry_complete_v3.py
    """
    
    # Initialize sentence engine
    sentence_engine = SentenceEngine('knowledge_base_enriched.json')
    
    # When getting node state, add generated sentences
    def get_node_with_sentences(foundry_graph, node_id: str) -> Dict:
        state = foundry_graph.get_complete_state(node_id)
        
        # Add sentences to each activation
        for field_name, field_data in state['fields'].items():
            for activation in field_data['activations']:
                # Generate all sentence styles
                activation['sentences'] = {
                    'complete': sentence_engine.generate(activation, 'complete'),
                    'essence': sentence_engine.generate(activation, 'essence'),
                    'technical': sentence_engine.generate(activation, 'technical'),
                    'poetic': sentence_engine.generate(activation, 'poetic')
                }
                
                # Add state expressions
                activation['state_expressions'] = sentence_engine.generate_state_expression(activation)
        
        return state
    
    return get_node_with_sentences


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    import sys
    
    # Load sentence engine
    kb_path = '/mnt/user-data/uploads/knowledge_base_enriched.json'
    if not Path(kb_path).exists():
        print(f"❌ Knowledge base not found at {kb_path}")
        sys.exit(1)
    
    engine = SentenceEngine(kb_path)
    
    # Example activation (what the backend calculates)
    sample_activation = {
        'gate': 41,
        'line': 3,
        'color': 2,
        'tone': 5,
        'base': 1,
        'planet': 'sun',
        'signature': '41.3.2.5.1',
        'frequency': 642.5,
        'planet_position': {
            'zodiac_sign': 'Virgo',
            'zodiac_position': '25°32\'35" Virgo',
            'house': 10
        }
    }
    
    print("🔥 FOUNDRY SENTENCE ENGINE - DYNAMIC GENERATION")
    print("=" * 70)
    print()
    
    print("📍 Sample Activation:")
    print(f"  Signature: {sample_activation['signature']}")
    print(f"  Planet: {sample_activation['planet']} in {sample_activation['planet_position']['zodiac_sign']}")
    print(f"  House: {sample_activation['planet_position']['house']}")
    print()
    
    print("📝 GENERATED SENTENCES:")
    print()
    
    print("🎯 COMPLETE:")
    print(f"  {engine.generate(sample_activation, 'complete')}")
    print()
    
    print("💎 ESSENCE:")
    print(f"  {engine.generate(sample_activation, 'essence')}")
    print()
    
    print("🔬 TECHNICAL:")
    print(f"  {engine.generate(sample_activation, 'technical')}")
    print()
    
    print("🌊 POETIC:")
    print(f"  {engine.generate(sample_activation, 'poetic')}")
    print()
    
    print("🔄 STATE EXPRESSIONS:")
    states = engine.generate_state_expression(sample_activation)
    for state_name, state_data in states.items():
        print(f"\n  {state_name.upper()}:")
        print(f"    Feels: {state_data['feels']}")
        print(f"    Looks: {state_data['looks']}")
        print(f"    Guidance: {state_data['guidance']}")
    
    print()
    print("✅ Sentence engine operational - sentences generated from")
    print("   calculated activations + knowledge base (NO pre-written templates)")
