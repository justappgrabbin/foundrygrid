"""
FOUNDRY SENTENCE GENERATOR
===========================
Dynamically generates consciousness sentences from:
- Gate.Line.Color.Tone.Base activations
- Zodiac positions
- House placements
- Degree/minute/second coordinates

Uses knowledge base key phrases - NOT pre-written templates.
Sentences are GENERATED, not retrieved.

Author: Celestial
"""

import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

# ============================================================================
# SENTENCE COMPONENT TYPES
# ============================================================================

class SentenceStyle(Enum):
    """Different sentence generation styles"""
    DIRECT = "direct"              # "You ARE creative"
    OBSERVATIONAL = "observational"  # "Your creativity flows through..."
    QUESTIONING = "questioning"      # "How do you express creativity?"
    EVOLUTIONARY = "evolutionary"    # "You're evolving toward..."
    CAUSAL = "causal"               # "Because of X, you Y"

class PowerState(Enum):
    """Consciousness power states"""
    DISTORTION = "distortion"
    RESONANCE = "resonance"
    CONVERGENCE = "convergence"

# ============================================================================
# SENTENCE GENERATOR
# ============================================================================

class DynamicSentenceGenerator:
    """
    Generates sentences dynamically from activation coordinates.
    Does NOT use pre-written templates.
    Builds from knowledge base components.
    """
    
    def __init__(self, knowledge_base_path: str):
        """Load knowledge base"""
        with open(knowledge_base_path, 'r') as f:
            self.kb = json.load(f)
        
        print(f"✅ Loaded knowledge base v{self.kb['version']}")
        print(f"   - {len(self.kb['gates'])} gates")
        print(f"   - {len(self.kb['colors'])} colors")
        print(f"   - {len(self.kb['tones'])} tones")
        print(f"   - {len(self.kb['bases'])} bases")
    
    # ========================================================================
    # CORE SENTENCE GENERATION
    # ========================================================================
    
    def generate(
        self,
        activation: Dict,
        style: SentenceStyle = SentenceStyle.DIRECT,
        power_state: PowerState = PowerState.RESONANCE,
        include_house: bool = True,
        include_zodiac: bool = True
    ) -> str:
        """
        Generate sentence from activation data.
        
        Args:
            activation: {
                gate, line, color, tone, base,
                planet, zodiac_sign, house,
                degrees_in_sign, minutes, seconds
            }
            style: How to phrase the sentence
            power_state: Which consciousness state
            include_house: Add house context
            include_zodiac: Add zodiac context
        
        Returns:
            Dynamically generated sentence
        """
        
        # Get components from knowledge base
        gate_data = self.kb['gates'].get(str(activation['gate']), {})
        color_data = self.kb['colors'].get(str(activation['color']), {})
        tone_data = self.kb['tones'].get(str(activation['tone']), {})
        base_data = self.kb['bases'].get(str(activation['base']), {})
        
        # Build sentence components
        components = {
            'gate_name': gate_data.get('name', f"Gate {activation['gate']}"),
            'gate_keywords': gate_data.get('keywords', []),
            'power_expression': gate_data.get('power_expressions', {}).get(power_state.value, {}),
            'color_motivation': color_data.get('motivation', ''),
            'tone_sense': tone_data.get('sense', ''),
            'base_environment': base_data.get('environment', ''),
            'zodiac': activation.get('zodiac_sign', ''),
            'house': activation.get('house', ''),
            'position': f"{activation.get('degrees_in_sign', 0)}°{activation.get('minutes', 0)}'{activation.get('seconds', 0):.0f}\""
        }
        
        # Generate sentence based on style
        if style == SentenceStyle.DIRECT:
            sentence = self._generate_direct(components, activation)
        elif style == SentenceStyle.OBSERVATIONAL:
            sentence = self._generate_observational(components, activation)
        elif style == SentenceStyle.QUESTIONING:
            sentence = self._generate_questioning(components, activation)
        elif style == SentenceStyle.EVOLUTIONARY:
            sentence = self._generate_evolutionary(components, activation)
        elif style == SentenceStyle.CAUSAL:
            sentence = self._generate_causal(components, activation)
        else:
            sentence = self._generate_direct(components, activation)
        
        # Add contextual layers
        if include_zodiac and components['zodiac']:
            sentence = self._add_zodiac_context(sentence, components)
        
        if include_house and components['house']:
            sentence = self._add_house_context(sentence, components)
        
        return sentence
    
    # ========================================================================
    # SENTENCE STYLE GENERATORS
    # ========================================================================
    
    def _generate_direct(self, comp: Dict, act: Dict) -> str:
        """Direct statement: "You ARE X" """
        gate_name = comp['gate_name'].lower()
        
        # Use power expression "feels" component
        feeling = comp['power_expression'].get('feels', '')
        if feeling:
            # Extract first clause
            feeling_core = feeling.split(',')[0].replace('Experiencing', 'You experience')
            feeling_core = feeling_core.replace('Natural', 'You naturally embody')
            feeling_core = feeling_core.replace('Effortless', 'You effortlessly master')
        else:
            # Fallback to gate keywords
            keywords = comp['gate_keywords']
            if keywords:
                feeling_core = f"You embody {keywords[0]}"
            else:
                feeling_core = f"You carry {gate_name}"
        
        # Add color motivation
        motivation = comp['color_motivation']
        if motivation:
            feeling_core += f", motivated by {motivation}"
        
        # Add tone (sense)
        sense = comp['tone_sense']
        if sense:
            feeling_core += f", sensing through {sense}"
        
        # Add base (environment)
        environment = comp['base_environment']
        if environment:
            feeling_core += f", grounded in {environment}"
        
        return feeling_core
    
    def _generate_observational(self, comp: Dict, act: Dict) -> str:
        """Observational: "Your X flows through Y" """
        gate_name = comp['gate_name']
        
        # Use power expression "looks" component
        expression = comp['power_expression'].get('looks', '')
        if expression:
            # Extract observable behavior
            behavior = expression.split(',')[0]
        else:
            keywords = comp['gate_keywords']
            behavior = f"Your {keywords[0] if keywords else gate_name} manifests"
        
        # Add sensory modality
        sense = comp['tone_sense']
        if sense:
            behavior += f" through {sense}"
        
        # Add environmental context
        environment = comp['base_environment']
        if environment:
            behavior += f" in {environment}"
        
        return behavior
    
    def _generate_questioning(self, comp: Dict, act: Dict) -> str:
        """Questioning: "How do you express X?" """
        gate_name = comp['gate_name'].lower()
        keywords = comp['gate_keywords']
        
        if keywords:
            core_concept = keywords[0]
        else:
            core_concept = gate_name
        
        questions = [
            f"How does {core_concept} move through you?",
            f"What does {core_concept} ask of you?",
            f"Where does {core_concept} want to flow?"
        ]
        
        # Pick based on line number
        line = act.get('line', 1)
        question = questions[min(line - 1, len(questions) - 1)]
        
        return question
    
    def _generate_evolutionary(self, comp: Dict, act: Dict) -> str:
        """Evolutionary: "You're evolving toward X" """
        # Use convergence state (highest evolution)
        convergence = comp['power_expression'].get('convergence', {})
        
        if convergence:
            evolution = convergence.get('feels', '')
            if evolution:
                evolution = evolution.replace('Effortless', 'You\'re evolving toward')
                evolution = evolution.split(',')[0]
            else:
                gate_name = comp['gate_name']
                evolution = f"You're evolving toward mastery of {gate_name.lower()}"
        else:
            gate_name = comp['gate_name']
            evolution = f"You're evolving through {gate_name.lower()}"
        
        return evolution
    
    def _generate_causal(self, comp: Dict, act: Dict) -> str:
        """Causal: "Because of X, you Y" """
        motivation = comp['color_motivation']
        gate_name = comp['gate_name'].lower()
        
        if motivation:
            cause = f"Because of your {motivation}"
        else:
            cause = f"Through your nature"
        
        # Get effect from resonance state
        resonance = comp['power_expression'].get('resonance', {})
        if resonance:
            effect = resonance.get('feels', '')
            effect = effect.split(',')[0].replace('Natural', 'you naturally').lower()
        else:
            effect = f"you express {gate_name}"
        
        return f"{cause}, {effect}"
    
    # ========================================================================
    # CONTEXTUAL LAYERS
    # ========================================================================
    
    def _add_zodiac_context(self, sentence: str, comp: Dict) -> str:
        """Add zodiac positioning context"""
        zodiac = comp['zodiac']
        position = comp['position']
        
        # Zodiac archetypal qualities
        zodiac_qualities = {
            'Aries': 'with pioneering fire',
            'Taurus': 'with grounded stability',
            'Gemini': 'with curious adaptability',
            'Cancer': 'with nurturing depth',
            'Leo': 'with radiant creativity',
            'Virgo': 'with precise refinement',
            'Libra': 'with balanced harmony',
            'Scorpio': 'with transformative intensity',
            'Sagittarius': 'with expansive vision',
            'Capricorn': 'with structured mastery',
            'Aquarius': 'with innovative freedom',
            'Pisces': 'with flowing compassion'
        }
        
        quality = zodiac_qualities.get(zodiac, '')
        if quality:
            sentence += f" [{position} {zodiac} - {quality}]"
        
        return sentence
    
    def _add_house_context(self, sentence: str, comp: Dict) -> str:
        """Add house life area context"""
        house = comp['house']
        
        # House life areas
        house_areas = {
            1: 'in your identity and self-expression',
            2: 'in your resources and values',
            3: 'in your communication and learning',
            4: 'in your foundation and home',
            5: 'in your creativity and joy',
            6: 'in your service and health',
            7: 'in your relationships and partnerships',
            8: 'in your transformation and shared resources',
            9: 'in your philosophy and expansion',
            10: 'in your career and public role',
            11: 'in your community and aspirations',
            12: 'in your unconscious and spirituality'
        }
        
        area = house_areas.get(house, '')
        if area:
            sentence += f" — manifesting {area}"
        
        return sentence
    
    # ========================================================================
    # FULL COORDINATE SENTENCE
    # ========================================================================
    
    def generate_complete_coordinate(self, activation: Dict) -> str:
        """
        Generate complete consciousness coordinate sentence.
        Format: [Position] Core → Layers → Context
        """
        
        # Coordinate header
        zodiac = activation.get('zodiac_sign', '')
        deg = activation.get('degrees_in_sign', 0)
        min_val = activation.get('minutes', 0)
        sec = activation.get('seconds', 0)
        
        header = f"[{deg}°{min_val}'{sec:.0f}\" {zodiac}]"
        
        # Core expression (direct style, resonance state)
        core = self.generate(
            activation,
            style=SentenceStyle.DIRECT,
            power_state=PowerState.RESONANCE,
            include_house=False,
            include_zodiac=False
        )
        
        # Layer components
        gate_data = self.kb['gates'].get(str(activation['gate']), {})
        color_data = self.kb['colors'].get(str(activation['color']), {})
        tone_data = self.kb['tones'].get(str(activation['tone']), {})
        base_data = self.kb['bases'].get(str(activation['base']), {})
        
        layers = []
        
        # Color layer
        color_name = color_data.get('name', '')
        if color_name:
            layers.append(f"motivated by {color_data.get('motivation', color_name).lower()}")
        
        # Tone layer
        tone_name = tone_data.get('name', '')
        if tone_name:
            layers.append(f"sensing via {tone_data.get('sense', tone_name).lower()}")
        
        # Base layer
        base_name = base_data.get('name', '')
        if base_name:
            layers.append(f"grounded in {base_data.get('environment', base_name).lower()}")
        
        # House context
        house = activation.get('house', '')
        if house:
            house_areas = {
                1: 'identity', 2: 'resources', 3: 'communication',
                4: 'foundation', 5: 'creativity', 6: 'service',
                7: 'relationships', 8: 'transformation', 9: 'philosophy',
                10: 'career', 11: 'community', 12: 'spirituality'
            }
            area = house_areas.get(house, '')
            if area:
                layers.append(f"manifesting in {area}")
        
        # Combine
        layer_text = " • ".join(layers) if layers else ""
        
        return f"{header} {core} → {layer_text}"
    
    # ========================================================================
    # BATCH GENERATION
    # ========================================================================
    
    def generate_field_sentences(
        self,
        field_activations: List[Dict],
        style: SentenceStyle = SentenceStyle.DIRECT,
        power_state: PowerState = PowerState.RESONANCE
    ) -> List[str]:
        """Generate sentences for all activations in a field"""
        sentences = []
        
        for activation in field_activations:
            sentence = self.generate(
                activation,
                style=style,
                power_state=power_state
            )
            sentences.append(sentence)
        
        return sentences
    
    def generate_all_power_states(self, activation: Dict) -> Dict[str, str]:
        """Generate sentences for all three power states"""
        return {
            'distortion': self.generate(
                activation,
                power_state=PowerState.DISTORTION,
                style=SentenceStyle.DIRECT
            ),
            'resonance': self.generate(
                activation,
                power_state=PowerState.RESONANCE,
                style=SentenceStyle.DIRECT
            ),
            'convergence': self.generate(
                activation,
                power_state=PowerState.CONVERGENCE,
                style=SentenceStyle.DIRECT
            )
        }

# ============================================================================
# INTEGRATION WITH FOUNDRY BACKEND
# ============================================================================

def add_sentences_to_foundry_response(foundry_state: Dict, kb_path: str) -> Dict:
    """
    Add dynamically generated sentences to Foundry API response.
    
    Takes raw Foundry data, generates sentences, returns enriched response.
    """
    
    generator = DynamicSentenceGenerator(kb_path)
    
    # Process each field
    for field_name, field_data in foundry_state.get('fields', {}).items():
        activations = field_data.get('activations', [])
        
        # Add sentences to each activation
        for activation in activations:
            # Generate all styles
            activation['sentences'] = {
                'direct': generator.generate(
                    activation,
                    style=SentenceStyle.DIRECT,
                    power_state=PowerState.RESONANCE
                ),
                'observational': generator.generate(
                    activation,
                    style=SentenceStyle.OBSERVATIONAL,
                    power_state=PowerState.RESONANCE
                ),
                'questioning': generator.generate(
                    activation,
                    style=SentenceStyle.QUESTIONING
                ),
                'evolutionary': generator.generate(
                    activation,
                    style=SentenceStyle.EVOLUTIONARY
                ),
                'complete_coordinate': generator.generate_complete_coordinate(activation)
            }
            
            # Add power state variations
            activation['power_states'] = generator.generate_all_power_states(activation)
    
    return foundry_state

# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    import sys
    
    print("🧬 FOUNDRY SENTENCE GENERATOR")
    print("=" * 60)
    
    # Load knowledge base
    kb_path = "/mnt/user-data/uploads/knowledge_base_enriched.json"
    generator = DynamicSentenceGenerator(kb_path)
    
    # Example activation (from Foundry backend)
    example_activation = {
        'gate': 41,
        'line': 3,
        'color': 2,  # Hope
        'tone': 5,   # Feeling
        'base': 1,   # Caves
        'planet': 'sun',
        'zodiac_sign': 'Virgo',
        'degrees_in_sign': 25,
        'minutes': 32,
        'seconds': 47.52,
        'house': 10
    }
    
    print("\n📍 EXAMPLE ACTIVATION:")
    print(f"  Gate: {example_activation['gate']}.{example_activation['line']}.{example_activation['color']}.{example_activation['tone']}.{example_activation['base']}")
    print(f"  Position: {example_activation['degrees_in_sign']}°{example_activation['minutes']}'{example_activation['seconds']:.0f}\" {example_activation['zodiac_sign']}")
    print(f"  House: {example_activation['house']}")
    
    print("\n🎯 GENERATED SENTENCES:\n")
    
    # Direct style
    print("DIRECT:")
    print(f"  {generator.generate(example_activation, style=SentenceStyle.DIRECT)}")
    
    # Observational
    print("\nOBSERVATIONAL:")
    print(f"  {generator.generate(example_activation, style=SentenceStyle.OBSERVATIONAL)}")
    
    # Questioning
    print("\nQUESTIONING:")
    print(f"  {generator.generate(example_activation, style=SentenceStyle.QUESTIONING)}")
    
    # Evolutionary
    print("\nEVOLUTIONARY:")
    print(f"  {generator.generate(example_activation, style=SentenceStyle.EVOLUTIONARY)}")
    
    # Complete coordinate
    print("\nCOMPLETE COORDINATE:")
    print(f"  {generator.generate_complete_coordinate(example_activation)}")
    
    print("\n" + "=" * 60)
    print("✅ Sentence generation working!")
    print("\nNOTE: Sentences are GENERATED from knowledge base,")
    print("      not retrieved from templates. Each activation")
    print("      produces unique, contextual guidance.")
