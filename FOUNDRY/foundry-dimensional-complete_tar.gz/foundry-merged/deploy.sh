#!/bin/bash

# FOUNDRY COMPLETE SYSTEM v3.0 - DEPLOYMENT SCRIPT
# ================================================

echo "🔥 FOUNDRY COMPLETE SYSTEM v3.0 - DEPLOYMENT"
echo "=============================================="

# Check Python version
echo ""
echo "📌 Checking Python version..."
python3 --version

# Create virtual environment
echo ""
echo "📦 Creating virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install dependencies
echo ""
echo "📥 Installing dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Create necessary directories
echo ""
echo "📁 Creating directory structure..."
mkdir -p assets/glyphs/{gates,zodiac,planets,centers,channels}
mkdir -p data
mkdir -p logs

# Generate placeholder glyphs (SVG)
echo ""
echo "🎨 Generating placeholder glyphs..."

# Gate glyphs (1-64)
for i in {1..64}; do
cat > "assets/glyphs/gates/gate_${i}.svg" << EOF
<svg width="64" height="64" xmlns="http://www.w3.org/2000/svg">
  <circle cx="32" cy="32" r="28" fill="none" stroke="#9d4edd" stroke-width="2"/>
  <text x="32" y="38" text-anchor="middle" font-size="24" fill="#9d4edd">${i}</text>
</svg>
EOF
done

# Zodiac glyphs
declare -A zodiac_symbols=( ["aries"]="♈" ["taurus"]="♉" ["gemini"]="♊" ["cancer"]="♋" 
                            ["leo"]="♌" ["virgo"]="♍" ["libra"]="♎" ["scorpio"]="♏" 
                            ["sagittarius"]="♐" ["capricorn"]="♑" ["aquarius"]="♒" ["pisces"]="♓" )

for sign in aries taurus gemini cancer leo virgo libra scorpio sagittarius capricorn aquarius pisces; do
cat > "assets/glyphs/zodiac/${sign}.svg" << EOF
<svg width="48" height="48" xmlns="http://www.w3.org/2000/svg">
  <text x="24" y="32" text-anchor="middle" font-size="32" fill="#4895ef">${zodiac_symbols[$sign]}</text>
</svg>
EOF
done

# Planet glyphs
declare -A planet_symbols=( ["sun"]="☉" ["moon"]="☽" ["mercury"]="☿" ["venus"]="♀" 
                            ["mars"]="♂" ["jupiter"]="♃" ["saturn"]="♄" 
                            ["uranus"]="♅" ["neptune"]="♆" ["pluto"]="♇" )

for planet in sun moon mercury venus mars jupiter saturn uranus neptune pluto; do
cat > "assets/glyphs/planets/${planet}.svg" << EOF
<svg width="48" height="48" xmlns="http://www.w3.org/2000/svg">
  <text x="24" y="32" text-anchor="middle" font-size="32" fill="#6dd5ed">${planet_symbols[$planet]}</text>
</svg>
EOF
done

echo "✅ Generated 64 gate glyphs"
echo "✅ Generated 12 zodiac glyphs"
echo "✅ Generated 10 planet glyphs"

# Test the system
echo ""
echo "🧪 Testing Foundry system..."
python3 -c "
from foundry_complete_v3 import FoundryGraph, BirthCoordinates
from datetime import datetime

print('Creating foundry instance...')
foundry = FoundryGraph(persist_path='data/foundry_graph.json')

print('Testing node creation...')
coords = BirthCoordinates(
    latitude=37.7749,
    longitude=-122.4194,
    datetime=datetime(1990, 9, 18, 14, 30, 0)
)

node = foundry.add_node(coords)
print(f'✓ Node created: {node.node_id}')
print(f'✓ Coherence: {node.coherence:.4f}')
print(f'✓ Fields computed: {len(node.fields)}')
print(f'✓ Charts computed: {len(node.charts)}')

state = foundry.get_complete_state(node.node_id)
print(f'✓ Complete state retrieved')
print('🎉 System test passed!')
"

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ ALL TESTS PASSED!"
    echo ""
    echo "🚀 Starting API server..."
    echo ""
    echo "Run: uvicorn foundry_complete_v3:app --reload --host 0.0.0.0 --port 8000"
    echo ""
    echo "API will be available at:"
    echo "  http://localhost:8000"
    echo "  http://localhost:8000/docs  (Swagger UI)"
    echo ""
    echo "Key endpoints:"
    echo "  POST /api/nodes              - Create consciousness node"
    echo "  GET  /api/nodes/{id}         - Get complete state"
    echo "  GET  /api/trinity/{id}       - Trinity view (Body/Mind/Heart)"
    echo "  GET  /api/glyphs/gate/{num}  - Gate metadata"
    echo "  GET  /assets/glyphs/...      - Glyph images"
    echo ""
else
    echo "❌ TEST FAILED"
    exit 1
fi
