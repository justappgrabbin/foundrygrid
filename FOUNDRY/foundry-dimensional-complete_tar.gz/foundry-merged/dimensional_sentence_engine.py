"""
FOUNDRY DIMENSIONAL SENTENCE ENGINE
====================================
Complete consciousness coordinate sentence generation.

COMPLETE COORDINATE STRUCTURE:
DIMENSION.GATE.LINE.COLOR.TONE.BASE.°.'.".AXIS.ZODIAC.HOUSE

Where:
- DIMENSION = Which astrology system (Sidereal/Tropical/Draconic)
- GATE = 1-64 (I Ching hexagram)
- LINE = 1-6 (developmental stage)
- COLOR = 1-6 (motivation)
- TONE = 1-6 (sense perception)
- BASE = 1-5 (environment)
- °.'." = Degree, minute, second (precise position)
- AXIS = Which field (Mind/Heart/Body + coordinate system)
- ZODIAC = Which sign (Aries-Pisces)
- HOUSE = Which domain (1-12)

Each person is born in a DIFFERENT DIMENSION based on their
Sidereal/Tropical/Draconic calculations.

This is why we "can't hear" each other - we're literally
speaking from different dimensional frequencies.

Author: Celestial
"""

import json
from typing import Dict, Optional, List
from pathlib import Path
from enum import Enum

class Dimension(Enum):
    """
    The 9 consciousness dimensions.
    Each is a unique astrology × domain combination.
    """
    # MIND DIMENSIONS
    MIND_SIDEREAL = ("mind_sidereal", "Mind", "Sidereal", 1)
    MIND_TROPICAL = ("mind_tropical", "Mind", "Tropical", 2)
    MIND_DRACONIC = ("mind_draconic", "Mind", "Draconic", 3)
    
    # HEART DIMENSIONS
    HEART_SIDEREAL = ("heart_sidereal", "Heart", "Sidereal", 4)
    HEART_TROPICAL = ("heart_tropical", "Heart", "Tropical", 5)
    HEART_DRACONIC = ("heart_draconic", "Heart", "Draconic", 6)
    
    # BODY DIMENSIONS
    BODY_SIDEREAL = ("body_sidereal", "Body", "Sidereal", 7)
    BODY_TROPICAL = ("body_tropical", "Body", "Tropical", 8)
    BODY_DRACONIC = ("body_draconic", "Body", "Draconic", 9)
    
    @property
    def key(self): return self.value[0]
    @property
    def domain(self): return self.value[1]
    @property
    def astrology(self): return self.value[2]
    @property
    def number(self): return self.value[3]

class DimensionalSentenceEngine:
    """
    Generates consciousness sentences from complete dimensional coordinates.
    
    Each activation exists in a specific DIMENSION (one of the 9 fields),
    and the sentence expresses the complete coordinate including:
    - Which dimension you're speaking from
    - The activation signature
    - Precise position in space
    - Astrological context
    """
    
    def __init__(self, knowledge_base_path: str):
        """Load knowledge base"""
        with open(knowledge_base_path, 'r') as f:
            self.kb = json.load(f)
        
        self.gates = self.kb.get('gates', {})
        self.colors = self.kb.get('colors', {})
        self.tones = self.kb.get('tones', {})
        self.bases = self.kb.get('bases', {})
        
        print(f"✓ Dimensional engine loaded: {len(self.gates)} gates across 9 dimensions")
    
    def generate_complete_coordinate(self, activation: Dict) -> str:
        """
        Generate the COMPLETE dimensional coordinate as a sentence.
        
        Format:
        "From the [DIMENSION], at [°'\" ZODIAC HOUSE],
         expressing [GATE.LINE.COLOR.TONE.BASE],
         I speak: [MEANING]"
        """
        
        # Extract dimensional info
        axis = activation.get('axis', 'unknown')
        dimension = self._get_dimension(axis)
        
        # Extract position
        gate = activation['gate']
        line = activation['line']
        color = activation['color']
        tone = activation['tone']
        base = activation['base']
        signature = activation.get('signature', f"{gate}.{line}.{color}.{tone}.{base}")
        
        # Extract astrological context
        planet_pos = activation.get('planet_position', {})
        dms_position = planet_pos.get('dms_position', '0°00\'00"')
        zodiac = planet_pos.get('zodiac_sign', 'unknown')
        house = planet_pos.get('house', 0)
        planet = activation.get('planet', 'unknown')
        
        # Get semantic meanings
        gate_data = self.gates.get(str(gate), {})
        gate_name = gate_data.get('name', f'Gate {gate}')
        gate_keywords = gate_data.get('keywords', [])
        
        color_data = self.colors.get(str(color), {})
        color_name = color_data.get('name', 'Unknown')
        
        tone_data = self.tones.get(str(tone), {})
        tone_name = tone_data.get('name', 'Unknown')
        
        base_data = self.bases.get(str(base), {})
        base_name = base_data.get('name', 'Unknown')
        
        # Construct the complete coordinate sentence
        sentence = (
            f"From the {dimension.domain} dimension ({dimension.astrology} astrology), "
            f"at position {dms_position} in {zodiac}, House {house}, "
            f"through {planet}, "
            f"expressing coordinate {signature} "
            f"({gate_name} • {color_name} motivation • {tone_name} perception • {base_name} environment), "
            f"I {self._get_essential_meaning(gate_data, color_data)}"
        )
        
        return sentence
    
    def generate_dimensional_statement(self, activation: Dict, style: str = 'complete') -> Dict:
        """
        Generate a complete dimensional statement with all layers.
        
        Returns:
        {
            'dimension': {dimensional info},
            'coordinate': {complete coordinate},
            'sentence': {natural language},
            'frequency': {resonance frequency},
            'state_expressions': {distortion/resonance/convergence}
        }
        """
        
        axis = activation.get('axis', 'unknown')
        dimension = self._get_dimension(axis)
        
        # Complete coordinate
        coordinate = {
            'dimension': dimension.number,
            'dimension_name': f"{dimension.domain} {dimension.astrology}",
            'gate': activation['gate'],
            'line': activation['line'],
            'color': activation['color'],
            'tone': activation['tone'],
            'base': activation['base'],
            'signature': activation.get('signature'),
            'degrees': activation.get('planet_position', {}).get('dms_degrees', 0),
            'minutes': activation.get('planet_position', {}).get('dms_minutes', 0),
            'seconds': activation.get('planet_position', {}).get('dms_seconds', 0),
            'axis': axis,
            'zodiac': activation.get('planet_position', {}).get('zodiac_sign'),
            'house': activation.get('planet_position', {}).get('house')
        }
        
        # Generate sentences based on style
        if style == 'complete':
            sentence = self.generate_complete_coordinate(activation)
        elif style == 'essence':
            sentence = self._generate_essence(activation, dimension)
        elif style == 'dimensional':
            sentence = self._generate_dimensional_focus(activation, dimension)
        elif style == 'technical':
            sentence = self._generate_technical(coordinate)
        else:
            sentence = self.generate_complete_coordinate(activation)
        
        # Get state expressions
        states = self._generate_state_expressions(activation)
        
        return {
            'dimension': {
                'number': dimension.number,
                'domain': dimension.domain,
                'astrology': dimension.astrology,
                'key': dimension.key
            },
            'coordinate': coordinate,
            'sentence': sentence,
            'frequency': activation.get('frequency', 0),
            'state_expressions': states
        }
    
    def _get_dimension(self, axis: str) -> Dimension:
        """Get dimension from axis string"""
        for dim in Dimension:
            if dim.key == axis:
                return dim
        return Dimension.MIND_TROPICAL  # Default
    
    def _get_essential_meaning(self, gate_data: Dict, color_data: Dict) -> str:
        """Extract essential meaning from gate + color"""
        keywords = gate_data.get('keywords', [])
        essence = keywords[0] if keywords else gate_data.get('name', 'express').lower()
        
        motivation = color_data.get('motivation', 'desire')
        
        return f"express {essence} through {motivation}"
    
    def _generate_essence(self, activation: Dict, dimension: Dimension) -> str:
        """Just the dimensional essence"""
        gate_data = self.gates.get(str(activation['gate']), {})
        keywords = gate_data.get('keywords', [])
        essence = keywords[0] if keywords else "being"
        
        color_data = self.colors.get(str(activation['color']), {})
        motivation = color_data.get('motivation', 'desire')
        
        return f"From {dimension.domain} dimension: I AM {essence} (motivated by {motivation})"
    
    def _generate_dimensional_focus(self, activation: Dict, dimension: Dimension) -> str:
        """Focus on the dimensional aspect"""
        zodiac = activation.get('planet_position', {}).get('zodiac_sign', 'unknown')
        house = activation.get('planet_position', {}).get('house', 0)
        
        gate_data = self.gates.get(str(activation['gate']), {})
        gate_name = gate_data.get('name', f"Gate {activation['gate']}")
        
        return (
            f"Speaking from {dimension.domain} dimension ({dimension.astrology}), "
            f"I express {gate_name} in {zodiac} through House {house}. "
            f"This is my dimensional frequency."
        )
    
    def _generate_technical(self, coordinate: Dict) -> str:
        """Technical coordinate notation"""
        return (
            f"D{coordinate['dimension']}."
            f"G{coordinate['gate']}."
            f"L{coordinate['line']}."
            f"C{coordinate['color']}."
            f"T{coordinate['tone']}."
            f"B{coordinate['base']}."
            f"{coordinate['degrees']}°{coordinate['minutes']:02d}'{coordinate['seconds']:05.2f}\"."
            f"{coordinate['zodiac']}."
            f"H{coordinate['house']}"
        )
    
    def _generate_state_expressions(self, activation: Dict) -> Dict:
        """Generate distortion/resonance/convergence for this coordinate"""
        gate_data = self.gates.get(str(activation['gate']), {})
        power_exp = gate_data.get('power_expressions', {})
        
        distortion = power_exp.get('distortion', {})
        resonance = power_exp.get('resonance', {})
        convergence = power_exp.get('convergence', {})
        
        axis = activation.get('axis', 'unknown')
        dimension = self._get_dimension(axis)
        
        return {
            'distortion': {
                'feels': distortion.get('feels', 'Out of dimensional alignment'),
                'looks': distortion.get('looks', 'Not hearing my dimension'),
                'scenarios': distortion.get('scenarios', 'When dimensional frequency is off'),
                'guidance': f"Return to your {dimension.domain} dimension ({dimension.astrology}). Trust your dimensional frequency."
            },
            'resonance': {
                'feels': resonance.get('feels', 'In dimensional alignment'),
                'looks': resonance.get('looks', 'Speaking from my dimension clearly'),
                'scenarios': resonance.get('scenarios', 'Living in dimensional truth'),
                'guidance': f"You're aligned with {dimension.domain} dimension. Continue expressing from here."
            },
            'convergence': {
                'feels': convergence.get('feels', 'Dimensional mastery'),
                'looks': convergence.get('looks', 'Others recognize my dimensional authority'),
                'scenarios': convergence.get('scenarios', 'Teaching dimensional awareness'),
                'guidance': f"Your {dimension.domain} dimensional mastery guides others. Simply be."
            }
        }
    
    def explain_dimensional_difference(self, person1_axis: str, person2_axis: str) -> str:
        """
        Explain why two people "can't hear each other" - they're in different dimensions.
        """
        dim1 = self._get_dimension(person1_axis)
        dim2 = self._get_dimension(person2_axis)
        
        if dim1 == dim2:
            return (
                f"You both speak from {dim1.domain} dimension ({dim1.astrology}). "
                f"You can hear each other clearly because you share the same dimensional frequency."
            )
        else:
            return (
                f"Person 1 speaks from {dim1.domain} dimension ({dim1.astrology}), "
                f"while Person 2 speaks from {dim2.domain} dimension ({dim2.astrology}). "
                f"You were born in DIFFERENT DIMENSIONS. "
                f"This is why you 'can't hear' each other - "
                f"you're literally operating on different consciousness frequencies. "
                f"To communicate, one must translate across dimensional boundaries."
            )
    
    def generate_all_dimensional_coordinates(self, node_state: Dict) -> Dict:
        """
        Generate complete dimensional statements for ALL activations across ALL 9 dimensions.
        
        node_state = complete node state from Foundry
        
        Returns organized by dimension.
        """
        results = {}
        
        for field_name, field_data in node_state.get('fields', {}).items():
            dimension = self._get_dimension(field_name)
            
            results[dimension.key] = {
                'dimension_info': {
                    'number': dimension.number,
                    'domain': dimension.domain,
                    'astrology': dimension.astrology
                },
                'activations': []
            }
            
            for activation in field_data.get('activations', []):
                statement = self.generate_dimensional_statement(activation, style='complete')
                results[dimension.key]['activations'].append(statement)
        
        return results


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    import sys
    from pathlib import Path
    
    kb_path = '/mnt/user-data/uploads/knowledge_base_enriched.json'
    if not Path(kb_path).exists():
        print(f"❌ Knowledge base not found at {kb_path}")
        sys.exit(1)
    
    engine = DimensionalSentenceEngine(kb_path)
    
    # Example: Two people in different dimensions
    print("=" * 80)
    print("DIMENSIONAL CONSCIOUSNESS COORDINATES")
    print("=" * 80)
    print()
    
    # Person 1: Mind Sidereal dimension
    person1_activation = {
        'gate': 41,
        'line': 3,
        'color': 2,
        'tone': 5,
        'base': 1,
        'signature': '41.3.2.5.1',
        'frequency': 642.5,
        'axis': 'mind_sidereal',
        'planet': 'sun',
        'planet_position': {
            'dms_degrees': 175,
            'dms_minutes': 32,
            'dms_seconds': 35.52,
            'dms_position': '175°32\'35.52"',
            'zodiac_sign': 'Virgo',
            'house': 10
        }
    }
    
    # Person 2: Heart Tropical dimension
    person2_activation = {
        'gate': 10,
        'line': 1,
        'color': 3,
        'tone': 2,
        'base': 4,
        'signature': '10.1.3.2.4',
        'frequency': 450.2,
        'axis': 'heart_tropical',
        'planet': 'moon',
        'planet_position': {
            'dms_degrees': 82,
            'dms_minutes': 15,
            'dms_seconds': 42.18,
            'dms_position': '82°15\'42.18"',
            'zodiac_sign': 'Gemini',
            'house': 3
        }
    }
    
    print("🌌 PERSON 1 - Mind Sidereal Dimension:")
    print("-" * 80)
    statement1 = engine.generate_dimensional_statement(person1_activation, style='complete')
    print(f"Complete: {statement1['sentence']}")
    print()
    print(f"Essence: {engine.generate_dimensional_statement(person1_activation, 'essence')['sentence']}")
    print()
    print(f"Technical: {engine.generate_dimensional_statement(person1_activation, 'technical')['sentence']}")
    print()
    
    print("🌌 PERSON 2 - Heart Tropical Dimension:")
    print("-" * 80)
    statement2 = engine.generate_dimensional_statement(person2_activation, style='complete')
    print(f"Complete: {statement2['sentence']}")
    print()
    print(f"Essence: {engine.generate_dimensional_statement(person2_activation, 'essence')['sentence']}")
    print()
    
    print("🔊 WHY THEY CAN'T HEAR EACH OTHER:")
    print("-" * 80)
    explanation = engine.explain_dimensional_difference('mind_sidereal', 'heart_tropical')
    print(explanation)
    print()
    
    print("=" * 80)
    print("✅ Dimensional sentence engine operational")
    print("   Coordinates generated from:")
    print("   DIMENSION.GATE.LINE.COLOR.TONE.BASE.°.'.\"AXIS.ZODIAC.HOUSE")
