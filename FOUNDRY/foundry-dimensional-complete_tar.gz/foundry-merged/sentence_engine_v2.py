"""
FOUNDRY SENTENCE ENGINE v2.0 - COMPLETE FORMULA
================================================
Dynamic sentence generation using:
- Gate.Line.Color.Tone.Base (from calculations)
- Degree/Minute/Second (precise ecliptic position)
- Axis (0-360° position)
- Zodiac Sign (which sign it's in)
- House (which life domain)
- Knowledge Base (semantic source - Ra's work)

NO PRE-WRITTEN TEMPLATES - All sentences generated dynamically from:
1. Calculated astronomical positions
2. Knowledge base semantic data
3. Your sentence formula

Author: Celestial
"""

import json
from typing import Dict, Optional, List
from pathlib import Path
import math

class FoundrySentenceEngine:
    """
    Generates consciousness sentences from calculated activations.
    Uses your exact formula with degree/minute/second precision.
    """
    
    def __init__(self, knowledge_base_path: str):
        """Load the knowledge base"""
        with open(knowledge_base_path, 'r') as f:
            self.kb = json.load(f)
        
        # Extract semantic components
        self.gates = self.kb.get('gates', {})
        self.colors = self.kb.get('colors', {})
        self.tones = self.kb.get('tones', {})
        self.bases = self.kb.get('bases', {})
        self.zodiac_info = self.kb.get('zodiac', {})
        
        print(f"✓ Sentence Engine loaded: {len(self.gates)} gates, "
              f"{len(self.colors)} colors, {len(self.tones)} tones, {len(self.bases)} bases")
    
    def generate_sentence(self, activation: Dict, style: str = 'sovereign') -> str:
        """
        Generate sentence using YOUR EXACT FORMULA:
        
        [Degree°Minute'Second"] on [Axis] in [Zodiac Sign] 
        through [House] house:
        "I AM [Gate essence] [Line quality], 
        motivated by [Color], sensing via [Tone], 
        grounded in [Base] environment"
        
        activation = {
            'gate': 41,
            'line': 3,
            'color': 2,
            'tone': 5,
            'base': 1,
            'signature': '41.3.2.5.1',
            'frequency': 642.5,
            'planet': 'sun',
            'planet_position': {
                'longitude': 175.5432,      # Ecliptic longitude (0-360°)
                'zodiac_sign': 'Virgo',
                'degrees_in_sign': 25,
                'minutes': 32,
                'seconds': 35.52,
                'zodiac_position': '25°32\'35.52" Virgo',
                'house': 10
            }
        }
        
        Styles:
        - 'sovereign': Full formula with all layers
        - 'direct': Stripped down essence
        - 'narrative': Story-like flow
        - 'technical': Precise coordinates
        """
        
        # Extract astronomical data
        planet_pos = activation.get('planet_position', {})
        axis = planet_pos.get('longitude', 0)  # 0-360° ecliptic position
        degrees = planet_pos.get('degrees_in_sign', 0)
        minutes = planet_pos.get('minutes', 0)
        seconds = planet_pos.get('seconds', 0)
        zodiac = planet_pos.get('zodiac_sign', 'Unknown')
        house = planet_pos.get('house', 0)
        
        # Extract activation data
        gate_num = str(activation['gate'])
        line_num = str(activation['line'])
        color_num = str(activation['color'])
        tone_num = str(activation['tone'])
        base_num = str(activation['base'])
        
        # Get semantic data from knowledge base
        gate_data = self.gates.get(gate_num, {})
        color_data = self.colors.get(color_num, {})
        tone_data = self.tones.get(tone_num, {})
        base_data = self.bases.get(base_num, {})
        
        # Generate based on style
        if style == 'sovereign':
            return self._generate_sovereign_formula(
                axis, degrees, minutes, seconds, zodiac, house,
                gate_data, line_num, color_data, tone_data, base_data,
                activation
            )
        elif style == 'direct':
            return self._generate_direct(gate_data, color_data, line_num)
        elif style == 'narrative':
            return self._generate_narrative(
                gate_data, line_num, color_data, tone_data, base_data,
                zodiac, house, activation
            )
        elif style == 'technical':
            return self._generate_technical_precise(activation, planet_pos)
        else:
            return self._generate_sovereign_formula(
                axis, degrees, minutes, seconds, zodiac, house,
                gate_data, line_num, color_data, tone_data, base_data,
                activation
            )
    
    def _generate_sovereign_formula(self, axis, degrees, minutes, seconds, 
                                    zodiac, house, gate_data, line_num,
                                    color_data, tone_data, base_data, activation):
        """
        YOUR EXACT FORMULA:
        
        • [259°50′54″]: "I AM creative" → *foundation*, 
          (motivated by desire) – sensing via inner-vision; 
          {grounded in markets} °
        
        Translated to:
        [D°M'S"] at [AXIS]° in [ZODIAC] through [HOUSE]:
        "I AM [GATE] [LINE]", 
        motivated by [COLOR], sensing via [TONE], 
        grounded in [BASE]
        """
        
        # Format DMS
        dms = f"{degrees}°{minutes}'{seconds:.0f}\""
        
        # Format axis (full ecliptic longitude)
        axis_degrees = int(axis)
        axis_minutes = int((axis - axis_degrees) * 60)
        axis_seconds = ((axis - axis_degrees) * 60 - axis_minutes) * 60
        axis_formatted = f"{axis_degrees}°{axis_minutes}'{axis_seconds:.0f}\""
        
        # Gate essence
        gate_keywords = gate_data.get('keywords', [])
        gate_name = gate_data.get('name', f"Gate {activation['gate']}")
        gate_essence = self._extract_essence(gate_keywords, gate_name)
        
        # Line quality
        line_quality = self._get_line_theme(line_num)
        
        # Color motivation
        color_name = color_data.get('name', 'unknown')
        color_motivation = color_data.get('motivation', color_name.lower())
        
        # Tone sensing
        tone_name = tone_data.get('name', 'unknown')
        tone_sense = tone_data.get('sense', tone_name.lower())
        
        # Base environment
        base_name = base_data.get('name', 'unknown')
        base_env = base_data.get('environment', base_name.lower())
        
        # House domain
        house_domain = self._get_house_name(house)
        
        # Construct sovereign sentence
        sentence = (
            f"• [{dms} at {axis_formatted}]: "
            f'"I AM {gate_essence}" → *{line_quality}*, '
            f"(motivated by {color_motivation}) – "
            f"sensing via {tone_sense}; "
            f"{{grounded in {base_env}}} "
            f"in {zodiac} through {house_domain} °"
        )
        
        return sentence
    
    def _generate_direct(self, gate_data, color_data, line_num):
        """
        Direct essence statement:
        "I AM [essence], motivated by [color]"
        """
        gate_keywords = gate_data.get('keywords', [])
        gate_name = gate_data.get('name', 'expression')
        essence = self._extract_essence(gate_keywords, gate_name)
        
        color_motivation = color_data.get('motivation', 'desire')
        
        return f"I AM {essence}, motivated by {color_motivation}"
    
    def _generate_narrative(self, gate_data, line_num, color_data, 
                           tone_data, base_data, zodiac, house, activation):
        """
        Natural story flow:
        "Your [gate] expresses through [line], driven by [color],
         perceived through [tone], anchored in [base],
         manifesting in [zodiac] through [house]"
        """
        gate_keywords = gate_data.get('keywords', [])
        gate_name = gate_data.get('name', 'expression')
        essence = self._extract_essence(gate_keywords, gate_name)
        
        line_theme = self._get_line_theme(line_num)
        color_feeling = color_data.get('keywords', [])[0] if color_data.get('keywords') else 'desire'
        tone_quality = tone_data.get('keywords', [])[0] if tone_data.get('keywords') else 'awareness'
        base_space = base_data.get('environment', 'space')
        house_meaning = self._get_house_meaning(house)
        
        planet = activation.get('planet', 'energy')
        
        return (
            f"Your {essence} expresses through {line_theme}, "
            f"driven by {color_feeling}, "
            f"perceived through {tone_quality}, "
            f"anchored in {base_space}, "
            f"manifesting via {planet} in {zodiac} "
            f"through {house_meaning}"
        )
    
    def _generate_technical_precise(self, activation, planet_pos):
        """
        Technical format with all coordinates:
        
        Gate.Line.Color.Tone.Base @ D°M'S" (Axis) in Sign/House
        Frequency: XHz via Planet
        """
        sig = activation.get('signature', 'unknown')
        freq = activation.get('frequency', 0)
        planet = activation.get('planet', 'unknown')
        
        dms = f"{planet_pos.get('degrees_in_sign', 0)}°" \
              f"{planet_pos.get('minutes', 0)}'" \
              f"{planet_pos.get('seconds', 0):.0f}\""
        
        axis = planet_pos.get('longitude', 0)
        zodiac = planet_pos.get('zodiac_sign', 'unknown')
        house = planet_pos.get('house', 0)
        
        return (
            f"{sig} @ {dms} ({axis:.4f}°) "
            f"in {zodiac}/House {house} "
            f"| {freq:.2f}Hz via {planet}"
        )
    
    def _extract_essence(self, keywords: List[str], gate_name: str) -> str:
        """Extract core essence from keywords or gate name"""
        if keywords:
            # Clean up keywords (remove newlines, extra spaces)
            cleaned = [kw.replace('\n', ' ').strip() for kw in keywords]
            # Return first substantive keyword
            for kw in cleaned:
                if len(kw) > 2 and 'channel' not in kw.lower():
                    return kw.lower()
        
        # Fallback to gate name
        return gate_name.lower().replace(' c', '').strip()
    
    def _get_line_theme(self, line_num: str) -> str:
        """Get line thematic quality"""
        line_themes = {
            '1': 'foundation',
            '2': 'natural genius',
            '3': 'experimentation',
            '4': 'externalization',
            '5': 'universalization',
            '6': 'transition'
        }
        return line_themes.get(line_num, 'expression')
    
    def _get_house_name(self, house: int) -> str:
        """Get house name"""
        house_names = {
            1: 'the 1st (self)',
            2: 'the 2nd (resources)',
            3: 'the 3rd (communication)',
            4: 'the 4th (foundation)',
            5: 'the 5th (creativity)',
            6: 'the 6th (service)',
            7: 'the 7th (partnership)',
            8: 'the 8th (transformation)',
            9: 'the 9th (expansion)',
            10: 'the 10th (career)',
            11: 'the 11th (community)',
            12: 'the 12th (transcendence)'
        }
        return house_names.get(house, f'the {house}th house')
    
    def _get_house_meaning(self, house: int) -> str:
        """Get house meaning for narrative"""
        house_meanings = {
            1: 'the realm of identity',
            2: 'the domain of value',
            3: 'the space of exchange',
            4: 'the ground of being',
            5: 'the joy of expression',
            6: 'the path of refinement',
            7: 'the mirror of relationship',
            8: 'the depth of power',
            9: 'the horizon of meaning',
            10: 'the peak of achievement',
            11: 'the field of vision',
            12: 'the ocean of surrender'
        }
        return house_meanings.get(house, 'life experience')
    
    def generate_state_sentences(self, activation: Dict) -> Dict:
        """
        Generate sentences for all three consciousness states:
        - Distortion (not-self, shadow)
        - Resonance (aligned, gift)
        - Convergence (mastery, siddhi)
        
        Uses knowledge base power expressions + activation data
        """
        gate_num = str(activation['gate'])
        gate_data = self.gates.get(gate_num, {})
        power_exp = gate_data.get('power_expressions', {})
        
        # Get color and tone for context
        color_data = self.colors.get(str(activation['color']), {})
        tone_data = self.tones.get(str(activation['tone']), {})
        base_data = self.bases.get(str(activation['base']), {})
        
        color_motivation = color_data.get('motivation', 'desire')
        tone_sense = tone_data.get('sense', 'awareness')
        base_env = base_data.get('environment', 'space')
        
        gate_essence = self._extract_essence(
            gate_data.get('keywords', []),
            gate_data.get('name', 'expression')
        )
        
        # Build state-specific sentences
        states = {}
        
        # DISTORTION (Shadow)
        distortion = power_exp.get('distortion', {})
        states['distortion'] = {
            'feels': distortion.get('feels', f'Blocked {gate_essence}'),
            'looks': distortion.get('looks', 'Struggling with expression'),
            'scenarios': distortion.get('scenarios', 'When alignment is lost'),
            'sentence': (
                f"When {gate_essence} is distorted, "
                f"your {color_motivation} becomes misaligned, "
                f"your {tone_sense} perception clouded, "
                f"seeking {base_env} that don't nourish"
            )
        }
        
        # RESONANCE (Gift)
        resonance = power_exp.get('resonance', {})
        states['resonance'] = {
            'feels': resonance.get('feels', f'Natural {gate_essence}'),
            'looks': resonance.get('looks', 'Aligned expression'),
            'scenarios': resonance.get('scenarios', 'Living your design'),
            'sentence': (
                f"When {gate_essence} flows naturally, "
                f"your {color_motivation} guides you truly, "
                f"your {tone_sense} perception clear, "
                f"finding {base_env} that support your nature"
            )
        }
        
        # CONVERGENCE (Siddhi)
        convergence = power_exp.get('convergence', {})
        states['convergence'] = {
            'feels': convergence.get('feels', f'Effortless {gate_essence}'),
            'looks': convergence.get('looks', 'Magnetic mastery'),
            'scenarios': convergence.get('scenarios', 'Teaching through being'),
            'sentence': (
                f"In mastery, {gate_essence} becomes effortless, "
                f"your {color_motivation} serves the whole, "
                f"your {tone_sense} perception transcendent, "
                f"{base_env} arising spontaneously to meet you"
            )
        }
        
        return states
    
    def generate_complete_reading(self, activations: List[Dict]) -> Dict:
        """
        Generate a complete consciousness reading from all activations.
        
        Returns:
        {
            'primary_sentence': Main sovereign sentence,
            'supporting_sentences': List of other activation sentences,
            'state_guidance': Current state analysis,
            'frequency_analysis': Harmonic/dissonant patterns
        }
        """
        if not activations:
            return {'error': 'No activations provided'}
        
        # Primary activation (typically first/strongest)
        primary = activations[0]
        
        # Generate primary sentence
        primary_sentence = self.generate_sentence(primary, style='sovereign')
        
        # Generate supporting sentences
        supporting = [
            self.generate_sentence(act, style='narrative')
            for act in activations[1:5]  # Limit to 4 supporting
        ]
        
        # Analyze state
        primary_states = self.generate_state_sentences(primary)
        
        # Calculate frequency analysis
        frequencies = [act.get('frequency', 0) for act in activations]
        avg_freq = sum(frequencies) / len(frequencies) if frequencies else 0
        
        return {
            'primary_sentence': primary_sentence,
            'supporting_sentences': supporting,
            'state_guidance': primary_states,
            'frequency_analysis': {
                'average': avg_freq,
                'range': (min(frequencies), max(frequencies)) if frequencies else (0, 0),
                'count': len(frequencies)
            },
            'activation_count': len(activations)
        }


# ============================================================================
# EXAMPLE USAGE & TESTING
# ============================================================================

if __name__ == "__main__":
    import sys
    
    # Load sentence engine
    kb_path = '/mnt/user-data/uploads/knowledge_base_enriched.json'
    if not Path(kb_path).exists():
        print(f"❌ Knowledge base not found at {kb_path}")
        sys.exit(1)
    
    engine = FoundrySentenceEngine(kb_path)
    
    # Example activation with FULL astronomical data
    sample_activation = {
        'gate': 41,
        'line': 3,
        'color': 2,
        'tone': 5,
        'base': 1,
        'signature': '41.3.2.5.1',
        'frequency': 642.5,
        'planet': 'sun',
        'planet_position': {
            'longitude': 175.5432,           # Ecliptic axis (0-360°)
            'latitude': 0.0,
            'zodiac_sign': 'Virgo',
            'degrees_in_sign': 25,           # Position within sign
            'minutes': 32,
            'seconds': 35.52,
            'zodiac_position': '25°32\'35.52" Virgo',
            'house': 10
        }
    }
    
    print("🔥 FOUNDRY SENTENCE ENGINE v2.0")
    print("=" * 80)
    print()
    
    print("📍 ACTIVATION DATA:")
    print(f"  Signature: {sample_activation['signature']}")
    print(f"  Axis: {sample_activation['planet_position']['longitude']:.4f}°")
    print(f"  Position: {sample_activation['planet_position']['zodiac_position']}")
    print(f"  House: {sample_activation['planet_position']['house']}")
    print(f"  Planet: {sample_activation['planet']}")
    print()
    
    print("📝 GENERATED SENTENCES:")
    print()
    
    print("🏛️  SOVEREIGN FORMULA:")
    print(f"  {engine.generate_sentence(sample_activation, 'sovereign')}")
    print()
    
    print("💎 DIRECT:")
    print(f"  {engine.generate_sentence(sample_activation, 'direct')}")
    print()
    
    print("📖 NARRATIVE:")
    print(f"  {engine.generate_sentence(sample_activation, 'narrative')}")
    print()
    
    print("🔬 TECHNICAL:")
    print(f"  {engine.generate_sentence(sample_activation, 'technical')}")
    print()
    
    print("🔄 STATE SENTENCES:")
    states = engine.generate_state_sentences(sample_activation)
    for state_name, state_data in states.items():
        print(f"\n  {state_name.upper()}:")
        print(f"    {state_data['sentence']}")
    
    print()
    print("✅ Sentence engine operational")
    print("   Sentences generated dynamically from:")
    print("   • Calculated activations (Gate.Line.Color.Tone.Base)")
    print("   • Astronomical positions (Degree/Minute/Second, Axis, Zodiac, House)")
    print("   • Knowledge base (Ra's semantic data)")
    print("   • NO pre-written templates")
