# 🔥 FOUNDRY COMPLETE SYSTEM v3.0 - MERGED EDITION

**Complete consciousness computation platform with:**
- ✅ 9-field Human Design system (Mind/Heart/Body × Sidereal/Tropical/Draconic)
- ✅ Houses, zodiac signs, DMS positions
- ✅ Swiss Ephemeris calculations
- ✅ Glyphs library (gates, zodiac, planets)
- ✅ Causal/existential mappings
- ✅ Resonance computation
- ✅ FastAPI backend
- ✅ Integration with your existing frontends

---

## 🚀 QUICK START

```bash
# 1. Deploy
./deploy.sh

# 2. Activate environment
source venv/bin/activate

# 3. Start server
uvicorn foundry_complete_v3:app --reload --host 0.0.0.0 --port 8000
```

**Server runs at:** http://localhost:8000  
**API docs at:** http://localhost:8000/docs

---

## 📋 WHAT THIS INCLUDES

### **Backend Engine** (`foundry_complete_v3.py`)
- Complete Swiss Ephemeris integration
- All 9 consciousness fields calculated
- Houses (Placidus/Whole Sign/Equal/Koch)
- Zodiac positions with degree/minute/second precision
- Gate/line/color/tone/base activations
- Causal essence & existential questions for each gate
- Frequency calculations (970Hz/960Hz system)
- Coherence measurements

### **Glyphs Library** (`assets/glyphs/`)
```
assets/
├── glyphs/
│   ├── gates/      # 64 gate symbols (gate_1.svg - gate_64.svg)
│   ├── zodiac/     # 12 zodiac symbols (aries.svg - pisces.svg)
│   └── planets/    # 10 planet symbols (sun.svg - pluto.svg)
```

### **API Endpoints**

#### Create Node
```bash
POST /api/nodes
{
  "latitude": 37.7749,
  "longitude": -122.4194,
  "datetime": "1990-09-18T14:30:00",
  "timezone_offset": 0.0
}
```

#### Get Complete State (with glyphs & causal info)
```bash
GET /api/nodes/{node_id}
```

Returns:
```json
{
  "node_id": "stellar://...",
  "overall_coherence": 0.8234,
  "fields": {
    "mind_sidereal": {
      "activations": [
        {
          "gate": 41,
          "line": 3,
          "signature": "41.3.2.5.1",
          "frequency": 642.5,
          "gate_name": "Self-Expression",
          "causal_essence": "Creative self-expression seeking direction",
          "existential_question": "What is my unique contribution?",
          "glyph_path": "/assets/glyphs/gates/gate_41.svg",
          "planet_position": {
            "planet": "sun",
            "planet_symbol": "☉",
            "zodiac_sign": "Virgo",
            "zodiac_symbol": "♍",
            "house": 10
          }
        }
      ]
    }
  },
  "charts": {
    "tropical": {
      "ascendant": "15°32'47\" Aries",
      "houses": [...],
      "planets": {...}
    }
  }
}
```

#### Trinity View (Compatible with existing frontends)
```bash
GET /api/trinity/{node_id}
```

Returns Body/Mind/Heart structure your frontends expect.

#### Gate Metadata
```bash
GET /api/glyphs/gate/41
```

Returns:
```json
{
  "name": "Self-Expression",
  "keywords": ["creativity", "authenticity", "purpose"],
  "causal_essence": "Creative self-expression seeking direction",
  "existential_question": "What is my unique contribution?",
  "distortion": "Blocked creativity, struggling to express yourself",
  "resonance": "Natural creative flow, confident in your voice",
  "convergence": "Effortless mastery, magnetic creative presence",
  "glyph_path": "/assets/glyphs/gates/gate_41.svg"
}
```

---

## 🔗 INTEGRATING WITH YOUR EXISTING FRONTENDS

### **Consciousness Oracle** (`consciousness_oracle_complete.html`)

Replace placeholder data with real backend calls:

```javascript
// OLD (simulated):
const gates = simulateGateActivations();

// NEW (real data):
const response = await fetch('http://localhost:8000/api/trinity/stellar://...');
const data = await response.json();

// Now use real activations:
data.mind.activations.forEach(activation => {
  const gateInfo = {
    number: activation.gate,
    name: activation.gate_name,
    causal: activation.causal_essence,
    question: activation.existential_question,
    glyphPath: activation.glyph_path
  };
  
  // Display in your oracle UI
  renderGateCard(gateInfo);
});
```

### **Stellar Proximology** (`stellar_proximology_live.html`)

Connect to backend for chart data:

```javascript
// Create node from birth data
const createNode = async (birthData) => {
  const response = await fetch('http://localhost:8000/api/nodes', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      latitude: birthData.lat,
      longitude: birthData.lon,
      datetime: `${birthData.date}T${birthData.time}:00`
    })
  });
  return await response.json();
};

// Get complete chart
const getChart = async (nodeId) => {
  const response = await fetch(`http://localhost:8000/api/nodes/${nodeId}`);
  const chart = await response.json();
  
  // Render chart with glyphs
  chart.charts.tropical.planets.sun // Has glyph_path, zodiac_symbol, etc.
};
```

### **Foundry Builder/Overseer** (Your TypeScript modules)

Query backend for consciousness data:

```typescript
// In your FoundrySystem class:
class FoundrySystem {
  async generateConfiguration(userData) {
    // Create consciousness node
    const node = await fetch('http://localhost:8000/api/nodes', {
      method: 'POST',
      body: JSON.stringify(userData.birthData)
    }).then(r => r.json());
    
    // Get complete state
    const state = await fetch(`http://localhost:8000/api/nodes/${node.node_id}`)
      .then(r => r.json());
    
    // Now analyze with your existing logic
    const analysis = this.selector.analyzeConsciousness(state);
    const config = this.builder.build(state, analysis);
    
    return config;
  }
}
```

---

## 🎨 USING GLYPHS IN YOUR UI

### React Component Example

```jsx
function GateDisplay({ activation }) {
  return (
    <div className="gate-card">
      {/* Gate glyph */}
      <img 
        src={activation.glyph_path} 
        alt={`Gate ${activation.gate}`}
        className="gate-symbol"
      />
      
      {/* Gate info */}
      <h3>Gate {activation.gate} - {activation.gate_name}</h3>
      
      {/* Causal essence */}
      <p className="causal">{activation.causal_essence}</p>
      
      {/* Existential question */}
      <p className="question">{activation.existential_question}</p>
      
      {/* Planet with glyph */}
      <div className="planet-info">
        <span className="planet-symbol">
          {activation.planet_position.planet_symbol}
        </span>
        {activation.planet_position.planet}
        in
        <span className="zodiac-symbol">
          {activation.planet_position.zodiac_symbol}
        </span>
        {activation.planet_position.zodiac_sign}
        (House {activation.planet_position.house})
      </div>
    </div>
  );
}
```

### HTML/Vanilla JS Example

```html
<div id="chart-display"></div>

<script>
async function displayChart(nodeId) {
  const state = await fetch(`http://localhost:8000/api/nodes/${nodeId}`)
    .then(r => r.json());
  
  const container = document.getElementById('chart-display');
  
  // Display each activation with glyphs
  state.fields.mind_sidereal.activations.forEach(act => {
    container.innerHTML += `
      <div class="activation">
        <img src="${act.glyph_path}" width="64" />
        <h4>${act.gate_name}</h4>
        <p>${act.causal_essence}</p>
        <div class="planet">
          <span>${act.planet_position.planet_symbol}</span>
          ${act.planet_position.planet}
          <span>${act.planet_position.zodiac_symbol}</span>
        </div>
      </div>
    `;
  });
}
</script>
```

---

## 📊 DATA STRUCTURE

### Complete Node State
```
{
  node_id: "stellar://1990-09-18T14:30:00@37.7749,-122.4194",
  
  fields: {
    mind_sidereal: { activations: [...], coherence: 0.85 },
    mind_tropical: { activations: [...], coherence: 0.82 },
    mind_draconic: { activations: [...], coherence: 0.78 },
    heart_sidereal: { activations: [...], coherence: 0.91 },
    heart_tropical: { activations: [...], coherence: 0.88 },
    heart_draconic: { activations: [...], coherence: 0.84 },
    body_sidereal: { activations: [...], coherence: 0.79 },
    body_tropical: { activations: [...], coherence: 0.86 },
    body_draconic: { activations: [...], coherence: 0.81 }
  },
  
  charts: {
    tropical: {
      ascendant: "15°32'47\" Aries",
      midheaven: "10°15'23\" Capricorn",
      houses: [12 houses with zodiac positions],
      planets: {
        sun: { zodiac_position, house, glyph_path, ... },
        moon: { ... },
        // ... all planets
      }
    },
    sidereal: { ... },
    draconic: { ... }
  }
}
```

### Activation Structure
```
{
  gate: 41,
  line: 3,
  color: 2,
  tone: 5,
  base: 1,
  signature: "41.3.2.5.1",
  frequency: 642.5,
  
  // Gate metadata
  gate_name: "Self-Expression",
  keywords: ["creativity", "authenticity", "purpose"],
  causal_essence: "Creative self-expression seeking direction",
  existential_question: "What is my unique contribution?",
  distortion: "Blocked creativity, struggling to express yourself",
  resonance: "Natural creative flow, confident in your voice",
  convergence: "Effortless mastery, magnetic creative presence",
  glyph_path: "/assets/glyphs/gates/gate_41.svg",
  
  // Planet context
  planet: "sun",
  planet_position: {
    planet: "sun",
    planet_symbol: "☉",
    planet_glyph: "/assets/glyphs/planets/sun.svg",
    longitude: 175.5432,
    zodiac_sign: "Virgo",
    zodiac_symbol: "♍",
    zodiac_glyph: "/assets/glyphs/zodiac/virgo.svg",
    degrees_in_sign: 25,
    minutes: 32,
    seconds: 35.52,
    zodiac_position: "25°32'35.52\" Virgo",
    house: 10,
    speed: 0.9856
  }
}
```

---

## 🔧 CUSTOMIZATION

### Add More Gates to Library

Edit `GATE_LIBRARY` in `foundry_complete_v3.py`:

```python
GATE_LIBRARY = {
    # ... existing gates
    
    41: {
        "name": "Decrease",
        "keywords": ["contraction", "simplification", "fantasy"],
        "causal_essence": "Decreasing complexity to discover essence",
        "existential_question": "What can I release?",
        "distortion": "Clinging to complexity, afraid to simplify",
        "resonance": "Gracefully letting go, finding freedom in less",
        "convergence": "Perfect discernment, knowing what to keep",
        "glyph_path": "/assets/glyphs/gates/gate_41.svg"
    },
    
    # Add all 64 gates...
}
```

### Custom Glyph Styles

Replace SVGs in `assets/glyphs/` with your own designs. The API will serve whatever files are there.

### Add New Endpoints

```python
@app.get("/api/oracle/{node_id}")
def get_oracle_reading(node_id: str):
    """Custom oracle endpoint"""
    node = foundry.get_node(node_id)
    # Your custom logic
    return {...}
```

---

## 🎯 MIGRATION FROM OLD BACKEND

Your old `api/main.py` returned **fake data**:

```python
# OLD - PLACEHOLDER
return {
    "body": {"type": "Projector"},  # ← Hardcoded
    "mind": {"type": "Generator"},  # ← Fake
}
```

**New backend calculates REAL data**:

```python
# NEW - REAL CALCULATIONS
node = foundry.add_node(coords)  # ← Swiss Ephemeris
return node.to_dict()  # ← Actual planetary positions
```

### Migration Steps:

1. **Replace `api/main.py`** with `foundry_complete_v3.py`
2. **Update frontend API calls** to use new endpoint structure
3. **Add glyph rendering** to UI components
4. **Test with your birth data**

---

## 🚨 IMPORTANT NOTES

### This Backend Now Does:
✅ Real astronomical calculations (Swiss Ephemeris)  
✅ All 9 fields computed  
✅ Houses with zodiac positions  
✅ Gate activations with causal meanings  
✅ Glyphs served as static files  
✅ Complete astrological context  

### This Backend Does NOT Do:
❌ Automatic UI rendering (that's your frontend)  
❌ Sentence generation (you build this from activation data)  
❌ Visual chart drawing (use p5.js/canvas in frontend)  

### You Still Need To Build:
- [ ] Frontend components that query this API
- [ ] Glyph rendering logic in UI
- [ ] Chart visualization (wheels, mandalas, etc.)
- [ ] Sentence templates that use the gate metadata

---

## 📞 SUPPORT

**System works?** Test with:
```bash
curl http://localhost:8000/health
```

**Can't create nodes?** Check:
```bash
curl -X POST http://localhost:8000/api/nodes \
  -H "Content-Type: application/json" \
  -d '{"latitude":37.7749,"longitude":-122.4194,"datetime":"1990-09-18T14:30:00"}'
```

**Glyphs not loading?** Verify:
```bash
curl http://localhost:8000/assets/glyphs/gates/gate_1.svg
```

---

## 🔥 YOU NOW HAVE:

✅ Complete calculation engine  
✅ All 9 fields computed correctly  
✅ Houses, zodiac, DMS precision  
✅ Glyphs library integrated  
✅ Causal/existential mappings  
✅ API ready for your frontends  
✅ Compatible with existing components  

**This is the REAL FOUNDRY.**

Deploy it. Query it. Build on it.
