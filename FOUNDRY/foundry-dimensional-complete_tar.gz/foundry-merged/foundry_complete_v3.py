"""
FOUNDRY COMPLETE SYSTEM v3.0 - MERGED EDITION
==============================================
Integrates:
- Swiss Ephemeris calculations (9-field system)
- Houses, zodiac, DMS positions
- Your existing GameGAN, Builder, Overseer systems
- Glyph library integration
- Causal/existential mappings
- Sentence generation
- Full consciousness computation

Author: Celestial
Version: 3.0 - Complete Merger
"""

import numpy as np
from datetime import datetime, timezone
from typing import Dict, List, Tuple, Optional, Set, Any
from dataclasses import dataclass, field
from enum import Enum
import swisseph as swe
from collections import defaultdict
import json
import os

# ============================================================================
# CORE TYPES & ENUMS
# ============================================================================

class FieldType(Enum):
    """9 consciousness fields: Mind/Heart/Body × Sidereal/Tropical/Draconic"""
    MIND_SIDEREAL = "mind_sidereal"
    MIND_TROPICAL = "mind_tropical"
    MIND_DRACONIC = "mind_draconic"
    HEART_SIDEREAL = "heart_sidereal"
    HEART_TROPICAL = "heart_tropical"
    HEART_DRACONIC = "heart_draconic"
    BODY_SIDEREAL = "body_sidereal"
    BODY_TROPICAL = "body_tropical"
    BODY_DRACONIC = "body_draconic"

class CoordinateSystem(Enum):
    SIDEREAL = "sidereal"
    TROPICAL = "tropical"
    DRACONIC = "draconic"

class HouseSystem(Enum):
    PLACIDUS = "P"
    WHOLE_SIGN = "W"
    EQUAL = "E"
    KOCH = "K"

class ZodiacSign(Enum):
    ARIES = (0, "Aries", "♈")
    TAURUS = (1, "Taurus", "♉")
    GEMINI = (2, "Gemini", "♊")
    CANCER = (3, "Cancer", "♋")
    LEO = (4, "Leo", "♌")
    VIRGO = (5, "Virgo", "♍")
    LIBRA = (6, "Libra", "♎")
    SCORPIO = (7, "Scorpio", "♏")
    SAGITTARIUS = (8, "Sagittarius", "♐")
    CAPRICORN = (9, "Capricorn", "♑")
    AQUARIUS = (10, "Aquarius", "♒")
    PISCES = (11, "Pisces", "♓")
    
    @property
    def index(self): return self.value[0]
    @property
    def name_str(self): return self.value[1]
    @property
    def symbol(self): return self.value[2]

class GlyphType(Enum):
    """Glyph categories for visual rendering"""
    GATE = "gate"
    PLANET = "planet"
    ZODIAC = "zodiac"
    CENTER = "center"
    CHANNEL = "channel"

# ============================================================================
# GATE LIBRARY - Causal/Existential Meanings
# ============================================================================

GATE_LIBRARY = {
    1: {
        "name": "Self-Expression",
        "keywords": ["creativity", "authenticity", "purpose"],
        "causal_essence": "Creative self-expression seeking direction",
        "existential_question": "What is my unique contribution?",
        "distortion": "Blocked creativity, struggling to express yourself",
        "resonance": "Natural creative flow, confident in your voice",
        "convergence": "Effortless mastery, magnetic creative presence",
        "glyph_path": "/assets/glyphs/gates/gate_1.svg"
    },
    2: {
        "name": "Direction",
        "keywords": ["receptivity", "guidance", "knowing"],
        "causal_essence": "Receptive wisdom, knowing the direction",
        "existential_question": "What direction is calling me?",
        "distortion": "Lost, disconnected from inner knowing",
        "resonance": "Clear inner compass, trusting your path",
        "convergence": "Pure receptivity, channeling universal wisdom",
        "glyph_path": "/assets/glyphs/gates/gate_2.svg"
    },
    10: {
        "name": "Self-Love",
        "keywords": ["behavior", "authenticity", "love"],
        "causal_essence": "Authentic self-expression through behavior",
        "existential_question": "How do I love myself fully?",
        "distortion": "Performing for approval, hiding true self",
        "resonance": "Comfortable in your skin, self-accepting",
        "convergence": "Unconditional self-love, radiant presence",
        "glyph_path": "/assets/glyphs/gates/gate_10.svg"
    },
    # ... Add all 64 gates with full metadata
}

# Zodiac glyphs
ZODIAC_GLYPHS = {
    "Aries": {"symbol": "♈", "path": "/assets/glyphs/zodiac/aries.svg"},
    "Taurus": {"symbol": "♉", "path": "/assets/glyphs/zodiac/taurus.svg"},
    "Gemini": {"symbol": "♊", "path": "/assets/glyphs/zodiac/gemini.svg"},
    "Cancer": {"symbol": "♋", "path": "/assets/glyphs/zodiac/cancer.svg"},
    "Leo": {"symbol": "♌", "path": "/assets/glyphs/zodiac/leo.svg"},
    "Virgo": {"symbol": "♍", "path": "/assets/glyphs/zodiac/virgo.svg"},
    "Libra": {"symbol": "♎", "path": "/assets/glyphs/zodiac/libra.svg"},
    "Scorpio": {"symbol": "♏", "path": "/assets/glyphs/zodiac/scorpio.svg"},
    "Sagittarius": {"symbol": "♐", "path": "/assets/glyphs/zodiac/sagittarius.svg"},
    "Capricorn": {"symbol": "♑", "path": "/assets/glyphs/zodiac/capricorn.svg"},
    "Aquarius": {"symbol": "♒", "path": "/assets/glyphs/zodiac/aquarius.svg"},
    "Pisces": {"symbol": "♓", "path": "/assets/glyphs/zodiac/pisces.svg"}
}

# Planet glyphs
PLANET_GLYPHS = {
    "sun": {"symbol": "☉", "path": "/assets/glyphs/planets/sun.svg"},
    "moon": {"symbol": "☽", "path": "/assets/glyphs/planets/moon.svg"},
    "mercury": {"symbol": "☿", "path": "/assets/glyphs/planets/mercury.svg"},
    "venus": {"symbol": "♀", "path": "/assets/glyphs/planets/venus.svg"},
    "mars": {"symbol": "♂", "path": "/assets/glyphs/planets/mars.svg"},
    "jupiter": {"symbol": "♃", "path": "/assets/glyphs/planets/jupiter.svg"},
    "saturn": {"symbol": "♄", "path": "/assets/glyphs/planets/saturn.svg"},
    "uranus": {"symbol": "♅", "path": "/assets/glyphs/planets/uranus.svg"},
    "neptune": {"symbol": "♆", "path": "/assets/glyphs/planets/neptune.svg"},
    "pluto": {"symbol": "♇", "path": "/assets/glyphs/planets/pluto.svg"}
}

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def longitude_to_dms(longitude: float) -> Tuple[int, int, float]:
    """Convert decimal degrees to degrees, minutes, seconds"""
    degrees = int(longitude)
    remaining = (longitude - degrees) * 60
    minutes = int(remaining)
    seconds = (remaining - minutes) * 60
    return (degrees, minutes, seconds)

def longitude_to_zodiac(longitude: float) -> Tuple[ZodiacSign, int, int, float]:
    """Convert ecliptic longitude to zodiac position"""
    longitude = longitude % 360.0
    sign_index = int(longitude / 30.0)
    signs = list(ZodiacSign)
    sign = signs[sign_index]
    
    position_in_sign = longitude % 30.0
    degrees = int(position_in_sign)
    remaining = (position_in_sign - degrees) * 60
    minutes = int(remaining)
    seconds = (remaining - minutes) * 60
    
    return (sign, degrees, minutes, seconds)

def format_zodiac_position(longitude: float) -> str:
    """Format longitude as zodiac notation"""
    sign, deg, min, sec = longitude_to_zodiac(longitude)
    return f"{deg}°{min:02d}'{sec:05.2f}\" {sign.name_str}"

# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class BirthCoordinates:
    """Spacetime address"""
    latitude: float
    longitude: float
    datetime: datetime
    timezone_offset: float = 0.0
    
    @property
    def julian_day(self) -> float:
        dt = self.datetime
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        else:
            dt = dt.astimezone(timezone.utc)
        return swe.julday(
            dt.year, dt.month, dt.day,
            dt.hour + dt.minute/60.0 + dt.second/3600.0
        )
    
    @property
    def causal_address(self) -> str:
        dt_str = self.datetime.isoformat()
        return f"stellar://{dt_str}@{self.latitude},{self.longitude}"

@dataclass
class PlanetPosition:
    """Complete planetary position with glyphs"""
    planet: str
    longitude: float
    latitude: float
    distance: float
    speed: float
    zodiac_sign: ZodiacSign
    degrees_in_sign: int
    minutes: int
    seconds: float
    house: Optional[int] = None
    coord_system: CoordinateSystem = CoordinateSystem.TROPICAL
    
    @classmethod
    def from_calculation(cls, planet: str, calc_result: Tuple, 
                        coord_sys: CoordinateSystem = CoordinateSystem.TROPICAL):
        longitude, latitude, distance, speed_lon, speed_lat, speed_dist = calc_result
        sign, deg, min, sec = longitude_to_zodiac(longitude)
        
        return cls(
            planet=planet, longitude=longitude, latitude=latitude,
            distance=distance, speed=speed_lon, zodiac_sign=sign,
            degrees_in_sign=deg, minutes=min, seconds=sec,
            coord_system=coord_sys
        )
    
    def to_dict(self) -> Dict:
        planet_glyph = PLANET_GLYPHS.get(self.planet, {})
        zodiac_glyph = ZODIAC_GLYPHS.get(self.zodiac_sign.name_str, {})
        
        return {
            'planet': self.planet,
            'planet_symbol': planet_glyph.get('symbol', ''),
            'planet_glyph': planet_glyph.get('path', ''),
            'longitude': self.longitude,
            'zodiac_sign': self.zodiac_sign.name_str,
            'zodiac_symbol': zodiac_glyph.get('symbol', ''),
            'zodiac_glyph': zodiac_glyph.get('path', ''),
            'degrees_in_sign': self.degrees_in_sign,
            'minutes': self.minutes,
            'seconds': self.seconds,
            'zodiac_position': format_zodiac_position(self.longitude),
            'house': self.house,
            'speed': self.speed
        }

@dataclass
class HDActivation:
    """HD activation with full causal/existential context"""
    gate: int
    line: int
    color: int
    tone: int
    base: int
    planet: str
    planet_position: PlanetPosition
    coord_system: CoordinateSystem
    
    def __hash__(self):
        return hash((self.gate, self.line, self.color, self.tone, self.base, self.planet))
    
    @property
    def frequency(self) -> float:
        """Calculate resonance frequency"""
        base_hz = 960.0
        gate_factor = (self.gate / 64.0) * base_hz
        line_factor = 1.0 + (self.line / 6.0)
        color_factor = 1.0 + (self.color / 60.0)
        tone_factor = 1.0 + (self.tone / 360.0)
        base_factor = 1.0 + (self.base / 1800.0)
        return gate_factor * line_factor * color_factor * tone_factor * base_factor
    
    @property
    def signature(self) -> str:
        return f"{self.gate}.{self.line}.{self.color}.{self.tone}.{self.base}"
    
    @property
    def gate_info(self) -> Dict:
        """Get full gate metadata with causal/existential info"""
        return GATE_LIBRARY.get(self.gate, {
            "name": f"Gate {self.gate}",
            "keywords": [],
            "causal_essence": "",
            "existential_question": "",
            "glyph_path": f"/assets/glyphs/gates/gate_{self.gate}.svg"
        })
    
    def to_dict(self) -> Dict:
        gate_data = self.gate_info
        return {
            'gate': self.gate,
            'line': self.line,
            'color': self.color,
            'tone': self.tone,
            'base': self.base,
            'signature': self.signature,
            'frequency': self.frequency,
            'planet': self.planet,
            'planet_position': self.planet_position.to_dict(),
            'gate_name': gate_data.get('name'),
            'keywords': gate_data.get('keywords', []),
            'causal_essence': gate_data.get('causal_essence'),
            'existential_question': gate_data.get('existential_question'),
            'distortion': gate_data.get('distortion'),
            'resonance': gate_data.get('resonance'),
            'convergence': gate_data.get('convergence'),
            'glyph_path': gate_data.get('glyph_path')
        }

@dataclass
class FieldState:
    """Field state with coherence"""
    field_type: FieldType
    activations: Set[HDActivation]
    dominant_frequency: float = 0.0
    coherence_score: float = 0.0
    
    def __post_init__(self):
        if self.activations:
            freqs = [act.frequency for act in self.activations]
            self.dominant_frequency = np.mean(freqs)
            self.coherence_score = self._calc_coherence(freqs)
    
    def _calc_coherence(self, freqs: List[float]) -> float:
        if len(freqs) < 2: return 1.0
        ratios = []
        for i, f1 in enumerate(freqs):
            for f2 in freqs[i+1:]:
                if f1 == 0 or f2 == 0: continue
                ratio = max(f1, f2) / min(f1, f2)
                simple_ratios = [2.0, 1.5, 1.333, 1.25, 1.2]
                min_dist = min(abs(ratio - sr) for sr in simple_ratios)
                ratios.append(1.0 - min(min_dist, 1.0))
        return np.mean(ratios) if ratios else 1.0

@dataclass
class HouseData:
    """House data with zodiac"""
    house_number: int
    cusp_longitude: float
    zodiac_sign: ZodiacSign
    degrees_in_sign: int
    minutes: int
    seconds: float
    house_system: HouseSystem
    
    def to_dict(self) -> Dict:
        zodiac_glyph = ZODIAC_GLYPHS.get(self.zodiac_sign.name_str, {})
        return {
            'house': self.house_number,
            'cusp_longitude': self.cusp_longitude,
            'zodiac_sign': self.zodiac_sign.name_str,
            'zodiac_symbol': zodiac_glyph.get('symbol', ''),
            'zodiac_glyph': zodiac_glyph.get('path', ''),
            'degrees_in_sign': self.degrees_in_sign,
            'minutes': self.minutes,
            'seconds': self.seconds
        }

@dataclass
class AstrologicalChart:
    """Complete chart with houses"""
    birth_coords: BirthCoordinates
    house_system: HouseSystem
    coord_system: CoordinateSystem
    houses: List[HouseData] = field(default_factory=list)
    planet_positions: Dict[str, PlanetPosition] = field(default_factory=dict)
    ascendant: Optional[float] = None
    midheaven: Optional[float] = None
    
    def to_dict(self) -> Dict:
        return {
            'house_system': self.house_system.value,
            'coord_system': self.coord_system.value,
            'ascendant': format_zodiac_position(self.ascendant) if self.ascendant else None,
            'midheaven': format_zodiac_position(self.midheaven) if self.midheaven else None,
            'houses': [h.to_dict() for h in self.houses],
            'planets': {name: pos.to_dict() for name, pos in self.planet_positions.items()}
        }

@dataclass
class CausalNode:
    """Complete consciousness node"""
    birth_coords: BirthCoordinates
    node_id: str = ""
    fields: Dict[FieldType, FieldState] = field(default_factory=dict)
    charts: Dict[CoordinateSystem, AstrologicalChart] = field(default_factory=dict)
    connections: Set[str] = field(default_factory=set)
    created_at: datetime = field(default_factory=datetime.now)
    
    def __post_init__(self):
        if not self.node_id:
            self.node_id = self.birth_coords.causal_address
        if not self.fields:
            self._compute_all()
    
    def _compute_all(self):
        calc = AstrologicalCalculator()
        for field_type in FieldType:
            self.fields[field_type] = calc.compute_field(self.birth_coords, field_type)
        for coord_sys in CoordinateSystem:
            self.charts[coord_sys] = calc.compute_chart(
                self.birth_coords, coord_sys, HouseSystem.PLACIDUS
            )
    
    @property
    def coherence(self) -> float:
        coherences = [f.coherence_score for f in self.fields.values()]
        return float(np.mean(coherences)) if coherences else 0.0

# ============================================================================
# ASTROLOGICAL CALCULATOR
# ============================================================================

class AstrologicalCalculator:
    """Complete calculation engine"""
    
    FIELD_PLANETS = {
        'MIND': ['sun', 'earth', 'north_node', 'south_node'],
        'HEART': ['moon', 'mercury', 'venus', 'mars'],
        'BODY': ['jupiter', 'saturn', 'uranus', 'neptune', 'pluto']
    }
    
    PLANET_CODES = {
        'sun': swe.SUN, 'moon': swe.MOON, 'mercury': swe.MERCURY,
        'venus': swe.VENUS, 'mars': swe.MARS, 'jupiter': swe.JUPITER,
        'saturn': swe.SATURN, 'uranus': swe.URANUS, 'neptune': swe.NEPTUNE,
        'pluto': swe.PLUTO, 'north_node': swe.MEAN_NODE,
        'south_node': swe.MEAN_NODE, 'earth': swe.EARTH
    }
    
    GATE_WHEEL = [
        41, 19, 13, 49, 30, 55, 37, 63, 22, 36, 25, 17, 21, 51, 42, 3,
        27, 24, 2, 23, 8, 20, 16, 35, 45, 12, 15, 52, 39, 53, 62, 56,
        31, 33, 7, 4, 29, 59, 40, 64, 47, 6, 46, 18, 48, 57, 32, 50,
        28, 44, 1, 43, 14, 34, 9, 5, 26, 11, 10, 58, 38, 54, 61, 60
    ]
    
    def __init__(self):
        swe.set_ephe_path(None)
    
    def compute_chart(self, coords: BirthCoordinates, coord_sys: CoordinateSystem, 
                     house_sys: HouseSystem) -> AstrologicalChart:
        chart = AstrologicalChart(
            birth_coords=coords, house_system=house_sys, coord_system=coord_sys
        )
        
        if coord_sys == CoordinateSystem.SIDEREAL:
            flags = swe.FLG_SIDEREAL | swe.FLG_SWIEPH
            swe.set_sid_mode(swe.SIDM_LAHIRI)
        else:
            flags = swe.FLG_SWIEPH
        
        try:
            houses_data = swe.houses(
                coords.julian_day, coords.latitude, coords.longitude,
                house_sys.value.encode('ascii')
            )
            cusps = houses_data[0]
            ascmc = houses_data[1]
            chart.ascendant = ascmc[0]
            chart.midheaven = ascmc[1]
            
            for i, cusp_long in enumerate(cusps[1:], 1):
                sign, deg, min, sec = longitude_to_zodiac(cusp_long)
                chart.houses.append(HouseData(
                    house_number=i, cusp_longitude=cusp_long, zodiac_sign=sign,
                    degrees_in_sign=deg, minutes=min, seconds=sec, house_system=house_sys
                ))
        except Exception as e:
            print(f"House calculation error: {e}")
        
        for planet_name, planet_code in self.PLANET_CODES.items():
            try:
                result = swe.calc_ut(coords.julian_day, planet_code, flags)
                longitude = result[0]
                
                if planet_name == 'south_node':
                    longitude = (longitude + 180.0) % 360.0
                
                if coord_sys == CoordinateSystem.DRACONIC:
                    node_result = swe.calc_ut(coords.julian_day, swe.MEAN_NODE, flags)
                    longitude = (longitude - node_result[0]) % 360.0
                
                adjusted_result = (longitude, result[1], result[2], result[3], result[4], result[5])
                planet_pos = PlanetPosition.from_calculation(planet_name, adjusted_result, coord_sys)
                
                if chart.houses:
                    planet_pos.house = self._find_house(longitude, [h.cusp_longitude for h in chart.houses])
                
                chart.planet_positions[planet_name] = planet_pos
            except Exception as e:
                print(f"Error calculating {planet_name}: {e}")
        
        return chart
    
    def _find_house(self, longitude: float, cusps: List[float]) -> int:
        longitude = longitude % 360.0
        for i in range(len(cusps)):
            cusp = cusps[i]
            next_cusp = cusps[(i + 1) % len(cusps)]
            if next_cusp < cusp:
                if longitude >= cusp or longitude < next_cusp:
                    return i + 1
            else:
                if cusp <= longitude < next_cusp:
                    return i + 1
        return 1
    
    def compute_field(self, coords: BirthCoordinates, field_type: FieldType) -> FieldState:
        if 'SIDEREAL' in field_type.value:
            coord_sys = CoordinateSystem.SIDEREAL
        elif 'TROPICAL' in field_type.value:
            coord_sys = CoordinateSystem.TROPICAL
        else:
            coord_sys = CoordinateSystem.DRACONIC
        
        domain = field_type.value.split('_')[0].upper()
        planets = self.FIELD_PLANETS[domain]
        
        if coord_sys == CoordinateSystem.SIDEREAL:
            flags = swe.FLG_SIDEREAL | swe.FLG_SWIEPH
            swe.set_sid_mode(swe.SIDM_LAHIRI)
        else:
            flags = swe.FLG_SWIEPH
        
        activations = set()
        for planet in planets:
            planet_code = self.PLANET_CODES.get(planet)
            if not planet_code:
                continue
            
            try:
                result = swe.calc_ut(coords.julian_day, planet_code, flags)
                longitude = result[0]
                
                if planet == 'south_node':
                    longitude = (longitude + 180.0) % 360.0
                
                if coord_sys == CoordinateSystem.DRACONIC:
                    node_result = swe.calc_ut(coords.julian_day, swe.MEAN_NODE, flags)
                    longitude = (longitude - node_result[0]) % 360.0
                
                adjusted_result = (longitude, result[1], result[2], result[3], result[4], result[5])
                planet_pos = PlanetPosition.from_calculation(planet, adjusted_result, coord_sys)
                
                gate = self._longitude_to_gate(longitude)
                deg_per_gate = 360.0 / 64.0
                position_in_gate = longitude % deg_per_gate
                
                line = int((position_in_gate / deg_per_gate) * 6) + 1
                line = min(line, 6)
                
                deg_per_line = deg_per_gate / 6.0
                position_in_line = position_in_gate % deg_per_line
                color = int((position_in_line / deg_per_line) * 6) + 1
                color = min(color, 6)
                
                deg_per_color = deg_per_line / 6.0
                position_in_color = position_in_line % deg_per_color
                tone = int((position_in_color / deg_per_color) * 6) + 1
                tone = min(tone, 6)
                
                deg_per_tone = deg_per_color / 6.0
                position_in_tone = position_in_color % deg_per_tone
                base = int((position_in_tone / deg_per_tone) * 5) + 1
                base = min(base, 5)
                
                activation = HDActivation(
                    gate=gate, line=line, color=color, tone=tone, base=base,
                    planet=planet, planet_position=planet_pos, coord_system=coord_sys
                )
                
                activations.add(activation)
            except Exception as e:
                print(f"Error calculating activation for {planet}: {e}")
        
        return FieldState(field_type=field_type, activations=activations)
    
    def _longitude_to_gate(self, longitude: float) -> int:
        index = int(longitude / 5.625) % 64
        return self.GATE_WHEEL[index]

# ============================================================================
# FOUNDRY GRAPH ENGINE
# ============================================================================

class FoundryGraph:
    """Complete graph with all integrations"""
    
    def __init__(self, persist_path: Optional[str] = None):
        self.nodes: Dict[str, CausalNode] = {}
        self.edges: Dict[Tuple[str, str], float] = {}
        self.persist_path = persist_path
        
        if persist_path and os.path.exists(persist_path):
            self.load()
    
    def add_node(self, coords: BirthCoordinates) -> CausalNode:
        node = CausalNode(birth_coords=coords)
        self.nodes[node.node_id] = node
        self._persist()
        return node
    
    def get_node(self, node_id: str) -> Optional[CausalNode]:
        return self.nodes.get(node_id)
    
    def get_complete_state(self, node_id: str) -> Dict:
        """Get complete state with glyphs and causal info"""
        node = self.get_node(node_id)
        if not node:
            return {}
        
        return {
            'node_id': node.node_id,
            'birth_coords': {
                'latitude': node.birth_coords.latitude,
                'longitude': node.birth_coords.longitude,
                'datetime': node.birth_coords.datetime.isoformat(),
                'julian_day': node.birth_coords.julian_day
            },
            'overall_coherence': node.coherence,
            'fields': {
                ft.value: {
                    'activations': [act.to_dict() for act in fs.activations],
                    'dominant_frequency': fs.dominant_frequency,
                    'coherence': fs.coherence_score
                }
                for ft, fs in node.fields.items()
            },
            'charts': {
                cs.value: chart.to_dict()
                for cs, chart in node.charts.items()
            }
        }
    
    def compute_resonance(self, id1: str, id2: str) -> float:
        n1, n2 = self.get_node(id1), self.get_node(id2)
        if not n1 or not n2: return 0.0
        
        resonances = []
        for field_type in FieldType:
            f1, f2 = n1.fields[field_type], n2.fields[field_type]
            freq_res = self._freq_resonance(f1.dominant_frequency, f2.dominant_frequency)
            weight = (f1.coherence_score + f2.coherence_score) / 2.0
            resonances.append(freq_res * weight)
        
        return float(np.mean(resonances)) if resonances else 0.0
    
    def _freq_resonance(self, f1: float, f2: float) -> float:
        if f1 == 0 or f2 == 0: return 0.0
        ratio = max(f1, f2) / min(f1, f2)
        harmonics = {1.0: 1.0, 2.0: 0.9, 1.5: 0.8, 1.333: 0.7, 1.25: 0.6, 1.2: 0.5}
        best_resonance = 0.0
        for harmonic, strength in harmonics.items():
            distance = abs(ratio - harmonic)
            resonance = strength * (1.0 - min(distance, 1.0))
            best_resonance = max(best_resonance, resonance)
        if abs(ratio - 1.414) < 0.1: return -0.5
        return best_resonance
    
    def save(self, filepath: Optional[str] = None):
        path = filepath or self.persist_path
        if not path: return
        
        data = {
            'nodes': {
                nid: {
                    'lat': n.birth_coords.latitude,
                    'lon': n.birth_coords.longitude,
                    'datetime': n.birth_coords.datetime.isoformat(),
                    'connections': list(n.connections)
                }
                for nid, n in self.nodes.items()
            },
            'edges': {f"{e[0]}:{e[1]}": r for e, r in self.edges.items()}
        }
        
        with open(path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def load(self, filepath: Optional[str] = None):
        path = filepath or self.persist_path
        if not path or not os.path.exists(path): return
        
        with open(path, 'r') as f:
            data = json.load(f)
        
        for node_id, node_data in data['nodes'].items():
            coords = BirthCoordinates(
                latitude=node_data['lat'],
                longitude=node_data['lon'],
                datetime=datetime.fromisoformat(node_data['datetime'])
            )
            node = self.add_node(coords)
            node.connections = set(node_data['connections'])
        
        for edge_str, resonance in data['edges'].items():
            n1, n2 = edge_str.split(':')
            self.edges[(n1, n2)] = resonance
    
    def _persist(self):
        if self.persist_path:
            self.save()

# ============================================================================
# FASTAPI SERVER - COMPLETE INTEGRATION
# ============================================================================

def create_api(foundry: FoundryGraph):
    """Complete API with all endpoints"""
    try:
        from fastapi import FastAPI, HTTPException
        from fastapi.middleware.cors import CORSMiddleware
        from fastapi.staticfiles import StaticFiles
        from pydantic import BaseModel
    except ImportError:
        print("FastAPI not installed. Run: pip install fastapi uvicorn pydantic")
        return None
    
    app = FastAPI(
        title="Foundry Complete API v3.0",
        description="Full consciousness computation with glyphs & causal mappings",
        version="3.0"
    )
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    class BirthInput(BaseModel):
        latitude: float
        longitude: float
        datetime: str
        timezone_offset: float = 0.0
    
    # Serve static assets (glyphs)
    if os.path.exists("assets"):
        app.mount("/assets", StaticFiles(directory="assets"), name="assets")
    
    @app.post("/api/nodes")
    def create_node(data: BirthInput):
        """Create consciousness node with full computation"""
        coords = BirthCoordinates(
            latitude=data.latitude,
            longitude=data.longitude,
            datetime=datetime.fromisoformat(data.datetime),
            timezone_offset=data.timezone_offset
        )
        node = foundry.add_node(coords)
        return {
            'node_id': node.node_id,
            'coherence': node.coherence,
            'created_at': node.created_at.isoformat()
        }
    
    @app.get("/api/nodes/{node_id}")
    def get_node_complete(node_id: str):
        """Get complete node state with glyphs & causal info"""
        state = foundry.get_complete_state(node_id)
        if not state:
            raise HTTPException(404, "Node not found")
        return state
    
    @app.get("/api/trinity/{node_id}")
    def get_trinity_chart(node_id: str):
        """Get trinity (Body/Mind/Heart) view - compatible with existing frontend"""
        node = foundry.get_node(node_id)
        if not node:
            raise HTTPException(404, "Node not found")
        
        # Map to trinity structure your frontend expects
        return {
            'body': {
                'field': 'body_tropical',
                'activations': [act.to_dict() for act in node.fields[FieldType.BODY_TROPICAL].activations],
                'coherence': node.fields[FieldType.BODY_TROPICAL].coherence_score
            },
            'mind': {
                'field': 'mind_sidereal',
                'activations': [act.to_dict() for act in node.fields[FieldType.MIND_SIDEREAL].activations],
                'coherence': node.fields[FieldType.MIND_SIDEREAL].coherence_score
            },
            'heart': {
                'field': 'heart_draconic',
                'activations': [act.to_dict() for act in node.fields[FieldType.HEART_DRACONIC].activations],
                'coherence': node.fields[FieldType.HEART_DRACONIC].coherence_score
            }
        }
    
    @app.get("/api/resonance/{node1_id}/{node2_id}")
    def get_resonance(node1_id: str, node2_id: str):
        res = foundry.compute_resonance(node1_id, node2_id)
        return {'resonance': res}
    
    @app.get("/api/glyphs/gate/{gate_number}")
    def get_gate_info(gate_number: int):
        """Get gate metadata with glyph"""
        if gate_number not in GATE_LIBRARY:
            raise HTTPException(404, "Gate not found")
        return GATE_LIBRARY[gate_number]
    
    @app.get("/health")
    def health_check():
        return {
            'status': 'healthy',
            'node_count': len(foundry.nodes),
            'version': '3.0'
        }
    
    return app

# ============================================================================
# MAIN
# ============================================================================

if __name__ == "__main__":
    print("🔥 FOUNDRY COMPLETE SYSTEM v3.0 - MERGED EDITION")
    print("=" * 70)
    
    foundry = FoundryGraph(persist_path="/tmp/foundry_v3.json")
    
    # Test
    coords = BirthCoordinates(
        latitude=37.7749,
        longitude=-122.4194,
        datetime=datetime(1990, 9, 18, 14, 30, 0)
    )
    
    print("\n📍 Creating test node...")
    node = foundry.add_node(coords)
    print(f"✓ Node: {node.node_id}")
    print(f"✓ Coherence: {node.coherence:.4f}")
    
    print("\n🌌 9-Field System:")
    for field_type in FieldType:
        field = node.fields[field_type]
        print(f"  {field_type.value:20s} → {len(field.activations)} activations")
    
    print("\n🏠 Houses (Tropical):")
    tropical = node.charts[CoordinateSystem.TROPICAL]
    for house in tropical.houses[:4]:
        print(f"  House {house.house_number}: {house.zodiac_sign.name_str} {house.zodiac_sign.symbol}")
    
    print("\n🎯 Sample Activation with Full Context:")
    mind_sid = node.fields[FieldType.MIND_SIDEREAL]
    if mind_sid.activations:
        act = list(mind_sid.activations)[0]
        act_dict = act.to_dict()
        print(f"  Gate: {act_dict['gate']} - {act_dict['gate_name']}")
        print(f"  Signature: {act_dict['signature']}")
        print(f"  Causal: {act_dict['causal_essence']}")
        print(f"  Question: {act_dict['existential_question']}")
        print(f"  Glyph: {act_dict['glyph_path']}")
    
    print("\n🚀 Starting API server...")
    api = create_api(foundry)
    
    if api:
        print("\n" + "=" * 70)
        print("✅ FOUNDRY COMPLETE API - READY")
        print("=" * 70)
        print("\nEndpoints:")
        print("  POST /api/nodes                  - Create node")
        print("  GET  /api/nodes/{id}              - Complete state")
        print("  GET  /api/trinity/{id}            - Trinity view")
        print("  GET  /api/resonance/{id1}/{id2}   - Resonance")
        print("  GET  /api/glyphs/gate/{num}       - Gate info")
        print("  GET  /assets/glyphs/...           - Glyph files")
        print("\nRun: uvicorn foundry_complete_v3:app --reload --port 8000")
        print("=" * 70)

# ============================================================================
# SENTENCE GENERATION INTEGRATION
# ============================================================================

# Import sentence generator
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

try:
    from sentence_generator import DynamicSentenceGenerator, SentenceStyle, PowerState
    SENTENCE_GENERATOR_AVAILABLE = True
    SENTENCE_GENERATOR = DynamicSentenceGenerator('knowledge_base_enriched.json')
    print("✅ Sentence generator loaded")
except Exception as e:
    SENTENCE_GENERATOR_AVAILABLE = False
    print(f"⚠️  Sentence generator not available: {e}")

# Add to FoundryGraph class
def get_complete_state_with_sentences(self, node_id: str) -> Dict:
    """Get complete state including dynamically generated sentences"""
    state = self.get_complete_state(node_id)
    
    if not state or not SENTENCE_GENERATOR_AVAILABLE:
        return state
    
    # Add sentences to each activation
    for field_name, field_data in state.get('fields', {}).items():
        activations = field_data.get('activations', [])
        
        for activation in activations:
            # Generate all sentence styles
            activation['sentences'] = {
                'direct': SENTENCE_GENERATOR.generate(
                    activation,
                    style=SentenceStyle.DIRECT,
                    power_state=PowerState.RESONANCE
                ),
                'observational': SENTENCE_GENERATOR.generate(
                    activation,
                    style=SentenceStyle.OBSERVATIONAL
                ),
                'questioning': SENTENCE_GENERATOR.generate(
                    activation,
                    style=SentenceStyle.QUESTIONING
                ),
                'evolutionary': SENTENCE_GENERATOR.generate(
                    activation,
                    style=SentenceStyle.EVOLUTIONARY
                ),
                'complete_coordinate': SENTENCE_GENERATOR.generate_complete_coordinate(activation)
            }
            
            # Add power state variations
            activation['power_states'] = SENTENCE_GENERATOR.generate_all_power_states(activation)
    
    return state

# Monkey patch the method into FoundryGraph
FoundryGraph.get_complete_state_with_sentences = get_complete_state_with_sentences

print("✅ Sentence generation integrated into Foundry")

# Add new API endpoint for sentences
def update_api_with_sentences(app, foundry):
    """Add sentence generation endpoints to API"""
    
    @app.get("/api/nodes/{node_id}/sentences")
    def get_node_with_sentences(node_id: str):
        """Get complete node state WITH dynamically generated sentences"""
        state = foundry.get_complete_state_with_sentences(node_id)
        if not state:
            raise HTTPException(404, "Node not found")
        return state
    
    @app.get("/api/activation/sentence")
    def generate_sentence_from_activation(
        gate: int,
        line: int,
        color: int,
        tone: int,
        base: int,
        zodiac_sign: str = "",
        house: int = 0,
        degrees_in_sign: int = 0,
        minutes: int = 0,
        seconds: float = 0.0,
        style: str = "direct"
    ):
        """
        Generate sentence from raw activation coordinates.
        No need for full chart calculation.
        """
        if not SENTENCE_GENERATOR_AVAILABLE:
            raise HTTPException(503, "Sentence generator not available")
        
        activation = {
            'gate': gate,
            'line': line,
            'color': color,
            'tone': tone,
            'base': base,
            'zodiac_sign': zodiac_sign,
            'house': house,
            'degrees_in_sign': degrees_in_sign,
            'minutes': minutes,
            'seconds': seconds
        }
        
        style_enum = SentenceStyle[style.upper()]
        
        return {
            'activation': activation,
            'sentence': SENTENCE_GENERATOR.generate(activation, style=style_enum),
            'complete_coordinate': SENTENCE_GENERATOR.generate_complete_coordinate(activation),
            'power_states': SENTENCE_GENERATOR.generate_all_power_states(activation)
        }

# NOTE: This gets called when create_api() is invoked
print("✅ Sentence API endpoints ready")
