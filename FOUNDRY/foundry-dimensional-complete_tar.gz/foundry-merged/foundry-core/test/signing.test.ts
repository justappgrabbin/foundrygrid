/**
 * Foundry Core - Signing Tests
 * 
 * Verify Ed25519 signature creation and verification.
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  generateKeyPair,
  sign,
  verify,
  createAttestation,
  verifyAttestation,
  formatPublicKey,
  type SignaturePayload,
} from '../src/index.js';

test('key generation: creates valid keypair', () => {
  const keypair = generateKeyPair();
  
  assert.ok(keypair.publicKey);
  assert.ok(keypair.privateKey);
  assert.match(keypair.publicKey, /^[A-Za-z0-9+/]+=*$/); // base64
  assert.match(keypair.privateKey, /^[A-Za-z0-9+/]+=*$/); // base64
});

test('signing: creates valid signature', () => {
  const keypair = generateKeyPair();
  const payload: SignaturePayload = {
    glyphId: 'sha256:abc123',
    quality: 'production',
    timestamp: '2025-01-01T00:00:00Z',
  };
  
  const signature = sign(payload, keypair.privateKey);
  
  assert.ok(signature);
  assert.match(signature, /^[A-Za-z0-9+/]+=*$/); // base64
});

test('verification: accepts valid signature', () => {
  const keypair = generateKeyPair();
  const payload: SignaturePayload = {
    glyphId: 'sha256:abc123',
    quality: 'production',
    timestamp: '2025-01-01T00:00:00Z',
  };
  
  const signature = sign(payload, keypair.privateKey);
  const valid = verify(payload, signature, keypair.publicKey);
  
  assert.equal(valid, true);
});

test('verification: rejects invalid signature', () => {
  const keypair = generateKeyPair();
  const payload: SignaturePayload = {
    glyphId: 'sha256:abc123',
    quality: 'production',
    timestamp: '2025-01-01T00:00:00Z',
  };
  
  const signature = sign(payload, keypair.privateKey);
  
  // Tamper with payload
  const tamperedPayload = { ...payload, glyphId: 'sha256:different' };
  const valid = verify(tamperedPayload, signature, keypair.publicKey);
  
  assert.equal(valid, false);
});

test('verification: rejects wrong key', () => {
  const keypair1 = generateKeyPair();
  const keypair2 = generateKeyPair();
  
  const payload: SignaturePayload = {
    glyphId: 'sha256:abc123',
    quality: 'production',
    timestamp: '2025-01-01T00:00:00Z',
  };
  
  const signature = sign(payload, keypair1.privateKey);
  const valid = verify(payload, signature, keypair2.publicKey); // Wrong key
  
  assert.equal(valid, false);
});

test('signing: deterministic for same payload', () => {
  const keypair = generateKeyPair();
  const payload: SignaturePayload = {
    glyphId: 'sha256:abc123',
    quality: 'production',
    timestamp: '2025-01-01T00:00:00Z',
  };
  
  const sig1 = sign(payload, keypair.privateKey);
  const sig2 = sign(payload, keypair.privateKey);
  
  // Same payload → same signature
  assert.equal(sig1, sig2);
});

test('attestation: creates valid structure', () => {
  const keypair = generateKeyPair();
  const glyphId = 'sha256:abc123';
  
  const attestation = createAttestation(
    glyphId,
    'production',
    keypair.privateKey,
    'test-user',
    'https://ci.example.com/run/123'
  );
  
  assert.equal(attestation.quality, 'production');
  assert.equal(attestation.signer, 'test-user');
  assert.equal(attestation.evidence, 'https://ci.example.com/run/123');
  assert.ok(attestation.signature);
  assert.ok(attestation.signedAt);
});

test('attestation: verifies correctly', () => {
  const keypair = generateKeyPair();
  const glyphId = 'sha256:abc123';
  
  const attestation = createAttestation(
    glyphId,
    'production',
    keypair.privateKey,
    'test-user'
  );
  
  const valid = verifyAttestation(attestation, glyphId, keypair.publicKey);
  assert.equal(valid, true);
});

test('attestation: rejects tampered glyph ID', () => {
  const keypair = generateKeyPair();
  const glyphId = 'sha256:abc123';
  
  const attestation = createAttestation(
    glyphId,
    'production',
    keypair.privateKey,
    'test-user'
  );
  
  const valid = verifyAttestation(
    attestation,
    'sha256:different', // Tampered
    keypair.publicKey
  );
  
  assert.equal(valid, false);
});

test('public key formatting: readable format', () => {
  const keypair = generateKeyPair();
  const formatted = formatPublicKey(keypair.publicKey, 'alice');
  
  assert.match(formatted, /^ed25519:user:alice:[a-f0-9]{8}$/);
});

test('signature: canonical JSON ordering', () => {
  const keypair = generateKeyPair();
  
  // Same data, different key order
  const payload1: SignaturePayload = {
    glyphId: 'sha256:abc',
    quality: 'production',
    timestamp: '2025-01-01T00:00:00Z',
  };
  
  const payload2: SignaturePayload = {
    timestamp: '2025-01-01T00:00:00Z',
    quality: 'production',
    glyphId: 'sha256:abc',
  };
  
  const sig1 = sign(payload1, keypair.privateKey);
  const sig2 = sign(payload2, keypair.privateKey);
  
  // Keys are sorted internally → same signature
  assert.equal(sig1, sig2);
});
