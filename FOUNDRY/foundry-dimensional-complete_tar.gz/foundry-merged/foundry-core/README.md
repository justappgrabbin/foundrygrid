# Foundry Core Library

**Pure functions for glyph-based component identity.**

Zero I/O. 100% deterministic (except key generation). The invariant at the heart of Foundry Registry.

---

## What This Is

The core library that implements:

✅ **Deterministic glyph ID generation** (content + lineage → unique hash)  
✅ **Content normalization** (text, binary, manifests)  
✅ **Cryptographic signing** (Ed25519 attestations)  
✅ **Quality lifecycle** (draft → tested → production)  
✅ **Lineage tracking** (imported, assembled, derived)  

**No database. No network. No filesystem.**

Just pure functions that define what a glyph IS.

---

## Installation

```bash
npm install @foundry/core
```

---

## Quick Start

```typescript
import { createGlyph, verifyGlyphIntegrity } from '@foundry/core';

// Create a glyph from content
const glyph = createGlyph({
  content: 'export function Button() { return <button>Click</button>; }',
  producer: {
    userId: 'alice',
    tool: 'foundry-cli/1.0.0',
    environment: 'node/20.11.0'
  }
});

console.log(glyph.id);          // sha256:a1b2c3d4...
console.log(glyph.quality);     // 'draft'
console.log(glyph.contentHash); // sha256:...

// Verify integrity
console.log(verifyGlyphIntegrity(glyph)); // true
```

---

## Core Concepts

### Glyph Structure

```typescript
interface Glyph {
  id: string;              // sha256:... (identity hash)
  schemaVersion: number;   // 1
  contentHash: string;     // sha256 of normalized content
  contentSize: number;     // bytes
  contentType: string;     // 'fragment' | 'app' | 'artifact'
  quality: QualityLevel;   // 'draft' | 'tested' | 'production' | 'archived'
  origin: GlyphOrigin;     // provenance
  createdAt: string;       // ISO 8601
  producer: Producer;      // who created it
  attestations?: Attestation[]; // cryptographic trust
}
```

### Critical Invariants

1. **Glyph ID ≠ Content Hash**
   - `contentHash` = hash of normalized content
   - `glyphId` = hash of canonical glyph payload (includes contentHash + lineage)
   - **Why:** Same content, different lineage → different glyph

2. **Timestamps Excluded from ID**
   - `createdAt`, `promotedAt`, `signedAt` are NOT hashed
   - **Why:** Determinism - same inputs must yield same ID

3. **Parent Order Irrelevant**
   - Parent glyphs are sorted before hashing
   - **Why:** [A, B] and [B, A] should produce same ID

4. **Quality Affects ID**
   - Different quality levels → different glyph IDs
   - **Why:** Prevents accidental promotion bypass

---

## API Reference

### Content Normalization

```typescript
import { normalizeText, normalizeBinary, normalizeManifest } from '@foundry/core';

// Text: normalize line endings, trim whitespace
const normalized = normalizeText('hello\r\nworld   \n\n');
// → 'hello\nworld\n'

// Binary: no-op (use raw bytes)
const buffer = normalizeBinary(Buffer.from([0x00, 0xFF]));

// Manifest: sort keys recursively
const sorted = normalizeManifest({ z: 1, a: 2 });
// → { a: 2, z: 1 }
```

### Glyph Creation

```typescript
import { createGlyph, deriveGlyph } from '@foundry/core';

// Create from content
const glyph = createGlyph({
  content: 'export const foo = 42;',
  manifest: { name: 'foo', version: '1.0.0' },
  quality: 'draft',
  origin: {
    type: 'imported',
    sourceUri: 'file:///path/to/foo.ts'
  },
  producer: {
    userId: 'alice',
    tool: 'foundry-cli/1.0.0',
    environment: 'node/20.11.0'
  }
});

// Derive (fork) a glyph
const forked = deriveGlyph(glyph, {
  quality: 'draft',
  producer: { userId: 'bob', tool: '...', environment: '...' }
});

// Same content, different lineage → different ID
console.log(forked.id !== glyph.id); // true
```

### Signing & Attestations

```typescript
import { 
  generateKeyPair, 
  createAttestation, 
  verifyAttestation 
} from '@foundry/core';

// Generate keypair
const { publicKey, privateKey } = generateKeyPair();

// Create attestation for promotion
const attestation = createAttestation(
  glyph.id,
  'production',
  privateKey,
  'alice',
  'https://ci.example.com/run/12345'
);

// Verify signature
const valid = verifyAttestation(attestation, glyph.id, publicKey);
console.log(valid); // true
```

### Serialization

```typescript
import { 
  embedGlyph, 
  extractGlyphId, 
  serializeGlyph 
} from '@foundry/core';

// Embed in source file
const withHeader = embedGlyph(
  'export function Button() { ... }',
  glyph,
  '.tsx'
);
// → Adds comment header with glyph metadata

// Extract glyph ID from embedded content
const id = extractGlyphId(withHeader);
console.log(id); // 'sha256:...'

// Serialize to JSON
const json = serializeGlyph(glyph);
```

---

## Testing

Run tests:

```bash
npm test
```

Tests verify:
- ✅ Determinism (same input → same output)
- ✅ Uniqueness (different input → different output)
- ✅ Integrity (glyph ID matches computed ID)
- ✅ Immutability (timestamps excluded from hash)
- ✅ Cryptographic validity (Ed25519 signatures)

---

## Design Principles

### 1. Pure Functions Only

Every function (except `generateKeyPair`) is **pure**:
- No I/O
- No randomness
- No side effects
- Deterministic outputs

### 2. Timestamps Excluded from Hashes

`createdAt`, `promotedAt`, and `signedAt` are **metadata**, not identity.

They record **when** something happened, but don't affect **what** it is.

### 3. Content vs. Glyph Identity

- **Content hash** = what the bytes are
- **Glyph ID** = what the component means (content + lineage + quality)

Example:
- Same function, used in two different apps → **different glyphs**
- Same function, promoted from draft → production → **different glyphs**

### 4. Lineage is Identity

Two components with identical code but different origins are **different glyphs**.

This enables:
- Forking (derive from production → draft)
- Assembly (many fragments → one app)
- Provenance (know where everything came from)

---

## Examples

### Example 1: Deterministic Build

```typescript
const fragment1 = createGlyph({
  content: 'export const A = 1;',
  producer: testProducer
});

const fragment2 = createGlyph({
  content: 'export const B = 2;',
  producer: testProducer
});

// Assemble app from fragments
const app = createGlyph({
  content: '/* assembled app */',
  origin: {
    type: 'assembled',
    parents: [fragment1.id, fragment2.id]
  },
  producer: testProducer
});

// Parent order doesn't matter
const appReversed = createGlyph({
  content: '/* assembled app */',
  origin: {
    type: 'assembled',
    parents: [fragment2.id, fragment1.id] // Reversed
  },
  producer: testProducer
});

console.log(app.id === appReversed.id); // true (parents are sorted)
```

### Example 2: Production Lock

```typescript
const draft = createGlyph({
  content: testContent,
  quality: 'draft',
  producer: testProducer
});

const production = createGlyph({
  content: testContent,
  quality: 'production',
  producer: testProducer
});

// Different quality → different ID
console.log(draft.id !== production.id); // true

// To modify production, must derive (fork)
const modified = deriveGlyph(production, {
  quality: 'draft',
  producer: testProducer
});

console.log(modified.origin.type); // 'derived'
console.log(modified.origin.parents); // [production.id]
```

### Example 3: Cryptographic Trust

```typescript
const keypair = generateKeyPair();

const glyph = createGlyph({
  content: testContent,
  quality: 'production',
  producer: testProducer
});

// Attest to production quality
const attestation = createAttestation(
  glyph.id,
  'production',
  keypair.privateKey,
  'alice@example.com',
  'https://ci.example.com/run/12345'
);

// Add to glyph
glyph.attestations = [attestation];

// Later: verify signature
const valid = verifyAttestation(
  attestation,
  glyph.id,
  keypair.publicKey
);

console.log(valid); // true (cryptographic proof)
```

---

## Integration

This library is used by:

1. **Foundry CLI** - generates glyphs from files
2. **Foundry Registry** - stores/retrieves glyphs by ID
3. **Foundry Studio** - visual authoring tool

All three use the **same core primitives** defined here.

---

## Philosophy

> "Identity persists through transformation."

A glyph is not:
- A file
- A version
- A timestamp

A glyph is:
- The **essence** of a component (content + meaning)
- Immutable once created
- Cryptographically verifiable
- Self-documenting

This library ensures that **the same inputs always produce the same glyph**, enabling deterministic builds, safe reuse, and trustworthy composition.

---

## License

MIT

---

## Status

**Phase 2.1 Complete** - Core library implemented and tested.

Next: Registry Service (Postgres + S3 + API)
