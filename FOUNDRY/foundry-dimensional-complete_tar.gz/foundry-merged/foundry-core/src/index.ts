/**
 * Foundry Core Library
 * 
 * Pure functions for glyph-based component identity.
 * Zero I/O, 100% deterministic (except key generation).
 * 
 * @packageDocumentation
 */

// Types
export type {
  Glyph,
  GlyphOrigin,
  Producer,
  Attestation,
  QualityLevel,
  OriginType,
  ContentType,
  FragmentInput,
  SignaturePayload,
  CanonicalGlyphPayload,
  Recipe,
  FragmentReference,
  GeneratedFile,
} from './glyph/types.js';

// Normalization
export {
  normalizeText,
  normalizeBinary,
  normalizeManifest,
  normalizeContent,
  isTextContent,
  canonicalJSON,
} from './glyph/normalize.js';

// Hashing
export {
  sha256,
  sha256WithPrefix,
  sha256Multi,
  verifyHash,
} from './glyph/hash.js';

// Glyph ID Generation (core invariant)
export {
  computeContentHash,
  computeGlyphId,
  createGlyph,
  recomputeGlyphId,
  verifyGlyphIntegrity,
  deriveGlyph,
} from './glyph/id.js';

// Serialization
export {
  serializeGlyph,
  parseGlyph,
  generateInlineHeader,
  embedGlyph,
  extractGlyphId,
  sidecarFilename,
  createSidecarContent,
} from './glyph/format.js';

// Signing
export type { KeyPair } from './signing/sign.js';
export {
  generateKeyPair,
  sign,
  verify,
  createAttestation,
  verifyAttestation,
  formatPublicKey,
} from './signing/sign.js';
