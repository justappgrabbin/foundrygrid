/**
 * Foundry Core - Cryptographic Hashing
 * 
 * Uses SHA-256 for all content hashing.
 * All functions are pure and deterministic.
 */

import crypto from 'crypto';

/**
 * Compute SHA-256 hash of content
 * Returns hex string
 */
export function sha256(content: string | Buffer): string {
  const buffer = typeof content === 'string'
    ? Buffer.from(content, 'utf-8')
    : content;
  
  return crypto
    .createHash('sha256')
    .update(buffer)
    .digest('hex');
}

/**
 * Compute SHA-256 hash with prefix
 * Returns "sha256:..." format
 */
export function sha256WithPrefix(content: string | Buffer): string {
  return `sha256:${sha256(content)}`;
}

/**
 * Hash multiple pieces of content in sequence
 * Useful for hashing composite structures
 */
export function sha256Multi(...contents: (string | Buffer)[]): string {
  const hash = crypto.createHash('sha256');
  
  for (const content of contents) {
    const buffer = typeof content === 'string'
      ? Buffer.from(content, 'utf-8')
      : content;
    hash.update(buffer);
  }
  
  return hash.digest('hex');
}

/**
 * Verify hash matches expected value
 */
export function verifyHash(
  content: string | Buffer,
  expectedHash: string
): boolean {
  const actualHash = expectedHash.startsWith('sha256:')
    ? sha256WithPrefix(content)
    : sha256(content);
  
  return actualHash === expectedHash;
}
