/**
 * Foundry Core - Glyph ID Generation
 * 
 * CRITICAL INVARIANT:
 * - contentHash = hash of normalized content + manifest
 * - glyphId = hash of canonical glyph payload (includes contentHash + lineage)
 * 
 * This separation allows:
 * - Same bytes, different lineage → different glyph
 * - Glyph evolution without re-hashing content
 */

import { sha256WithPrefix, sha256 } from './hash.js';
import { normalizeContent, normalizeManifest, canonicalJSON } from './normalize.js';
import type {
  Glyph,
  FragmentInput,
  CanonicalGlyphPayload,
  Producer,
  GlyphOrigin,
  QualityLevel,
} from './types.js';

/**
 * Compute content hash from normalized content + optional manifest
 * 
 * This hash identifies the raw material, independent of lineage.
 */
export function computeContentHash(input: {
  content: string | Buffer;
  manifest?: Record<string, unknown>;
}): string {
  const normalized = normalizeContent(input.content);
  
  if (input.manifest) {
    const manifestNormalized = normalizeManifest(input.manifest);
    const manifestJSON = canonicalJSON(manifestNormalized);
    
    // Hash content + manifest together
    const combined = typeof normalized === 'string'
      ? normalized + '\n---MANIFEST---\n' + manifestJSON
      : Buffer.concat([
          normalized,
          Buffer.from('\n---MANIFEST---\n' + manifestJSON, 'utf-8')
        ]);
    
    return sha256WithPrefix(combined);
  }
  
  return sha256WithPrefix(normalized);
}

/**
 * Create canonical glyph payload for hashing
 * 
 * CRITICAL: This defines what makes a glyph unique.
 * Changes to this structure = breaking change.
 * 
 * EXCLUDED from glyph ID:
 * - createdAt, promotedAt (timestamps)
 * - attestations (added after creation)
 */
function createCanonicalPayload(params: {
  contentHash: string;
  contentSize: number;
  contentType: string;
  quality: QualityLevel;
  origin: GlyphOrigin;
  producer: Producer;
}): CanonicalGlyphPayload {
  // Sort parent glyphs if present
  const sortedParents = params.origin.parents
    ? [...params.origin.parents].sort()
    : undefined;
  
  // Create canonical structure (alphabetically sorted keys)
  return {
    contentHash: params.contentHash,
    contentSize: params.contentSize,
    contentType: params.contentType,
    origin: {
      type: params.origin.type,
      ...(sortedParents && { parents: sortedParents }),
      ...(params.origin.sourceUri && { sourceUri: params.origin.sourceUri }),
    },
    producer: {
      environment: params.producer.environment,
      tool: params.producer.tool,
      userId: params.producer.userId,
    },
    quality: params.quality,
    schemaVersion: 1,
  };
}

/**
 * Compute glyph ID from canonical payload
 * 
 * This is the core identity hash.
 */
export function computeGlyphId(payload: CanonicalGlyphPayload): string {
  const canonical = canonicalJSON(payload);
  return sha256WithPrefix(canonical);
}

/**
 * Create a complete glyph from fragment input
 * 
 * This is the main entry point for glyph creation.
 */
export function createGlyph(input: FragmentInput): Glyph {
  // Compute content hash
  const contentHash = computeContentHash({
    content: input.content,
    manifest: input.manifest,
  });
  
  // Determine content size
  const contentSize = typeof input.content === 'string'
    ? Buffer.byteLength(input.content, 'utf-8')
    : input.content.length;
  
  // Build origin
  const origin: GlyphOrigin = {
    type: input.origin?.type || 'imported',
    parents: input.origin?.parents,
    sourceUri: input.origin?.sourceUri,
  };
  
  // Create canonical payload
  const payload = createCanonicalPayload({
    contentHash,
    contentSize,
    contentType: input.contentType || 'fragment',
    quality: input.quality || 'draft',
    origin,
    producer: input.producer,
  });
  
  // Compute glyph ID
  const glyphId = computeGlyphId(payload);
  
  // Create full glyph
  const glyph: Glyph = {
    id: glyphId,
    schemaVersion: 1,
    contentHash,
    contentSize,
    contentType: input.contentType || 'fragment',
    quality: input.quality || 'draft',
    origin,
    createdAt: new Date().toISOString(),
    producer: input.producer,
  };
  
  return glyph;
}

/**
 * Re-compute glyph ID from existing glyph
 * Useful for verification
 */
export function recomputeGlyphId(glyph: Glyph): string {
  const payload = createCanonicalPayload({
    contentHash: glyph.contentHash,
    contentSize: glyph.contentSize,
    contentType: glyph.contentType,
    quality: glyph.quality,
    origin: glyph.origin,
    producer: glyph.producer,
  });
  
  return computeGlyphId(payload);
}

/**
 * Verify glyph integrity
 * Returns true if glyph.id matches computed ID
 */
export function verifyGlyphIntegrity(glyph: Glyph): boolean {
  const expected = recomputeGlyphId(glyph);
  return glyph.id === expected;
}

/**
 * Create a derived glyph (same content, different lineage)
 * 
 * Example: Forking a production component to make changes
 */
export function deriveGlyph(
  parent: Glyph,
  options: {
    quality?: QualityLevel;
    producer: Producer;
  }
): Glyph {
  const origin: GlyphOrigin = {
    type: 'derived',
    parents: [parent.id],
  };
  
  const payload = createCanonicalPayload({
    contentHash: parent.contentHash,
    contentSize: parent.contentSize,
    contentType: parent.contentType,
    quality: options.quality || 'draft',
    origin,
    producer: options.producer,
  });
  
  const glyphId = computeGlyphId(payload);
  
  return {
    id: glyphId,
    schemaVersion: 1,
    contentHash: parent.contentHash,
    contentSize: parent.contentSize,
    contentType: parent.contentType,
    quality: options.quality || 'draft',
    origin,
    createdAt: new Date().toISOString(),
    producer: options.producer,
  };
}
