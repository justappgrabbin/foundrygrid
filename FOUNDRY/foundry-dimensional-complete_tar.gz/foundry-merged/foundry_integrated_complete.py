"""
FOUNDRY COMPLETE INTEGRATED SYSTEM
===================================
Combines:
1. Swiss Ephemeris calculations (9 fields)
2. Degree/minute/second precision
3. Zodiac signs & houses
4. Knowledge base (64 gates + colors/tones/bases)
5. Dynamic sentence generation

NO PRE-WRITTEN TEMPLATES - sentences generated from:
- Calculated activation (Gate.Line.Color.Tone.Base)
- Precise position (°'")
- Astrological context (Zodiac, House)
- Knowledge base semantic data

Author: Celestial
Version: COMPLETE INTEGRATION
"""

import numpy as np
from datetime import datetime, timezone
from typing import Dict, List, Tuple, Optional, Set, Any
from dataclasses import dataclass, field
from enum import Enum
import swisseph as swe
from collections import defaultdict
import json
import os

# Import sentence engine
from sentence_engine import SentenceEngine

# ============================================================================
# [Keep all the previous types and classes from foundry_complete_v3.py]
# ============================================================================

class FieldType(Enum):
    """9 consciousness fields - AXES"""
    MIND_SIDEREAL = "mind_sidereal"
    MIND_TROPICAL = "mind_tropical"
    MIND_DRACONIC = "mind_draconic"
    HEART_SIDEREAL = "heart_sidereal"
    HEART_TROPICAL = "heart_tropical"
    HEART_DRACONIC = "heart_draconic"
    BODY_SIDEREAL = "body_sidereal"
    BODY_TROPICAL = "body_tropical"
    BODY_DRACONIC = "body_draconic"

class CoordinateSystem(Enum):
    SIDEREAL = "sidereal"
    TROPICAL = "tropical"
    DRACONIC = "draconic"

class HouseSystem(Enum):
    PLACIDUS = "P"
    WHOLE_SIGN = "W"
    EQUAL = "E"
    KOCH = "K"

class ZodiacSign(Enum):
    ARIES = (0, "Aries", "♈")
    TAURUS = (1, "Taurus", "♉")
    GEMINI = (2, "Gemini", "♊")
    CANCER = (3, "Cancer", "♋")
    LEO = (4, "Leo", "♌")
    VIRGO = (5, "Virgo", "♍")
    LIBRA = (6, "Libra", "♎")
    SCORPIO = (7, "Scorpio", "♏")
    SAGITTARIUS = (8, "Sagittarius", "♐")
    CAPRICORN = (9, "Capricorn", "♑")
    AQUARIUS = (10, "Aquarius", "♒")
    PISCES = (11, "Pisces", "♓")
    
    @property
    def index(self): return self.value[0]
    @property
    def name_str(self): return self.value[1]
    @property
    def symbol(self): return self.value[2]

# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def longitude_to_dms(longitude: float) -> Tuple[int, int, float]:
    """Convert decimal degrees to degrees, minutes, seconds"""
    degrees = int(longitude)
    remaining = (longitude - degrees) * 60
    minutes = int(remaining)
    seconds = (remaining - minutes) * 60
    return (degrees, minutes, seconds)

def longitude_to_zodiac(longitude: float) -> Tuple[ZodiacSign, int, int, float]:
    """Convert ecliptic longitude to zodiac position with DMS"""
    longitude = longitude % 360.0
    sign_index = int(longitude / 30.0)
    signs = list(ZodiacSign)
    sign = signs[sign_index]
    
    position_in_sign = longitude % 30.0
    degrees = int(position_in_sign)
    remaining = (position_in_sign - degrees) * 60
    minutes = int(remaining)
    seconds = (remaining - minutes) * 60
    
    return (sign, degrees, minutes, seconds)

def format_zodiac_position(longitude: float) -> str:
    """Format longitude as zodiac notation with DMS"""
    sign, deg, min, sec = longitude_to_zodiac(longitude)
    return f"{deg}°{min:02d}'{sec:05.2f}\" {sign.name_str}"

def format_dms(longitude: float) -> str:
    """Format as pure DMS"""
    deg, min, sec = longitude_to_dms(longitude)
    return f"{deg}°{min:02d}'{sec:05.2f}\""

# ============================================================================
# DATA STRUCTURES
# ============================================================================

@dataclass
class BirthCoordinates:
    """Spacetime address"""
    latitude: float
    longitude: float
    datetime: datetime
    timezone_offset: float = 0.0
    
    @property
    def julian_day(self) -> float:
        dt = self.datetime
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        else:
            dt = dt.astimezone(timezone.utc)
        return swe.julday(
            dt.year, dt.month, dt.day,
            dt.hour + dt.minute/60.0 + dt.second/3600.0
        )
    
    @property
    def causal_address(self) -> str:
        dt_str = self.datetime.isoformat()
        return f"stellar://{dt_str}@{self.latitude},{self.longitude}"

@dataclass
class PlanetPosition:
    """Complete planetary position with DMS precision"""
    planet: str
    longitude: float  # Ecliptic longitude (raw)
    latitude: float
    distance: float
    speed: float
    
    # Zodiac position
    zodiac_sign: ZodiacSign
    degrees_in_sign: int
    minutes: int
    seconds: float
    
    # Pure DMS (for axis calculations)
    dms_degrees: int
    dms_minutes: int
    dms_seconds: float
    
    house: Optional[int] = None
    coord_system: CoordinateSystem = CoordinateSystem.TROPICAL
    
    @classmethod
    def from_calculation(cls, planet: str, calc_result: Tuple, 
                        coord_sys: CoordinateSystem = CoordinateSystem.TROPICAL):
        longitude, latitude, distance, speed_lon, speed_lat, speed_dist = calc_result
        
        # Zodiac position
        sign, deg_in_sign, min_in_sign, sec_in_sign = longitude_to_zodiac(longitude)
        
        # Pure DMS
        dms_deg, dms_min, dms_sec = longitude_to_dms(longitude)
        
        return cls(
            planet=planet, longitude=longitude, latitude=latitude,
            distance=distance, speed=speed_lon, zodiac_sign=sign,
            degrees_in_sign=deg_in_sign, minutes=min_in_sign, 
            seconds=sec_in_sign, dms_degrees=dms_deg, dms_minutes=dms_min,
            dms_seconds=dms_sec, coord_system=coord_sys
        )
    
    @property
    def zodiac_position(self) -> str:
        return f"{self.degrees_in_sign}°{self.minutes:02d}'{self.seconds:05.2f}\" {self.zodiac_sign.name_str}"
    
    @property
    def dms_position(self) -> str:
        return f"{self.dms_degrees}°{self.dms_minutes:02d}'{self.dms_seconds:05.2f}\""
    
    def to_dict(self) -> Dict:
        return {
            'planet': self.planet,
            'longitude': self.longitude,
            'zodiac_sign': self.zodiac_sign.name_str,
            'zodiac_symbol': self.zodiac_sign.symbol,
            'zodiac_position': self.zodiac_position,
            'dms_position': self.dms_position,
            'degrees_in_sign': self.degrees_in_sign,
            'minutes': self.minutes,
            'seconds': self.seconds,
            'house': self.house,
            'speed': self.speed
        }

@dataclass
class HDActivation:
    """
    Complete HD activation with:
    - Gate.Line.Color.Tone.Base (signature)
    - Degree/Minute/Second (precise position)
    - Axis (which field/coordinate system)
    - Zodiac & House (astrological context)
    """
    gate: int
    line: int
    color: int
    tone: int
    base: int
    planet: str
    planet_position: PlanetPosition
    coord_system: CoordinateSystem
    field_type: FieldType  # The AXIS
    
    def __hash__(self):
        return hash((self.gate, self.line, self.color, self.tone, self.base, 
                    self.planet, self.field_type.value))
    
    @property
    def signature(self) -> str:
        """Gate.Line.Color.Tone.Base"""
        return f"{self.gate}.{self.line}.{self.color}.{self.tone}.{self.base}"
    
    @property
    def axis(self) -> str:
        """Which axis/field this activation belongs to"""
        return self.field_type.value
    
    @property
    def frequency(self) -> float:
        """Calculate resonance frequency"""
        base_hz = 960.0
        gate_factor = (self.gate / 64.0) * base_hz
        line_factor = 1.0 + (self.line / 6.0)
        color_factor = 1.0 + (self.color / 60.0)
        tone_factor = 1.0 + (self.tone / 360.0)
        base_factor = 1.0 + (self.base / 1800.0)
        return gate_factor * line_factor * color_factor * tone_factor * base_factor
    
    def to_dict(self) -> Dict:
        """Complete activation data for sentence generation"""
        return {
            'gate': self.gate,
            'line': self.line,
            'color': self.color,
            'tone': self.tone,
            'base': self.base,
            'signature': self.signature,
            'frequency': self.frequency,
            'axis': self.axis,
            'planet': self.planet,
            'planet_position': self.planet_position.to_dict(),
            'coord_system': self.coord_system.value
        }

@dataclass
class FieldState:
    """Field state with activations"""
    field_type: FieldType
    activations: Set[HDActivation]
    dominant_frequency: float = 0.0
    coherence_score: float = 0.0
    
    def __post_init__(self):
        if self.activations:
            freqs = [act.frequency for act in self.activations]
            self.dominant_frequency = np.mean(freqs)
            self.coherence_score = self._calc_coherence(freqs)
    
    def _calc_coherence(self, freqs: List[float]) -> float:
        if len(freqs) < 2: return 1.0
        ratios = []
        for i, f1 in enumerate(freqs):
            for f2 in freqs[i+1:]:
                if f1 == 0 or f2 == 0: continue
                ratio = max(f1, f2) / min(f1, f2)
                simple_ratios = [2.0, 1.5, 1.333, 1.25, 1.2]
                min_dist = min(abs(ratio - sr) for sr in simple_ratios)
                ratios.append(1.0 - min(min_dist, 1.0))
        return np.mean(ratios) if ratios else 1.0

@dataclass
class HouseData:
    """House data"""
    house_number: int
    cusp_longitude: float
    zodiac_sign: ZodiacSign
    degrees_in_sign: int
    minutes: int
    seconds: float
    house_system: HouseSystem
    
    def to_dict(self) -> Dict:
        return {
            'house': self.house_number,
            'cusp_longitude': self.cusp_longitude,
            'zodiac_sign': self.zodiac_sign.name_str,
            'zodiac_symbol': self.zodiac_sign.symbol,
            'zodiac_position': f"{self.degrees_in_sign}°{self.minutes:02d}'{self.seconds:05.2f}\" {self.zodiac_sign.name_str}"
        }

@dataclass
class AstrologicalChart:
    """Complete chart"""
    birth_coords: BirthCoordinates
    house_system: HouseSystem
    coord_system: CoordinateSystem
    houses: List[HouseData] = field(default_factory=list)
    planet_positions: Dict[str, PlanetPosition] = field(default_factory=dict)
    ascendant: Optional[float] = None
    midheaven: Optional[float] = None
    
    def to_dict(self) -> Dict:
        return {
            'house_system': self.house_system.value,
            'coord_system': self.coord_system.value,
            'ascendant': format_zodiac_position(self.ascendant) if self.ascendant else None,
            'midheaven': format_zodiac_position(self.midheaven) if self.midheaven else None,
            'houses': [h.to_dict() for h in self.houses],
            'planets': {name: pos.to_dict() for name, pos in self.planet_positions.items()}
        }

@dataclass
class CausalNode:
    """Complete consciousness node with sentence generation"""
    birth_coords: BirthCoordinates
    node_id: str = ""
    fields: Dict[FieldType, FieldState] = field(default_factory=dict)
    charts: Dict[CoordinateSystem, AstrologicalChart] = field(default_factory=dict)
    connections: Set[str] = field(default_factory=set)
    created_at: datetime = field(default_factory=datetime.now)
    
    # Sentence engine (set externally)
    sentence_engine: Optional[SentenceEngine] = None
    
    def __post_init__(self):
        if not self.node_id:
            self.node_id = self.birth_coords.causal_address
        if not self.fields:
            self._compute_all()
    
    def _compute_all(self):
        calc = AstrologicalCalculator()
        for field_type in FieldType:
            self.fields[field_type] = calc.compute_field(self.birth_coords, field_type)
        for coord_sys in CoordinateSystem:
            self.charts[coord_sys] = calc.compute_chart(
                self.birth_coords, coord_sys, HouseSystem.PLACIDUS
            )
    
    @property
    def coherence(self) -> float:
        coherences = [f.coherence_score for f in self.fields.values()]
        return float(np.mean(coherences)) if coherences else 0.0
    
    def get_sentences(self, field_type: FieldType, style: str = 'complete') -> List[Dict]:
        """
        Generate sentences for all activations in a field.
        Returns list of {activation, sentence, state_expressions}
        """
        if not self.sentence_engine:
            return []
        
        field_state = self.fields.get(field_type)
        if not field_state:
            return []
        
        results = []
        for activation in field_state.activations:
            act_dict = activation.to_dict()
            sentence = self.sentence_engine.generate(act_dict, style)
            states = self.sentence_engine.generate_state_expression(act_dict)
            
            results.append({
                'activation': act_dict,
                'sentence': sentence,
                'state_expressions': states
            })
        
        return results

# ============================================================================
# ASTROLOGICAL CALCULATOR
# ============================================================================

class AstrologicalCalculator:
    """Complete calculation engine"""
    
    FIELD_PLANETS = {
        'MIND': ['sun', 'earth', 'north_node', 'south_node'],
        'HEART': ['moon', 'mercury', 'venus', 'mars'],
        'BODY': ['jupiter', 'saturn', 'uranus', 'neptune', 'pluto']
    }
    
    PLANET_CODES = {
        'sun': swe.SUN, 'moon': swe.MOON, 'mercury': swe.MERCURY,
        'venus': swe.VENUS, 'mars': swe.MARS, 'jupiter': swe.JUPITER,
        'saturn': swe.SATURN, 'uranus': swe.URANUS, 'neptune': swe.NEPTUNE,
        'pluto': swe.PLUTO, 'north_node': swe.MEAN_NODE,
        'south_node': swe.MEAN_NODE, 'earth': swe.EARTH
    }
    
    GATE_WHEEL = [
        41, 19, 13, 49, 30, 55, 37, 63, 22, 36, 25, 17, 21, 51, 42, 3,
        27, 24, 2, 23, 8, 20, 16, 35, 45, 12, 15, 52, 39, 53, 62, 56,
        31, 33, 7, 4, 29, 59, 40, 64, 47, 6, 46, 18, 48, 57, 32, 50,
        28, 44, 1, 43, 14, 34, 9, 5, 26, 11, 10, 58, 38, 54, 61, 60
    ]
    
    def __init__(self):
        swe.set_ephe_path(None)
    
    def compute_chart(self, coords: BirthCoordinates, coord_sys: CoordinateSystem, 
                     house_sys: HouseSystem) -> AstrologicalChart:
        chart = AstrologicalChart(
            birth_coords=coords, house_system=house_sys, coord_system=coord_sys
        )
        
        if coord_sys == CoordinateSystem.SIDEREAL:
            flags = swe.FLG_SIDEREAL | swe.FLG_SWIEPH
            swe.set_sid_mode(swe.SIDM_LAHIRI)
        else:
            flags = swe.FLG_SWIEPH
        
        try:
            houses_data = swe.houses(
                coords.julian_day, coords.latitude, coords.longitude,
                house_sys.value.encode('ascii')
            )
            cusps = houses_data[0]
            ascmc = houses_data[1]
            chart.ascendant = ascmc[0]
            chart.midheaven = ascmc[1]
            
            for i, cusp_long in enumerate(cusps[1:], 1):
                sign, deg, min, sec = longitude_to_zodiac(cusp_long)
                chart.houses.append(HouseData(
                    house_number=i, cusp_longitude=cusp_long, zodiac_sign=sign,
                    degrees_in_sign=deg, minutes=min, seconds=sec, house_system=house_sys
                ))
        except Exception as e:
            print(f"House calculation error: {e}")
        
        for planet_name, planet_code in self.PLANET_CODES.items():
            try:
                result = swe.calc_ut(coords.julian_day, planet_code, flags)
                longitude = result[0]
                
                if planet_name == 'south_node':
                    longitude = (longitude + 180.0) % 360.0
                
                if coord_sys == CoordinateSystem.DRACONIC:
                    node_result = swe.calc_ut(coords.julian_day, swe.MEAN_NODE, flags)
                    longitude = (longitude - node_result[0]) % 360.0
                
                adjusted_result = (longitude, result[1], result[2], result[3], result[4], result[5])
                planet_pos = PlanetPosition.from_calculation(planet_name, adjusted_result, coord_sys)
                
                if chart.houses:
                    planet_pos.house = self._find_house(longitude, [h.cusp_longitude for h in chart.houses])
                
                chart.planet_positions[planet_name] = planet_pos
            except Exception as e:
                print(f"Error calculating {planet_name}: {e}")
        
        return chart
    
    def _find_house(self, longitude: float, cusps: List[float]) -> int:
        longitude = longitude % 360.0
        for i in range(len(cusps)):
            cusp = cusps[i]
            next_cusp = cusps[(i + 1) % len(cusps)]
            if next_cusp < cusp:
                if longitude >= cusp or longitude < next_cusp:
                    return i + 1
            else:
                if cusp <= longitude < next_cusp:
                    return i + 1
        return 1
    
    def compute_field(self, coords: BirthCoordinates, field_type: FieldType) -> FieldState:
        if 'SIDEREAL' in field_type.value:
            coord_sys = CoordinateSystem.SIDEREAL
        elif 'TROPICAL' in field_type.value:
            coord_sys = CoordinateSystem.TROPICAL
        else:
            coord_sys = CoordinateSystem.DRACONIC
        
        domain = field_type.value.split('_')[0].upper()
        planets = self.FIELD_PLANETS[domain]
        
        if coord_sys == CoordinateSystem.SIDEREAL:
            flags = swe.FLG_SIDEREAL | swe.FLG_SWIEPH
            swe.set_sid_mode(swe.SIDM_LAHIRI)
        else:
            flags = swe.FLG_SWIEPH
        
        activations = set()
        for planet in planets:
            planet_code = self.PLANET_CODES.