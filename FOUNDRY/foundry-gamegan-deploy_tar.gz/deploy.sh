#!/bin/bash
# Foundry GameGAN - One-Command Deploy

echo "🧠 Foundry GameGAN Deployment"
echo ""
echo "Choose deployment method:"
echo "1. Vercel (recommended - fastest)"
echo "2. Netlify"
echo "3. Surge.sh"
echo "4. GitHub Pages"
echo ""
read -p "Enter choice (1-4): " choice

case $choice in
  1)
    echo "📦 Deploying to Vercel..."
    if ! command -v vercel &> /dev/null; then
      echo "Installing Vercel CLI..."
      npm i -g vercel
    fi
    vercel --prod
    ;;
    
  2)
    echo "📦 Deploying to Netlify..."
    if ! command -v netlify &> /dev/null; then
      echo "Installing Netlify CLI..."
      npm i -g netlify-cli
    fi
    netlify deploy --prod --dir .
    ;;
    
  3)
    echo "📦 Deploying to Surge..."
    if ! command -v surge &> /dev/null; then
      echo "Installing Surge..."
      npm i -g surge
    fi
    surge
    ;;
    
  4)
    echo "📦 Deploying to GitHub Pages..."
    if [ ! -d .git ]; then
      git init
      git add .
      git commit -m "Deploy Foundry GameGAN"
    fi
    echo "Create repo at: https://github.com/new"
    echo "Then run: git remote add origin YOUR_REPO_URL"
    echo "Then run: git push origin main"
    echo "Then enable Pages in repo settings"
    ;;
    
  *)
    echo "Invalid choice"
    exit 1
    ;;
esac

echo ""
echo "✅ Deployment complete!"
echo "🧠 Your consciousness prediction engine is live"
