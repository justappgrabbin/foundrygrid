/**
 * Foundry Registry - Main Entry Point
 * 
 * Initializes database, storage, and HTTP server.
 */

import { initDb, closeDb } from './db/client.js';
import { initStorage } from './storage/s3.js';
import { createServer, startServer } from './api/server.js';

// Configuration from environment
const config = {
  database: {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    database: process.env.DB_NAME || 'foundry',
    user: process.env.DB_USER || 'foundry',
    password: process.env.DB_PASSWORD || 'foundry',
    max: parseInt(process.env.DB_POOL_SIZE || '20', 10),
  },
  storage: {
    endpoint: process.env.S3_ENDPOINT || 'http://localhost:9000',
    region: process.env.S3_REGION || 'us-east-1',
    bucket: process.env.S3_BUCKET || 'foundry-registry',
    accessKeyId: process.env.S3_ACCESS_KEY_ID || 'minioadmin',
    secretAccessKey: process.env.S3_SECRET_ACCESS_KEY || 'minioadmin',
  },
  server: {
    port: parseInt(process.env.PORT || '3000', 10),
    corsOrigins: process.env.CORS_ORIGINS?.split(','),
  },
};

async function main() {
  console.log('🔧 Initializing Foundry Registry...');
  
  try {
    // Initialize database
    console.log('   Connecting to database...');
    initDb(config.database);
    
    // Initialize storage
    console.log('   Connecting to object storage...');
    initStorage(config.storage);
    
    // Create and start HTTP server
    console.log('   Starting HTTP server...');
    const app = createServer(config.server);
    startServer(app, config.server.port);
    
    console.log('✅ Foundry Registry initialized successfully');
  } catch (err) {
    console.error('❌ Failed to initialize:', err);
    process.exit(1);
  }
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('🛑 SIGTERM received, shutting down gracefully...');
  await closeDb();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('🛑 SIGINT received, shutting down gracefully...');
  await closeDb();
  process.exit(0);
});

// Start
main();
