/**
 * Foundry Registry - S3/MinIO Storage
 * 
 * Content-addressable storage with sharded directories.
 */

import { S3Client, PutObjectCommand, GetObjectCommand, HeadObjectCommand } from '@aws-sdk/client-s3';
import { createReadStream } from 'fs';

export interface StorageConfig {
  endpoint: string;           // MinIO endpoint
  region: string;
  bucket: string;
  accessKeyId: string;
  secretAccessKey: string;
}

let s3Client: S3Client | null = null;
let bucketName: string = '';

/**
 * Initialize S3/MinIO client
 */
export function initStorage(config: StorageConfig): void {
  s3Client = new S3Client({
    endpoint: config.endpoint,
    region: config.region,
    credentials: {
      accessKeyId: config.accessKeyId,
      secretAccessKey: config.secretAccessKey,
    },
    forcePathStyle: true, // Required for MinIO
  });
  
  bucketName = config.bucket;
}

/**
 * Get S3 client (throws if not initialized)
 */
function getClient(): S3Client {
  if (!s3Client) {
    throw new Error('Storage not initialized. Call initStorage() first.');
  }
  return s3Client;
}

/**
 * Convert content hash to sharded object key
 * 
 * Example:
 *   sha256:abcd1234567890...
 *   → objects/sha256/ab/cd/abcd1234567890...
 */
function hashToObjectKey(contentHash: string): string {
  // Strip prefix if present
  const hash = contentHash.replace('sha256:', '');
  
  // Shard: first 2 chars / next 2 chars / full hash
  const shard1 = hash.slice(0, 2);
  const shard2 = hash.slice(2, 4);
  
  return `objects/sha256/${shard1}/${shard2}/${hash}`;
}

/**
 * Convert content hash to metadata key
 */
function hashToMetadataKey(contentHash: string): string {
  const hash = contentHash.replace('sha256:', '');
  const shard1 = hash.slice(0, 2);
  const shard2 = hash.slice(2, 4);
  
  return `metadata/sha256/${shard1}/${shard2}/${hash}.glyph.json`;
}

/**
 * Store content by hash
 * 
 * Returns true if stored, false if already exists.
 */
export async function storeContent(
  contentHash: string,
  content: Buffer | string
): Promise<boolean> {
  const key = hashToObjectKey(contentHash);
  
  // Check if already exists
  try {
    await getClient().send(new HeadObjectCommand({
      Bucket: bucketName,
      Key: key,
    }));
    return false; // Already exists
  } catch (err: any) {
    if (err.name !== 'NotFound') throw err;
  }
  
  // Store
  const buffer = typeof content === 'string' 
    ? Buffer.from(content, 'utf-8')
    : content;
  
  await getClient().send(new PutObjectCommand({
    Bucket: bucketName,
    Key: key,
    Body: buffer,
    ContentType: 'application/octet-stream',
    Metadata: {
      'content-hash': contentHash,
    },
  }));
  
  return true;
}

/**
 * Retrieve content by hash
 * 
 * Returns null if not found.
 */
export async function getContent(contentHash: string): Promise<Buffer | null> {
  const key = hashToObjectKey(contentHash);
  
  try {
    const response = await getClient().send(new GetObjectCommand({
      Bucket: bucketName,
      Key: key,
    }));
    
    if (!response.Body) return null;
    
    // Convert stream to buffer
    const chunks: Buffer[] = [];
    for await (const chunk of response.Body as any) {
      chunks.push(chunk);
    }
    
    return Buffer.concat(chunks);
  } catch (err: any) {
    if (err.name === 'NoSuchKey' || err.name === 'NotFound') {
      return null;
    }
    throw err;
  }
}

/**
 * Check if content exists
 */
export async function contentExists(contentHash: string): Promise<boolean> {
  const key = hashToObjectKey(contentHash);
  
  try {
    await getClient().send(new HeadObjectCommand({
      Bucket: bucketName,
      Key: key,
    }));
    return true;
  } catch (err: any) {
    if (err.name === 'NotFound' || err.name === 'NoSuchKey') {
      return false;
    }
    throw err;
  }
}

/**
 * Store glyph metadata sidecar
 */
export async function storeMetadata(
  contentHash: string,
  metadata: string
): Promise<void> {
  const key = hashToMetadataKey(contentHash);
  
  await getClient().send(new PutObjectCommand({
    Bucket: bucketName,
    Key: key,
    Body: Buffer.from(metadata, 'utf-8'),
    ContentType: 'application/json',
    Metadata: {
      'content-hash': contentHash,
    },
  }));
}

/**
 * Retrieve glyph metadata sidecar
 */
export async function getMetadata(contentHash: string): Promise<string | null> {
  const key = hashToMetadataKey(contentHash);
  
  try {
    const response = await getClient().send(new GetObjectCommand({
      Bucket: bucketName,
      Key: key,
    }));
    
    if (!response.Body) return null;
    
    const chunks: Buffer[] = [];
    for await (const chunk of response.Body as any) {
      chunks.push(chunk);
    }
    
    return Buffer.concat(chunks).toString('utf-8');
  } catch (err: any) {
    if (err.name === 'NoSuchKey' || err.name === 'NotFound') {
      return null;
    }
    throw err;
  }
}

/**
 * Get object stats
 */
export async function getContentStats(contentHash: string): Promise<{
  size: number;
  lastModified: Date;
} | null> {
  const key = hashToObjectKey(contentHash);
  
  try {
    const response = await getClient().send(new HeadObjectCommand({
      Bucket: bucketName,
      Key: key,
    }));
    
    return {
      size: response.ContentLength || 0,
      lastModified: response.LastModified || new Date(),
    };
  } catch (err: any) {
    if (err.name === 'NotFound' || err.name === 'NoSuchKey') {
      return null;
    }
    throw err;
  }
}
