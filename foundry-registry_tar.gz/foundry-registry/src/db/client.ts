/**
 * Foundry Registry - Database Client
 * 
 * Postgres connection pool with typed queries.
 */

import pg from 'pg';
import type { Glyph, Attestation } from '@foundry/core';

const { Pool } = pg;

// Connection pool
let pool: pg.Pool | null = null;

export interface DbConfig {
  host: string;
  port: number;
  database: string;
  user: string;
  password: string;
  max?: number;          // Max connections
  idleTimeoutMillis?: number;
}

/**
 * Initialize database connection pool
 */
export function initDb(config: DbConfig): void {
  pool = new Pool({
    host: config.host,
    port: config.port,
    database: config.database,
    user: config.user,
    password: config.password,
    max: config.max || 20,
    idleTimeoutMillis: config.idleTimeoutMillis || 30000,
  });
  
  pool.on('error', (err) => {
    console.error('Unexpected database error:', err);
  });
}

/**
 * Get pool (throws if not initialized)
 */
function getPool(): pg.Pool {
  if (!pool) {
    throw new Error('Database not initialized. Call initDb() first.');
  }
  return pool;
}

/**
 * Close database connections
 */
export async function closeDb(): Promise<void> {
  if (pool) {
    await pool.end();
    pool = null;
  }
}

// ============================================================================
// Glyph Operations
// ============================================================================

export interface DbGlyph {
  id: string;
  schema_version: number;
  content_hash: string;
  content_size: number;
  content_type: string;
  quality: string;
  origin_type: string;
  origin_parents: string[] | null;
  origin_source_uri: string | null;
  created_at: Date;
  promoted_at: Date | null;
  producer_user_id: string;
  producer_tool: string;
  producer_environment: string;
}

export async function insertGlyph(glyph: Glyph): Promise<void> {
  const query = `
    INSERT INTO glyphs (
      id, schema_version, content_hash, content_size, content_type,
      quality, origin_type, origin_parents, origin_source_uri,
      created_at, promoted_at, producer_user_id, producer_tool, producer_environment
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
  `;
  
  await getPool().query(query, [
    glyph.id,
    glyph.schemaVersion,
    glyph.contentHash,
    glyph.contentSize,
    glyph.contentType,
    glyph.quality,
    glyph.origin.type,
    glyph.origin.parents || null,
    glyph.origin.sourceUri || null,
    glyph.createdAt,
    glyph.promotedAt || null,
    glyph.producer.userId,
    glyph.producer.tool,
    glyph.producer.environment,
  ]);
}

export async function getGlyphById(id: string): Promise<DbGlyph | null> {
  const result = await getPool().query<DbGlyph>(
    'SELECT * FROM glyphs WHERE id = $1',
    [id]
  );
  
  return result.rows[0] || null;
}

export async function getGlyphFull(id: string): Promise<{
  glyph: DbGlyph;
  attestations: Attestation[];
  tags: string[];
} | null> {
  const result = await getPool().query(
    'SELECT * FROM get_glyph_full($1)',
    [id]
  );
  
  if (result.rows.length === 0) return null;
  
  const row = result.rows[0];
  return {
    glyph: row.glyph_data,
    attestations: row.attestations_data,
    tags: row.tags_data,
  };
}

export async function listGlyphs(params: {
  quality?: string;
  contentType?: string;
  userId?: string;
  limit?: number;
  offset?: number;
}): Promise<DbGlyph[]> {
  const result = await getPool().query(
    'SELECT * FROM list_glyphs($1, $2, $3, $4, $5)',
    [
      params.quality || null,
      params.contentType || null,
      params.userId || null,
      params.limit || 50,
      params.offset || 0,
    ]
  );
  
  return result.rows.map(r => r.glyph_data);
}

export async function updateGlyphQuality(
  id: string,
  quality: string,
  promotedAt: string
): Promise<void> {
  await getPool().query(
    'UPDATE glyphs SET quality = $1, promoted_at = $2 WHERE id = $3',
    [quality, promotedAt, id]
  );
}

// ============================================================================
// Attestation Operations
// ============================================================================

export async function insertAttestation(
  glyphId: string,
  attestation: Attestation
): Promise<void> {
  const query = `
    INSERT INTO attestations (
      glyph_id, quality, signer, signature, signed_at, evidence_uri, metadata
    ) VALUES ($1, $2, $3, $4, $5, $6, $7)
    ON CONFLICT (glyph_id, quality, signer) DO UPDATE
    SET signature = EXCLUDED.signature,
        signed_at = EXCLUDED.signed_at,
        evidence_uri = EXCLUDED.evidence_uri,
        metadata = EXCLUDED.metadata
  `;
  
  await getPool().query(query, [
    glyphId,
    attestation.quality,
    attestation.signer,
    attestation.signature,
    attestation.signedAt,
    attestation.evidence || null,
    attestation.metadata ? JSON.stringify(attestation.metadata) : null,
  ]);
}

export async function getAttestations(glyphId: string): Promise<Attestation[]> {
  const result = await getPool().query(
    'SELECT * FROM attestations WHERE glyph_id = $1 ORDER BY signed_at DESC',
    [glyphId]
  );
  
  return result.rows.map(row => ({
    quality: row.quality,
    signer: row.signer,
    signature: row.signature,
    signedAt: row.signed_at.toISOString(),
    evidence: row.evidence_uri,
    metadata: row.metadata,
  }));
}

// ============================================================================
// Tag Operations
// ============================================================================

export async function addTag(glyphId: string, tag: string): Promise<void> {
  await getPool().query(
    'INSERT INTO glyph_tags (glyph_id, tag) VALUES ($1, $2) ON CONFLICT DO NOTHING',
    [glyphId, tag]
  );
}

export async function getTags(glyphId: string): Promise<string[]> {
  const result = await getPool().query(
    'SELECT tag FROM glyph_tags WHERE glyph_id = $1 ORDER BY tag',
    [glyphId]
  );
  
  return result.rows.map(r => r.tag);
}

export async function findByTag(tag: string): Promise<string[]> {
  const result = await getPool().query(
    'SELECT glyph_id FROM glyph_tags WHERE tag = $1',
    [tag]
  );
  
  return result.rows.map(r => r.glyph_id);
}

// ============================================================================
// Audit Log Operations
// ============================================================================

export async function auditLog(
  eventType: string,
  glyphId: string,
  actorUserId: string,
  metadata?: Record<string, unknown>
): Promise<void> {
  await getPool().query(
    'SELECT audit_log($1, $2, $3, $4)',
    [
      eventType,
      glyphId,
      actorUserId,
      metadata ? JSON.stringify(metadata) : null,
    ]
  );
}

export async function getAuditTrail(glyphId: string): Promise<Array<{
  eventType: string;
  actorUserId: string;
  occurredAt: Date;
  metadata: Record<string, unknown> | null;
}>> {
  const result = await getPool().query(
    'SELECT event_type, actor_user_id, occurred_at, metadata FROM audit_events WHERE glyph_id = $1 ORDER BY occurred_at ASC',
    [glyphId]
  );
  
  return result.rows.map(r => ({
    eventType: r.event_type,
    actorUserId: r.actor_user_id,
    occurredAt: r.occurred_at,
    metadata: r.metadata,
  }));
}

// ============================================================================
// API Key Operations
// ============================================================================

export async function verifyApiKey(keyHash: string): Promise<{
  userId: string;
  role: string;
} | null> {
  const result = await getPool().query(
    `UPDATE api_keys 
     SET last_used_at = NOW() 
     WHERE key_hash = $1 AND (expires_at IS NULL OR expires_at > NOW())
     RETURNING user_id, role`,
    [keyHash]
  );
  
  if (result.rows.length === 0) return null;
  
  return {
    userId: result.rows[0].user_id,
    role: result.rows[0].role,
  };
}
