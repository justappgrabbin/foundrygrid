-- Foundry Registry - Database Schema
-- PostgreSQL 14+

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- Glyphs (Core Registry)
-- ============================================================================

CREATE TABLE glyphs (
  id TEXT PRIMARY KEY,                         -- sha256:...
  schema_version INTEGER NOT NULL DEFAULT 1,
  content_hash TEXT NOT NULL,
  content_size BIGINT NOT NULL,
  content_type TEXT NOT NULL,
  quality TEXT NOT NULL,
  origin_type TEXT NOT NULL,
  origin_parents TEXT[],
  origin_source_uri TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  promoted_at TIMESTAMPTZ,
  producer_user_id TEXT NOT NULL,
  producer_tool TEXT NOT NULL,
  producer_environment TEXT NOT NULL,
  
  -- Constraints
  CONSTRAINT quality_check CHECK (quality IN ('draft', 'tested', 'production', 'archived')),
  CONSTRAINT origin_check CHECK (origin_type IN ('imported', 'assembled', 'derived')),
  CONSTRAINT content_type_check CHECK (content_type IN ('fragment', 'app', 'artifact'))
);

-- Indexes for common queries
CREATE INDEX idx_glyphs_quality ON glyphs(quality);
CREATE INDEX idx_glyphs_content_hash ON glyphs(content_hash);
CREATE INDEX idx_glyphs_created_at ON glyphs(created_at DESC);
CREATE INDEX idx_glyphs_user ON glyphs(producer_user_id);
CREATE INDEX idx_glyphs_content_type ON glyphs(content_type);

-- ============================================================================
-- Attestations (Cryptographic Trust)
-- ============================================================================

CREATE TABLE attestations (
  id SERIAL PRIMARY KEY,
  glyph_id TEXT NOT NULL REFERENCES glyphs(id) ON DELETE CASCADE,
  quality TEXT NOT NULL,
  signer TEXT NOT NULL,
  signature TEXT NOT NULL,
  signed_at TIMESTAMPTZ NOT NULL,
  evidence_uri TEXT,
  metadata JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  -- Constraints
  CONSTRAINT attestation_quality_check CHECK (quality IN ('tested', 'production')),
  
  -- Unique: one attestation per (glyph, quality, signer)
  UNIQUE (glyph_id, quality, signer)
);

CREATE INDEX idx_attestations_glyph ON attestations(glyph_id);
CREATE INDEX idx_attestations_signer ON attestations(signer);
CREATE INDEX idx_attestations_quality ON attestations(quality);

-- ============================================================================
-- Tags (Discovery)
-- ============================================================================

CREATE TABLE glyph_tags (
  glyph_id TEXT NOT NULL REFERENCES glyphs(id) ON DELETE CASCADE,
  tag TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  
  PRIMARY KEY (glyph_id, tag)
);

CREATE INDEX idx_tags_tag ON glyph_tags(tag);

-- ============================================================================
-- Audit Log (Append-Only, Immutable)
-- ============================================================================

CREATE TABLE audit_events (
  id BIGSERIAL PRIMARY KEY,
  event_type TEXT NOT NULL,
  glyph_id TEXT NOT NULL,
  actor_user_id TEXT NOT NULL,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  metadata JSONB,
  
  -- Immutability constraint
  CONSTRAINT audit_immutable CHECK (occurred_at <= NOW())
);

CREATE INDEX idx_audit_glyph ON audit_events(glyph_id);
CREATE INDEX idx_audit_time ON audit_events(occurred_at DESC);
CREATE INDEX idx_audit_event_type ON audit_events(event_type);
CREATE INDEX idx_audit_actor ON audit_events(actor_user_id);

-- Prevent UPDATE and DELETE on audit_events
CREATE RULE audit_no_update AS ON UPDATE TO audit_events DO INSTEAD NOTHING;
CREATE RULE audit_no_delete AS ON DELETE TO audit_events DO INSTEAD NOTHING;

-- ============================================================================
-- API Keys (Authentication)
-- ============================================================================

CREATE TABLE api_keys (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  key_hash TEXT NOT NULL UNIQUE,           -- bcrypt hash
  user_id TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'reader',
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ,
  last_used_at TIMESTAMPTZ,
  
  CONSTRAINT role_check CHECK (role IN ('admin', 'maintainer', 'reader'))
);

CREATE INDEX idx_api_keys_user ON api_keys(user_id);
CREATE INDEX idx_api_keys_hash ON api_keys(key_hash);

-- ============================================================================
-- Helper Functions
-- ============================================================================

-- Insert audit event (safe wrapper)
CREATE OR REPLACE FUNCTION audit_log(
  p_event_type TEXT,
  p_glyph_id TEXT,
  p_actor_user_id TEXT,
  p_metadata JSONB DEFAULT NULL
) RETURNS BIGINT AS $$
DECLARE
  v_id BIGINT;
BEGIN
  INSERT INTO audit_events (event_type, glyph_id, actor_user_id, metadata)
  VALUES (p_event_type, p_glyph_id, p_actor_user_id, p_metadata)
  RETURNING id INTO v_id;
  
  RETURN v_id;
END;
$$ LANGUAGE plpgsql;

-- Get glyph with attestations
CREATE OR REPLACE FUNCTION get_glyph_full(p_glyph_id TEXT)
RETURNS TABLE (
  glyph_data JSONB,
  attestations_data JSONB,
  tags_data TEXT[]
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    to_jsonb(g.*) AS glyph_data,
    COALESCE(jsonb_agg(to_jsonb(a.*)) FILTER (WHERE a.id IS NOT NULL), '[]'::jsonb) AS attestations_data,
    COALESCE(array_agg(t.tag) FILTER (WHERE t.tag IS NOT NULL), ARRAY[]::TEXT[]) AS tags_data
  FROM glyphs g
  LEFT JOIN attestations a ON a.glyph_id = g.id
  LEFT JOIN glyph_tags t ON t.glyph_id = g.id
  WHERE g.id = p_glyph_id
  GROUP BY g.id;
END;
$$ LANGUAGE plpgsql;

-- List glyphs with filters
CREATE OR REPLACE FUNCTION list_glyphs(
  p_quality TEXT DEFAULT NULL,
  p_content_type TEXT DEFAULT NULL,
  p_user_id TEXT DEFAULT NULL,
  p_limit INT DEFAULT 50,
  p_offset INT DEFAULT 0
) RETURNS TABLE (
  glyph_data JSONB
) AS $$
BEGIN
  RETURN QUERY
  SELECT to_jsonb(g.*) AS glyph_data
  FROM glyphs g
  WHERE
    (p_quality IS NULL OR g.quality = p_quality) AND
    (p_content_type IS NULL OR g.content_type = p_content_type) AND
    (p_user_id IS NULL OR g.producer_user_id = p_user_id)
  ORDER BY g.created_at DESC
  LIMIT p_limit
  OFFSET p_offset;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- Initial Data
-- ============================================================================

-- Create default admin API key (CHANGE IN PRODUCTION)
-- Key: foundry_admin_dev_key_change_me
-- Hash generated with: bcrypt('foundry_admin_dev_key_change_me', 10)
INSERT INTO api_keys (key_hash, user_id, role, description)
VALUES (
  '$2a$10$N9qo8uLOickgx2ZMRZoMye7dJxQh8JxNqJD3XrwLzz3Y4xRdVLXsS',
  'admin',
  'admin',
  'Default admin key (DEVELOPMENT ONLY - CHANGE IN PRODUCTION)'
);
