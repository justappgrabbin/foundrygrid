/**
 * Foundry Registry - Glyph Routes
 * 
 * REST API for glyph operations.
 */

import { Router } from 'express';
import {
  createGlyph,
  verifyGlyphIntegrity,
  computeContentHash,
  serializeGlyph,
  parseGlyph,
  type FragmentInput,
} from '@foundry/core';
import {
  insertGlyph,
  getGlyphById,
  getGlyphFull,
  listGlyphs,
  updateGlyphQuality,
  addTag,
  getTags,
  auditLog,
} from '../../db/client.js';
import { storeContent, getContent, contentExists } from '../../storage/s3.js';
import type { AuthenticatedRequest } from '../middleware/auth.js';
import { requireRole } from '../middleware/auth.js';

export const glyphRouter = Router();

// ============================================================================
// POST /glyphs/ingest
// Ingest content and create glyph
// ============================================================================

glyphRouter.post('/ingest', requireRole('admin', 'maintainer'), async (req: AuthenticatedRequest, res) => {
  try {
    const { content, manifest, quality, origin, tags } = req.body;
    
    if (!content) {
      res.status(400).json({ error: 'Missing required field: content' });
      return;
    }
    
    // Create glyph
    const input: FragmentInput = {
      content,
      manifest,
      quality: quality || 'draft',
      origin,
      producer: {
        userId: req.auth!.userId,
        tool: req.headers['user-agent'] || 'unknown',
        environment: `node/${process.version}`,
      },
    };
    
    const glyph = createGlyph(input);
    
    // Verify integrity
    if (!verifyGlyphIntegrity(glyph)) {
      res.status(500).json({ error: 'Glyph integrity check failed' });
      return;
    }
    
    // Check if already exists
    const existing = await getGlyphById(glyph.id);
    if (existing) {
      res.status(409).json({
        error: 'Glyph already exists',
        glyphId: glyph.id,
      });
      return;
    }
    
    // Store content in S3
    const stored = await storeContent(glyph.contentHash, content);
    
    // Store glyph metadata in database
    await insertGlyph(glyph);
    
    // Add tags if provided
    if (tags && Array.isArray(tags)) {
      for (const tag of tags) {
        await addTag(glyph.id, tag);
      }
    }
    
    // Audit log
    await auditLog('glyph.created', glyph.id, req.auth!.userId, {
      contentHash: glyph.contentHash,
      quality: glyph.quality,
      stored: stored,
    });
    
    res.status(201).json({
      glyph: {
        id: glyph.id,
        contentHash: glyph.contentHash,
        quality: glyph.quality,
        origin: glyph.origin,
      },
      stored,
    });
  } catch (err: any) {
    console.error('Ingest error:', err);
    res.status(500).json({
      error: 'Failed to ingest content',
      message: err.message,
    });
  }
});

// ============================================================================
// GET /glyphs/:id
// Get glyph metadata (without content)
// ============================================================================

glyphRouter.get('/:id', async (req: AuthenticatedRequest, res) => {
  try {
    const { id } = req.params;
    
    const result = await getGlyphFull(id);
    
    if (!result) {
      res.status(404).json({ error: 'Glyph not found' });
      return;
    }
    
    res.json({
      glyph: result.glyph,
      attestations: result.attestations,
      tags: result.tags,
    });
  } catch (err: any) {
    console.error('Get glyph error:', err);
    res.status(500).json({
      error: 'Failed to retrieve glyph',
      message: err.message,
    });
  }
});

// ============================================================================
// GET /glyphs/:id/content
// Get glyph content (raw bytes)
// ============================================================================

glyphRouter.get('/:id/content', async (req: AuthenticatedRequest, res) => {
  try {
    const { id } = req.params;
    
    // Get glyph metadata
    const glyph = await getGlyphById(id);
    if (!glyph) {
      res.status(404).json({ error: 'Glyph not found' });
      return;
    }
    
    // Get content from S3
    const content = await getContent(glyph.content_hash);
    if (!content) {
      res.status(404).json({ error: 'Content not found in storage' });
      return;
    }
    
    // Return raw bytes
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Length', content.length);
    res.setHeader('X-Content-Hash', glyph.content_hash);
    res.send(content);
  } catch (err: any) {
    console.error('Get content error:', err);
    res.status(500).json({
      error: 'Failed to retrieve content',
      message: err.message,
    });
  }
});

// ============================================================================
// GET /glyphs
// List glyphs with filters
// ============================================================================

glyphRouter.get('/', async (req: AuthenticatedRequest, res) => {
  try {
    const {
      quality,
      contentType,
      userId,
      limit = '50',
      offset = '0',
    } = req.query;
    
    const glyphs = await listGlyphs({
      quality: quality as string | undefined,
      contentType: contentType as string | undefined,
      userId: userId as string | undefined,
      limit: parseInt(limit as string, 10),
      offset: parseInt(offset as string, 10),
    });
    
    res.json({
      glyphs,
      count: glyphs.length,
    });
  } catch (err: any) {
    console.error('List glyphs error:', err);
    res.status(500).json({
      error: 'Failed to list glyphs',
      message: err.message,
    });
  }
});

// ============================================================================
// POST /glyphs/:id/promote
// Promote glyph quality (requires attestation)
// ============================================================================

glyphRouter.post('/:id/promote', requireRole('admin', 'maintainer'), async (req: AuthenticatedRequest, res) => {
  try {
    const { id } = req.params;
    const { quality, attestation } = req.body;
    
    if (!quality) {
      res.status(400).json({ error: 'Missing required field: quality' });
      return;
    }
    
    if (!['tested', 'production'].includes(quality)) {
      res.status(400).json({ error: 'Quality must be "tested" or "production"' });
      return;
    }
    
    // Get current glyph
    const glyph = await getGlyphById(id);
    if (!glyph) {
      res.status(404).json({ error: 'Glyph not found' });
      return;
    }
    
    // Check monotonic promotion
    const qualityOrder = ['draft', 'tested', 'production', 'archived'];
    const currentIndex = qualityOrder.indexOf(glyph.quality);
    const newIndex = qualityOrder.indexOf(quality);
    
    if (newIndex <= currentIndex && quality !== 'archived') {
      res.status(400).json({
        error: 'Quality can only be promoted forward (draft → tested → production)',
        current: glyph.quality,
        requested: quality,
      });
      return;
    }
    
    // Update quality
    const promotedAt = new Date().toISOString();
    await updateGlyphQuality(id, quality, promotedAt);
    
    // Audit log
    await auditLog('glyph.promoted', id, req.auth!.userId, {
      from: glyph.quality,
      to: quality,
      attestation: attestation || null,
    });
    
    res.json({
      glyphId: id,
      quality,
      promotedAt,
    });
  } catch (err: any) {
    console.error('Promote error:', err);
    res.status(500).json({
      error: 'Failed to promote glyph',
      message: err.message,
    });
  }
});

// ============================================================================
// POST /glyphs/:id/tags
// Add tag to glyph
// ============================================================================

glyphRouter.post('/:id/tags', requireRole('admin', 'maintainer'), async (req: AuthenticatedRequest, res) => {
  try {
    const { id } = req.params;
    const { tag } = req.body;
    
    if (!tag) {
      res.status(400).json({ error: 'Missing required field: tag' });
      return;
    }
    
    await addTag(id, tag);
    
    await auditLog('glyph.tagged', id, req.auth!.userId, { tag });
    
    res.json({ glyphId: id, tag });
  } catch (err: any) {
    console.error('Add tag error:', err);
    res.status(500).json({
      error: 'Failed to add tag',
      message: err.message,
    });
  }
});

// ============================================================================
// GET /glyphs/:id/tags
// Get tags for glyph
// ============================================================================

glyphRouter.get('/:id/tags', async (req: AuthenticatedRequest, res) => {
  try {
    const { id } = req.params;
    const tags = await getTags(id);
    
    res.json({ glyphId: id, tags });
  } catch (err: any) {
    console.error('Get tags error:', err);
    res.status(500).json({
      error: 'Failed to get tags',
      message: err.message,
    });
  }
});
