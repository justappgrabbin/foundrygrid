/**
 * Foundry Registry - Authentication Middleware
 * 
 * API key-based authentication with role-based access control.
 */

import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { verifyApiKey } from '../../db/client.js';

export interface AuthenticatedRequest extends Request {
  auth?: {
    userId: string;
    role: 'admin' | 'maintainer' | 'reader';
  };
}

/**
 * Hash API key with bcrypt-compatible algorithm
 */
function hashApiKey(key: string): string {
  // Use sha256 for simplicity (in production, use bcrypt)
  return crypto.createHash('sha256').update(key).digest('hex');
}

/**
 * Extract API key from request
 * Supports: Authorization header, x-api-key header, query param
 */
function extractApiKey(req: Request): string | null {
  // Authorization: Bearer <key>
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith('Bearer ')) {
    return authHeader.slice(7);
  }
  
  // X-API-Key header
  const apiKeyHeader = req.headers['x-api-key'];
  if (apiKeyHeader && typeof apiKeyHeader === 'string') {
    return apiKeyHeader;
  }
  
  // Query param (not recommended for production)
  const apiKeyQuery = req.query.api_key;
  if (apiKeyQuery && typeof apiKeyQuery === 'string') {
    return apiKeyQuery;
  }
  
  return null;
}

/**
 * Authentication middleware
 * Verifies API key and populates req.auth
 */
export async function authenticate(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const apiKey = extractApiKey(req);
  
  if (!apiKey) {
    res.status(401).json({
      error: 'Unauthorized',
      message: 'Missing API key. Provide via Authorization header, X-API-Key header, or api_key query param.',
    });
    return;
  }
  
  try {
    // Hash key for lookup
    const keyHash = hashApiKey(apiKey);
    
    // Verify in database
    const auth = await verifyApiKey(keyHash);
    
    if (!auth) {
      res.status(401).json({
        error: 'Unauthorized',
        message: 'Invalid or expired API key.',
      });
      return;
    }
    
    // Attach auth to request
    req.auth = {
      userId: auth.userId,
      role: auth.role as 'admin' | 'maintainer' | 'reader',
    };
    
    next();
  } catch (err) {
    console.error('Authentication error:', err);
    res.status(500).json({
      error: 'Internal Server Error',
      message: 'Failed to authenticate request.',
    });
  }
}

/**
 * Authorization middleware - require specific role
 */
export function requireRole(...roles: Array<'admin' | 'maintainer' | 'reader'>) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction): void => {
    if (!req.auth) {
      res.status(401).json({
        error: 'Unauthorized',
        message: 'Not authenticated.',
      });
      return;
    }
    
    if (!roles.includes(req.auth.role)) {
      res.status(403).json({
        error: 'Forbidden',
        message: `Requires one of: ${roles.join(', ')}. You have: ${req.auth.role}`,
      });
      return;
    }
    
    next();
  };
}
