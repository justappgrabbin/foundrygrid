/**
 * Foundry Registry - HTTP Server
 * 
 * REST API server with authentication and routing.
 */

import express from 'express';
import cors from 'cors';
import { authenticate } from './middleware/auth.js';
import { glyphRouter } from './routes/glyphs.js';

export interface ServerConfig {
  port: number;
  corsOrigins?: string[];
}

export function createServer(config: ServerConfig): express.Application {
  const app = express();
  
  // Middleware
  app.use(express.json({ limit: '50mb' })); // Support large payloads
  app.use(cors({
    origin: config.corsOrigins || '*',
    credentials: true,
  }));
  
  // Health check (no auth required)
  app.get('/health', (req, res) => {
    res.json({
      status: 'healthy',
      version: '1.0.0',
      timestamp: new Date().toISOString(),
    });
  });
  
  // API routes (require authentication)
  app.use('/api/v1/glyphs', authenticate, glyphRouter);
  
  // Error handling
  app.use((err: Error, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error('Unhandled error:', err);
    res.status(500).json({
      error: 'Internal Server Error',
      message: process.env.NODE_ENV === 'development' ? err.message : 'An error occurred',
    });
  });
  
  // 404 handler
  app.use((req, res) => {
    res.status(404).json({
      error: 'Not Found',
      path: req.path,
    });
  });
  
  return app;
}

export function startServer(app: express.Application, port: number): void {
  app.listen(port, () => {
    console.log(`🚀 Foundry Registry listening on port ${port}`);
    console.log(`   Health: http://localhost:${port}/health`);
    console.log(`   API:    http://localhost:${port}/api/v1/glyphs`);
  });
}
