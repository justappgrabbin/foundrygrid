# Foundry Registry

**Content-addressable glyph registry with PostgreSQL + S3/MinIO.**

The infrastructure layer that stores, indexes, and serves glyphs created by `@foundry/core`.

---

## Architecture

```
┌─────────────────────────────────────┐
│   HTTP API (Express)                │
│   - Authentication (API keys)       │
│   - REST endpoints                  │
│   - CORS + JSON middleware          │
└─────────────────────────────────────┘
              ↓
┌─────────────────────────────────────┐
│   Registry Service                  │
│   - Glyph ingestion                 │
│   - Quality promotion               │
│   - Tag management                  │
│   - Audit logging                   │
└─────────────────────────────────────┘
       ↓                    ↓
┌─────────────┐      ┌──────────────┐
│  PostgreSQL │      │  S3/MinIO    │
│  (metadata) │      │  (content)   │
└─────────────┘      └──────────────┘
```

---

## Quick Start

### 1. Start Infrastructure

```bash
# Start Postgres + MinIO
docker-compose up -d postgres minio minio-init

# Wait for services to be healthy
docker-compose ps
```

### 2. Run Registry

```bash
# Install dependencies
npm install

# Build
npm run build

# Start server
npm start
```

Server will be available at `http://localhost:3000`.

---

## API Reference

### Authentication

All API endpoints require authentication via API key.

**Methods:**
1. Authorization header: `Authorization: Bearer <key>`
2. X-API-Key header: `X-API-Key: <key>`
3. Query parameter: `?api_key=<key>` (not recommended)

**Default API key (development only):**
```
foundry_admin_dev_key_change_me
```

---

### Endpoints

#### POST /api/v1/glyphs/ingest

Ingest content and create glyph.

**Request:**
```json
{
  "content": "export function Button() { return <button>Click</button>; }",
  "manifest": { "name": "button", "version": "1.0.0" },
  "quality": "draft",
  "origin": {
    "type": "imported",
    "sourceUri": "file:///path/to/Button.tsx"
  },
  "tags": ["ui", "components"]
}
```

**Response:**
```json
{
  "glyph": {
    "id": "sha256:abc123...",
    "contentHash": "sha256:def456...",
    "quality": "draft",
    "origin": { "type": "imported", "sourceUri": "..." }
  },
  "stored": true
}
```

---

#### GET /api/v1/glyphs/:id

Get glyph metadata (without content).

**Response:**
```json
{
  "glyph": {
    "id": "sha256:abc123...",
    "content_hash": "sha256:def456...",
    "content_size": 1234,
    "content_type": "fragment",
    "quality": "production",
    "origin_type": "imported",
    "created_at": "2025-12-13T16:30:00Z",
    "producer_user_id": "alice"
  },
  "attestations": [
    {
      "quality": "production",
      "signer": "alice",
      "signature": "...",
      "signedAt": "2025-12-13T18:00:00Z"
    }
  ],
  "tags": ["ui", "components"]
}
```

---

#### GET /api/v1/glyphs/:id/content

Get raw content bytes.

**Response:** Binary data (application/octet-stream)

**Headers:**
- `X-Content-Hash`: sha256:...
- `Content-Length`: bytes

---

#### GET /api/v1/glyphs

List glyphs with filters.

**Query Parameters:**
- `quality`: draft | tested | production | archived
- `contentType`: fragment | app | artifact
- `userId`: filter by producer
- `limit`: max results (default 50)
- `offset`: pagination offset

**Response:**
```json
{
  "glyphs": [
    { "id": "sha256:...", "quality": "production", ... },
    { "id": "sha256:...", "quality": "tested", ... }
  ],
  "count": 2
}
```

---

#### POST /api/v1/glyphs/:id/promote

Promote glyph quality level.

**Requires:** admin or maintainer role

**Request:**
```json
{
  "quality": "production",
  "attestation": {
    "signer": "alice",
    "signature": "...",
    "evidence": "https://ci.example.com/run/123"
  }
}
```

**Response:**
```json
{
  "glyphId": "sha256:abc123...",
  "quality": "production",
  "promotedAt": "2025-12-13T18:00:00Z"
}
```

---

#### POST /api/v1/glyphs/:id/tags

Add tag to glyph.

**Request:**
```json
{
  "tag": "ui"
}
```

---

#### GET /api/v1/glyphs/:id/tags

Get tags for glyph.

**Response:**
```json
{
  "glyphId": "sha256:abc123...",
  "tags": ["ui", "components", "button"]
}
```

---

## Database Schema

### Tables

**glyphs**
- Core glyph metadata
- Indexed by: id, quality, content_hash, user

**attestations**
- Cryptographic trust signatures
- Unique per (glyph, quality, signer)

**glyph_tags**
- Discovery tags
- Many-to-many relationship

**audit_events**
- Append-only event log
- Immutable (no UPDATE/DELETE)

**api_keys**
- Authentication credentials
- RBAC: admin | maintainer | reader

---

## Storage Layout

### S3/MinIO

Objects stored with sharded paths:

```
bucket: foundry-registry

/objects/sha256/ab/cd/abcd1234...  (content)
/metadata/sha256/ab/cd/abcd1234.glyph.json  (metadata)
```

**Why sharding?**
- Avoid millions of files in single directory
- Better filesystem performance
- Natural partitioning for backups

---

## Role-Based Access Control

### Roles

**admin**
- Full access
- Can promote to production
- Can manage API keys

**maintainer**
- Can ingest glyphs
- Can promote to tested
- Cannot promote to production

**reader**
- Read-only access
- Can list and retrieve glyphs
- Cannot modify

---

## Configuration

### Environment Variables

```bash
# Database
DB_HOST=localhost
DB_PORT=5432
DB_NAME=foundry
DB_USER=foundry
DB_PASSWORD=foundry
DB_POOL_SIZE=20

# S3/MinIO
S3_ENDPOINT=http://localhost:9000
S3_REGION=us-east-1
S3_BUCKET=foundry-registry
S3_ACCESS_KEY_ID=minioadmin
S3_SECRET_ACCESS_KEY=minioadmin

# Server
PORT=3000
CORS_ORIGINS=http://localhost:5173,http://localhost:3001
```

---

## Production Deployment

### Security Checklist

- [ ] Change default API key
- [ ] Use strong DB password
- [ ] Enable TLS for Postgres
- [ ] Use HTTPS for API
- [ ] Restrict CORS origins
- [ ] Enable S3 encryption at rest
- [ ] Set up backup strategy
- [ ] Configure rate limiting
- [ ] Enable audit log retention
- [ ] Use bcrypt for API key hashing

### Recommended Stack

**Database:** AWS RDS (Postgres 16)
**Storage:** AWS S3
**Compute:** AWS ECS/Fargate or Kubernetes
**Load Balancer:** AWS ALB with TLS
**CDN:** CloudFront (for content delivery)

---

## Audit Log

All operations are logged to `audit_events`:

```sql
SELECT * FROM audit_events 
WHERE glyph_id = 'sha256:abc123...' 
ORDER BY occurred_at ASC;
```

**Event types:**
- `glyph.created`
- `glyph.promoted`
- `glyph.tagged`
- `glyph.exported`
- `attestation.added`

---

## Health Check

```bash
curl http://localhost:3000/health
```

**Response:**
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "timestamp": "2025-12-13T16:30:00Z"
}
```

---

## Testing

```bash
# Run tests
npm test

# Test ingestion
curl -X POST http://localhost:3000/api/v1/glyphs/ingest \
  -H "X-API-Key: foundry_admin_dev_key_change_me" \
  -H "Content-Type: application/json" \
  -d '{
    "content": "export const foo = 42;",
    "quality": "draft"
  }'

# Get glyph
curl http://localhost:3000/api/v1/glyphs/sha256:... \
  -H "X-API-Key: foundry_admin_dev_key_change_me"
```

---

## Monitoring

### Metrics to Track

- API request rate
- P95/P99 latency
- Database connection pool utilization
- S3 request rate
- Audit log volume
- Active API keys

### Logs

All errors logged to console (JSON format in production).

Use structured logging for:
- Authentication failures
- Glyph ingestion errors
- Storage failures
- Database errors

---

## Next Steps

**Phase 2.3: CLI Tool**

Build `foundry` CLI that uses this registry:

```bash
foundry init
foundry ingest ./components/**/*.tsx
foundry list --quality production
foundry get sha256:abc123...
foundry promote sha256:abc123... --to production
```

---

## License

MIT
